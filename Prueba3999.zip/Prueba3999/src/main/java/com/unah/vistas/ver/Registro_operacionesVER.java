/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas.ver;

import com.unah.vista.*;
import dao.OperacionesDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Operacion;
import dao.OperacionesDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.TableModel;
/**
 *
 * @author pango
 */
public class Registro_operacionesVER extends javax.swing.JFrame {

    private OperacionesDAO operacionesDAO;

    public Registro_operacionesVER() {
        initComponents();
        operacionesDAO = new OperacionesDAO();
        cargarDatosTabla();
    }

    private void cargarDatosTabla() {
        // Verifica que jTable1 no sea null
        if (jTable1 == null) {
            System.out.println("jTable1 es null");
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        List<Operacion> operaciones = operacionesDAO.cargarDatos(); // Obtener los datos desde el DAO

        // Agregar los datos al modelo de la tabla
        for (Operacion operacion : operaciones) {
            modeloTabla.addRow(new Object[]{
                operacion.getIdOperacion(),
                operacion.getNombreOperacion(),
                operacion.getDescripcion()
            });
        }}
  
    private void mostrarDialogoFiltroOperaciones() {
    // Opciones de columnas para la tabla de Operaciones
    String[] opcionesFiltro = {"ID", "Nombre Operación", "Descripción"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    
    // Crear checkboxes para cada opción de columna
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    // Opciones de ordenación (Ascendente o Descendente)
    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    // Crear panel principal para el diálogo
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());

    // Panel para las opciones de filtro
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    
    // Añadir checkboxes al panel de filtro
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }

    // Panel para las opciones de ordenación
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    // Añadir paneles al panel principal
    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    // Mostrar diálogo de opciones
    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        // Obtener columnas seleccionadas y orden de las opciones elegidas por el usuario
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        // Aplicar filtro y ordenación a la tabla de Operaciones
        aplicarFiltroYOrdenOperaciones(columnasSeleccionadas, ordenSeleccionado);
    }
}
    
    private void aplicarFiltroYOrdenOperaciones(List<String> columnasSeleccionadas, String orden) {
    // Cargar todos los datos de operaciones desde la base de datos
    List<Operacion> operaciones = operacionesDAO.cargarDatos();

    // Ordenar la lista de operaciones
    operaciones.sort((o1, o2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(o1.getIdOperacion(), o2.getIdOperacion());
                    break;
                case "Nombre Operación":
                    comparacion = o1.getNombreOperacion().compareTo(o2.getNombreOperacion());
                    break;
                case "Descripción":
                    comparacion = o1.getDescripcion().compareTo(o2.getDescripcion());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla dinámicamente basado en las columnas seleccionadas
    DefaultTableModel modeloTabla = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modeloTabla);

    // Llenar el modelo de la tabla con los datos filtrados y ordenados
    for (Operacion operacion : operaciones) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(operacion.getIdOperacion());
                    break;
                case "Nombre Operación":
                    fila.add(operacion.getNombreOperacion());
                    break;
                case "Descripción":
                    fila.add(operacion.getDescripcion());
                    break;
            }
        }
        modeloTabla.addRow(fila.toArray());
    }
}
 
    private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}  

    
      private void exportarOperacionesATxt() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(this);

    if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = fileChooser.getSelectedFile();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave + ".txt"))) {
            TableModel model = jTable1.getModel();

            // Escribir encabezados
            for (int i = 0; i < model.getColumnCount(); i++) {
                writer.write(model.getColumnName(i) + "\t");
            }
            writer.write("\n");

            // Escribir filas de datos
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString() + "\t");
                }
                writer.write("\n");
            }

            JOptionPane.showMessageDialog(this, "Datos exportados exitosamente a TXT.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID Operaciones", "Nombre de Operación", "Descripción"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 858, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7)
                                .addGap(7, 7, 7))
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5)
                        .addComponent(jLabel7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltroOperaciones(); // Llamar al método para agregar insumo
            }
        });
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                actualizarJFrame();
            }
        });  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
  jLabel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
exportarOperacionesATxt();
            }
        });
    }//GEN-LAST:event_jLabel3MouseClicked
       
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro_operacionesVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro_operacionesVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro_operacionesVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro_operacionesVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro_operacionesVER().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}