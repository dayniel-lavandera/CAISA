/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas.ver;

import static com.unah.vista.Insumos.jTable1;
import dao.InsumosDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Insumos1;
/**
 *
 * @author JuanMi025
 */
public class InsumosVER extends javax.swing.JFrame {

     private InsumosDAO insumosDAO;
    public InsumosVER() {
        initComponents(); // Inicializa los componentes de la interfaz
        insumosDAO = new InsumosDAO(); // Crea una instancia del DAO
        cargarDatosTabla(); // Carga datos en la tabla después de inicializar los componentes
    }
    
    private void actualizarTabla() {
    List<Insumos1> listaInsumos = insumosDAO.cargarDatos(); // Obtener los datos actualizados

    // Obtén el modelo de la tabla
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
    
    // Limpiar el modelo existente
    modelo.setRowCount(0);

    // Llenar el modelo con los nuevos datos
    for (Insumos1 insumo : listaInsumos) {
        modelo.addRow(new Object[]{
            insumo.getIdInsumos(),
            insumo.getNombre(),
            insumo.getUm(),
            insumo.getCantidad(),
            insumo.getCausa(),
            insumo.getPuestoIdPuesto()
        });
    }}

    private void cargarDatosTabla() {
        // Verifica que jTable1 no sea null
        if (jTable1 == null) {
            System.out.println("jTable1 es null");
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        List<Insumos1> insumos = insumosDAO.cargarDatos(); // Obtener los datos desde el DAO

        // Agregar los datos al modelo de la tabla
        for (Insumos1 insumo : insumos) {
            modeloTabla.addRow(new Object[]{
                insumo.getIdInsumos(),
                insumo.getNombre(),
                insumo.getUm(),
                insumo.getCantidad(),
                insumo.getCausa(),
                insumo.getPuestoIdPuesto()
            });
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Insumo", "Nombre", "U/M", "Cantidad", "Causa", "puestoid_puesto"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(750, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addGap(12, 12, 12))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addContainerGap())))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5)
                        .addComponent(jLabel7))
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 543, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(40, 40, 40)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 534, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(61, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 private void mostrarDialogoFiltroInsumos() 
    {
    String[] opcionesFiltro = {"ID", "Nombre", "Unidad de Medida", "Cantidad", "Causa", "Puesto ID"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrdenInsumos(columnasSeleccionadas, ordenSeleccionado);
    }
}
    private void aplicarFiltroYOrdenInsumos(List<String> columnasSeleccionadas, String orden) {
    // Cargar todos los datos de insumos desde la base de datos
    List<Insumos1> insumos = insumosDAO.cargarDatos();

    // Ordenar la lista de insumos
    insumos.sort((i1, i2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(i1.getIdInsumos(), i2.getIdInsumos());
                    break;
                case "Nombre":
                    comparacion = i1.getNombre().compareTo(i2.getNombre());
                    break;
                case "Unidad de Medida":
                    comparacion = i1.getUm().compareTo(i2.getUm());
                    break;
                case "Cantidad":
                    comparacion = i1.getCantidad().compareTo(i2.getCantidad());
                    break;
                case "Causa":
                    comparacion = i1.getCausa().compareTo(i2.getCausa());
                    break;
                case "Puesto ID":
                    comparacion = Integer.compare(i1.getPuestoIdPuesto(), i2.getPuestoIdPuesto());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla dinámicamente basado en las columnas seleccionadas
    DefaultTableModel modeloTabla = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modeloTabla);

    // Llenar el modelo de la tabla con los datos filtrados y ordenados
    for (Insumos1 insumo : insumos) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(insumo.getIdInsumos());
                    break;
                case "Nombre":
                    fila.add(insumo.getNombre());
                    break;
                case "Unidad de Medida":
                    fila.add(insumo.getUm());
                    break;
                case "Cantidad":
                    fila.add(insumo.getCantidad());
                    break;
                case "Causa":
                    fila.add(insumo.getCausa());
                    break;
                case "Puesto ID":
                    fila.add(insumo.getPuestoIdPuesto());
                    break;
            }
        }
        modeloTabla.addRow(fila.toArray());
    }
}

    private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}

    

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltroInsumos(); // Llamar al método para agregar insumo
            }
        });
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                actualizarJFrame();
            }
        });  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InsumosVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InsumosVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InsumosVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InsumosVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InsumosVER().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
