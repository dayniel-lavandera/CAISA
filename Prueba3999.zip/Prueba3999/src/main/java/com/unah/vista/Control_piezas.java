
package com.unah.vista;

import dao.PersonalDAO;
import dao.PiezaDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Pieza;

public class Control_piezas extends javax.swing.JFrame {
 private PiezaDAO piezaDAO;
   
 public Control_piezas() {
        initComponents();
    piezaDAO = new PiezaDAO(); 
        cargarDatosTabla();
    actualizarTabla();
    
    }
private void cargarDatosTabla() {
   
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

   
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); 


    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

   
    String[] columnNames = {"ID", "Número", "Código", "Cantidad", "Diseño", "Control Físico", "Observaciones", "Sobrante", "Causa", "Puesto ID", "Operaciones ID", "Puesto ID 2"};

    
    DefaultTableModel modelo = new DefaultTableModel(columnNames, 0);
    jTable1.setModel(modelo);

   
    for (Pieza pieza : listaPiezas) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}
private void agregarPieza() {
    JPanel panel = new JPanel(new GridLayout(0, 2));

    JTextField numeroField = new JTextField();
    JTextField codigoField = new JTextField();
    JTextField cantidadField = new JTextField();
    JTextField diseñoField = new JTextField();
    JTextField controlFisicoField = new JTextField();
    JTextField observacionesField = new JTextField();
    JTextField sobranteField = new JTextField();
    JTextField causaField = new JTextField();
    JTextField puestoidPuestoField = new JTextField();
    JTextField operacionesidOperacionesField = new JTextField();
    JTextField puestoidPuesto2Field = new JTextField();

    panel.add(new JLabel("Número:"));
    panel.add(numeroField);
    panel.add(new JLabel("Código:"));
    panel.add(codigoField);
    panel.add(new JLabel("Cantidad:"));
    panel.add(cantidadField);
    panel.add(new JLabel("Diseño:"));
    panel.add(diseñoField);
    panel.add(new JLabel("Control Físico:"));
    panel.add(controlFisicoField);
    panel.add(new JLabel("Observaciones:"));
    panel.add(observacionesField);
    panel.add(new JLabel("Sobrante:"));
    panel.add(sobranteField);
    panel.add(new JLabel("Causa:"));
    panel.add(causaField);
    panel.add(new JLabel("ID del Puesto:"));
    panel.add(puestoidPuestoField);
    panel.add(new JLabel("ID de Operaciones:"));
    panel.add(operacionesidOperacionesField);
    panel.add(new JLabel("ID del Segundo Puesto:"));
    panel.add(puestoidPuesto2Field);

    int option = JOptionPane.showConfirmDialog(null, panel, "Ingrese los datos de la pieza", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (option == JOptionPane.OK_OPTION) {
        try {
            int numero = Integer.parseInt(numeroField.getText().trim());
            int codigo = Integer.parseInt(codigoField.getText().trim());
            int cantidad = Integer.parseInt(cantidadField.getText().trim());
            int diseño = Integer.parseInt(diseñoField.getText().trim());
            String controlFisico = controlFisicoField.getText().trim();
            String observaciones = observacionesField.getText().trim();
            int sobrante = Integer.parseInt(sobranteField.getText().trim());
            String causa = causaField.getText().trim();
            int puestoidPuesto = Integer.parseInt(puestoidPuestoField.getText().trim());
            int operacionesidOperaciones = Integer.parseInt(operacionesidOperacionesField.getText().trim());
            int puestoidPuesto2 = Integer.parseInt(puestoidPuesto2Field.getText().trim());

            Pieza nuevaPieza = new Pieza(0, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoidPuesto, operacionesidOperaciones, puestoidPuesto2);

            boolean exito = piezaDAO.agregarPieza(nuevaPieza);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Pieza agregada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar la pieza.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Todos los campos numéricos deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe completar todos los campos para agregar la pieza.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
private void eliminarPieza() {
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID de la pieza que desea eliminar:", "Eliminar Pieza", JOptionPane.QUESTION_MESSAGE);

    if (input != null && !input.trim().isEmpty()) {
        try {
            int idPieza = Integer.parseInt(input.trim());

            int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar la pieza con ID " + idPieza + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                boolean exito = piezaDAO.eliminarPieza(idPieza);

                if (exito) {
                    JOptionPane.showMessageDialog(null, "Pieza eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    for (int i = 0; i < model.getRowCount(); i++) {
                        if ((int) model.getValueAt(i, 0) == idPieza) {
                            model.removeRow(i);
                            break;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar la pieza. Verifique si el ID es correcto o si existen dependencias.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de eliminación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
private void modificarPieza() {
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID de la pieza que desea modificar:", "Modificar Pieza", JOptionPane.QUESTION_MESSAGE);

    if (input != null && !input.trim().isEmpty()) {
        try {
            int idPieza = Integer.parseInt(input.trim());

            Pieza piezaModificada = new Pieza(idPieza, 123, 456, 10, 789, "Control OK", "Observación actualizada", 5, "Causa actualizada", 1, 2, 3);

            boolean exito = piezaDAO.actualizarPieza(piezaModificada);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Pieza modificada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar la pieza. Verifique el ID y los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de modificación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
private void exportarDatosATxt() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(null);

    if (userSelection != JFileChooser.APPROVE_OPTION) {
        return; 
    }

    File fileToSave = fileChooser.getSelectedFile();
    
    String filePath = fileToSave.getPath();
    if (!filePath.endsWith(".txt")) {
        filePath += ".txt";
    }
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();

        for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
            writer.write(modeloTabla.getColumnName(i));
            if (i < modeloTabla.getColumnCount() - 1) {
                writer.write("\t"); 
            }
        }
        writer.newLine();

        
        for (int row = 0; row < modeloTabla.getRowCount(); row++) {
            for (int col = 0; col < modeloTabla.getColumnCount(); col++) {
                writer.write(modeloTabla.getValueAt(row, col).toString());
                if (col < modeloTabla.getColumnCount() - 1) {
                    writer.write("\t"); 
                }
            }
            writer.newLine();
        }

        JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a " + filePath, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(null, "Error al exportar los datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
private void mostrarDialogoFiltro() {
    String[] opcionesFiltro = {"ID", "Número", "Código", "Cantidad", "Diseño"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true);
    }
    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);
    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);
    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrden(columnasSeleccionadas, ordenSeleccionado);
    }
}
private void aplicarFiltroYOrden(List<String> columnasSeleccionadas, String orden) {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();
    listaPiezas.sort((p1, p2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(p1.getIdPieza(), p2.getIdPieza());
                    break;
                case "Número":
                    comparacion = Integer.compare(p1.getNumero(), p2.getNumero());
                    break;
                case "Código":
                    comparacion = Integer.compare(p1.getCodigo(), p2.getCodigo());
                    break;
                case "Cantidad":
                    comparacion = Integer.compare(p1.getCantidad(), p2.getCantidad());
                    break;
                case "Diseño":
                    comparacion = Integer.compare(p1.getDiseño(), p2.getDiseño());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    DefaultTableModel modelo = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modelo);

    for (Pieza pieza : listaPiezas) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(pieza.getIdPieza());
                    break;
                case "Número":
                    fila.add(pieza.getNumero());
                    break;
                case "Código":
                    fila.add(pieza.getCodigo());
                    break;
                case "Cantidad":
                    fila.add(pieza.getCantidad());
                    break;
                case "Diseño":
                    fila.add(pieza.getDiseño());
                    break;
            }
        }
        modelo.addRow(fila.toArray());
    }
}
private void actualizarTabla() {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();

    Map<Integer, Pieza> mapaPiezas = new HashMap<>();
    for (Pieza pieza : listaPiezas) {
        mapaPiezas.put(pieza.getIdPieza(), pieza);
    }

    for (int i = 0; i < modelo.getRowCount(); i++) {
        int idPieza = (int) modelo.getValueAt(i, 0);
        Pieza pieza = mapaPiezas.get(idPieza);
        if (pieza != null) {
            modelo.setValueAt(pieza.getNumero(), i, 1);
            modelo.setValueAt(pieza.getCodigo(), i, 2);
            modelo.setValueAt(pieza.getCantidad(), i, 3);
            modelo.setValueAt(pieza.getDiseño(), i, 4);
            modelo.setValueAt(pieza.getControlFisico(), i, 5);
            modelo.setValueAt(pieza.getObservaciones(), i, 6);
            modelo.setValueAt(pieza.getSobrante(), i, 7);
            modelo.setValueAt(pieza.getCausa(), i, 8);
            modelo.setValueAt(pieza.getPuestoIdPuesto(), i, 9);
            modelo.setValueAt(pieza.getOperacionesIdOperaciones(), i, 10);
            modelo.setValueAt(pieza.getPuestoIdPuesto2(), i, 11);
            mapaPiezas.remove(idPieza); 
        }
    }

    for (Pieza pieza : mapaPiezas.values()) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}
private void actualizarJFrame() {
   
    this.getContentPane().removeAll();
    initComponents(); 

    
    cargarDatosTabla(); 

    this.revalidate(); 
    this.repaint(); 
}
private void mostrarDialogoBusqueda() {
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Piezas", true);
    dialogoBusqueda.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;

    
    JTextField campoBusqueda = new JTextField();
    dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
    gbc.gridy++;
    dialogoBusqueda.add(campoBusqueda, gbc);

    
    String[] opcionesFiltro = {"ID Pieza", "Número", "Código", "Cantidad", "Diseño"};
    JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); 
        panelOpciones.add(checkBoxes[i]);
    }
    gbc.gridy++;
    gbc.gridwidth = 2;
    dialogoBusqueda.add(panelOpciones, gbc);

    JButton botonBuscar = new JButton("Buscar");
    gbc.gridwidth = 1;
    gbc.gridy++;
    gbc.gridx = 0;
    dialogoBusqueda.add(botonBuscar, gbc);


    botonBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String textoBusqueda = campoBusqueda.getText().trim();
            List<String> columnasSeleccionadas = new ArrayList<>();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    columnasSeleccionadas.add(checkBox.getText());
                }
            }
            List<Pieza> resultadosBusqueda = buscarPiezas(textoBusqueda, columnasSeleccionadas);
            actualizarTablaConResultados(resultadosBusqueda);
            dialogoBusqueda.dispose();
        }
    });

    dialogoBusqueda.pack();
    dialogoBusqueda.setLocationRelativeTo(this);
    dialogoBusqueda.setVisible(true);
}
private List<Pieza> buscarPiezas(String textoBusqueda, List<String> columnasSeleccionadas) {
    if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
        return piezaDAO.cargarDatos();
    }

    String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

    List<Pieza> piezasList = piezaDAO.cargarDatos();

    return piezasList.stream()
            .filter(pieza -> {
              
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Pieza")) {
                    texto = String.valueOf(pieza.getIdPieza()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Número")) {
                    texto = String.valueOf(pieza.getNumero()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Código")) {
                    texto = String.valueOf(pieza.getCodigo()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Cantidad Adicional")) {
                    texto = String.valueOf(pieza.getCantidad()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Diseño")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                    if (columnasSeleccionadas.contains("Cantidad")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                
                     if (columnasSeleccionadas.contains("Control Fisico")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                } 
                    
                    return match;
            })
            .collect(Collectors.toList());
}
private void actualizarTablaConResultados(List<Pieza> piezasFiltrado) {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla


    for (Pieza pieza : piezasFiltrado) {
        modeloTabla.addRow(new Object[]{
                pieza.getIdPieza(),
                pieza.getNumero(),
                pieza.getCodigo(),
                pieza.getCantidad(),
                pieza.getDiseño()
        });
    }
}

@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Pieza", "Número", "Código", "Cantidad Adicional", "Diseño", "Cantidad", "control FÍsico", "Observaciones", "Sobrante", "Causas", "Operaciones ID ", "Puesto ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486503760-backup-disk-data-data-storage-floppy-save_81268.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1066, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        jLabel4.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        agregarPieza(); 
    }
});
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
    jLabel2.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        eliminarPieza(); 
    }
});   
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
     jLabel3.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        exportarDatosATxt(); 
    }
});   
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
         jLabel1.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        modificarPieza(); 
    }
});   
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltro();
            }
        });
      
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
 jLabel7.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
 actualizarJFrame();
    }
});         
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
    jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();    }
});         
    }//GEN-LAST:event_jLabel6MouseClicked

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Control_piezas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
