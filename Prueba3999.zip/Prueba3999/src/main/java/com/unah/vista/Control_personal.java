/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vista;

import dao.PersonalDAO;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.Personal;
import model.Pieza;





/**
 *
 * @author pango
 */
public class Control_personal extends javax.swing.JFrame {

    private PersonalDAO personalDAO;
    
   public Control_personal() {
        initComponents(); // Inicializa los componentes de la interfaz
        personalDAO = new PersonalDAO(); // Crea una instancia del DAO
       cargarDatosTabla(); // Carga los datos en la tabla después de inicializar los componentes
    }
  
private void cargarDatosTabla() {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    List<Personal> listaPersonal = personalDAO.obtenerPersonal();

    for (Personal personal : listaPersonal) {
        modeloTabla.addRow(new Object[]{
            personal.getIdPersonal(),
            personal.getNombre(),
            personal.getCantidad() // Asumiendo que cantidad es un atributo de la clase Personal
        });
    }
 
}

private void agregarPersonal() {
    // Crear un panel para contener todos los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    // Crear los campos de entrada
    JTextField idPersonalField = new JTextField();
    JTextField nombreField = new JTextField();
    JTextField cantidadField = new JTextField();

    // Añadir los campos al panel
    panel.add(new JLabel("ID del nuevo personal:"));
    panel.add(idPersonalField);
    panel.add(new JLabel("Nombre del nuevo personal:"));
    panel.add(nombreField);
    panel.add(new JLabel("Cantidad:"));
    panel.add(cantidadField);

    // Mostrar el panel en un JOptionPane
    int result = JOptionPane.showConfirmDialog(null, panel, "Ingrese los datos del nuevo personal", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        try {
            String idPersonal = idPersonalField.getText().trim();
            String nombre = nombreField.getText().trim();
            BigDecimal cantidad = new BigDecimal(cantidadField.getText().trim());

            // Validar entrada del usuario
            if (!idPersonal.isEmpty() && !nombre.isEmpty() && cantidad != null) {
                // Crear el objeto Personal
                Personal nuevoPersonal = new Personal(idPersonal, nombre, cantidad);

                // Agregar el nuevo personal a la base de datos
                boolean exito = personalDAO.agregarPersonal(nuevoPersonal);

                if (exito) {
                    JOptionPane.showMessageDialog(null, "Personal agregado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    cargarDatosTabla(); // Recargar datos en la tabla
                } else {
                    JOptionPane.showMessageDialog(null, "Error al agregar el personal.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe completar todos los campos para agregar el personal.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La cantidad debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe completar todos los campos para agregar el personal.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void eliminarPersonal() {
    // Solicitar al usuario el ID del personal que desea eliminar
    String idStr = JOptionPane.showInputDialog("Ingrese el ID del personal que desea eliminar:");
    
    if (idStr != null && !idStr.trim().isEmpty()) {
        String idPersonal = idStr.trim();
        
        // Eliminar el personal usando el ID proporcionado
        boolean exito = personalDAO.eliminarPersonal(idPersonal);
        
        if (exito) {
            JOptionPane.showMessageDialog(null, "Personal eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            cargarDatosTabla(); // Recargar datos en la tabla
        } else {
            JOptionPane.showMessageDialog(null, "Error al eliminar el personal.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void exportarDatosATxt() throws IOException {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(this);

    if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = fileChooser.getSelectedFile();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave + ".txt"))) {
            TableModel model = jTable1.getModel();

            // Escribir encabezados
            for (int i = 0; i < model.getColumnCount(); i++) {
                writer.write(model.getColumnName(i) + "\t");
            }
            writer.write("\n");

            // Escribir filas de datos
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString() + "\t");
                }
                writer.write("\n");
            }

            JOptionPane.showMessageDialog(this, "Datos exportados exitosamente a TXT.");
        }    }
}

private void modificarPersonal() {
    // Solicitar al usuario el ID del personal que desea modificar
    String idStr = JOptionPane.showInputDialog("Ingrese el ID del personal que desea modificar:");
    
    if (idStr != null && !idStr.trim().isEmpty()) {
        try {
            String idPersonal = idStr.trim();
            
            // Obtener el personal actual usando el ID proporcionado
            Personal personalActual = personalDAO.obtenerPersonalPorId(idPersonal);
            
            if (personalActual == null) {
                JOptionPane.showMessageDialog(null, "Personal no encontrado para el ID proporcionado.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Crear un panel para contener todos los campos de entrada
            JPanel panel = new JPanel(new GridLayout(0, 2));

            // Crear los campos de entrada con los valores actuales
            JTextField nombreField = new JTextField(personalActual.getNombre());
            JTextField cantidadField = new JTextField(personalActual.getCantidad().toString());

            // Añadir los campos al panel
            panel.add(new JLabel("Nuevo nombre del personal:"));
            panel.add(nombreField);
            panel.add(new JLabel("Nueva cantidad:"));
            panel.add(cantidadField);

            // Mostrar el panel en un JOptionPane
            int result = JOptionPane.showConfirmDialog(null, panel, "Modificar datos del personal", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                try {
                    String nombre = nombreField.getText().trim();
                    BigDecimal cantidad = new BigDecimal(cantidadField.getText().trim());

                    // Validar entrada del usuario
                    if (!nombre.isEmpty() && cantidad != null) {
                        // Crear el objeto Personal actualizado
                        Personal personalActualizado = new Personal(idPersonal, nombre, cantidad);

                        // Actualizar el personal en la base de datos
                        boolean exito = personalDAO.actualizarPersonal(personalActualizado);

                        if (exito) {
                            JOptionPane.showMessageDialog(null, "Personal actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                            cargarDatosTabla(); // Recargar datos en la tabla
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al actualizar el personal.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Debe completar todos los campos para modificar el personal.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "La cantidad debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe completar todos los campos para modificar el personal.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void mostrarDialogoFiltroPersonal() {
    // Define las opciones de filtro (columnas disponibles) y crea los JCheckBox correspondientes
    String[] opcionesFiltro = {"ID", "Nombre", "Cantidad"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    // Define las opciones de ordenación y crea el JComboBox
    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    // Crea el panel de diálogo
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());

    // Panel central para los JCheckBox
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }

    // Panel inferior para el JComboBox de ordenación
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    // Añade los paneles al panel principal
    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    // Muestra el cuadro de diálogo
    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        // Recoge las columnas seleccionadas y el orden elegido
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();

        // Llama al método aplicarFiltroYOrden con las opciones recogidas
        aplicarFiltroYOrden(columnasSeleccionadas, ordenSeleccionado);
    }
}

private void aplicarFiltroYOrden(List<String> columnasSeleccionadas, String orden) {
    // Cargar todos los datos de personal desde la base de datos
    List<Personal> listaPersonal = personalDAO.obtenerPersonal(); // Asegúrate de que este método esté bien implementado en personalDAO

    // Ordenar la lista de personal
    listaPersonal.sort((p1, p2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = p1.getIdPersonal().compareTo(p2.getIdPersonal());
                    break;
                case "Nombre":
                    comparacion = p1.getNombre().compareTo(p2.getNombre());
                    break;
                case "Cantidad":
                    comparacion = p1.getCantidad().compareTo(p2.getCantidad());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla con las columnas seleccionadas
    DefaultTableModel modeloTabla = new DefaultTableModel(columnasSeleccionadas.toArray(new String[0]), 0);
    jTable1.setModel(modeloTabla);

    // Agregar los datos filtrados y ordenados al modelo de la tabla
    for (Personal personal : listaPersonal) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(personal.getIdPersonal());
                    break;
                case "Nombre":
                    fila.add(personal.getNombre());
                    break;
                case "Cantidad":
                    fila.add(personal.getCantidad());
                    break;
            }
        }
        modeloTabla.addRow(fila.toArray());
    }
}

private void mostrarDialogoBusqueda() {
        
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Personal", true);
        dialogoBusqueda.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        // Campo de texto para el término de búsqueda
        JTextField campoBusqueda = new JTextField();
        dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
        gbc.gridy++;
        dialogoBusqueda.add(campoBusqueda, gbc);

        // Opciones de columnas para buscar
        String[] opcionesFiltro = {"ID Personal", "Nombre", "Cantidad"};
        JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
        JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
        for (int i = 0; i < opcionesFiltro.length; i++) {
            checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
            checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
            panelOpciones.add(checkBoxes[i]);
        }
        gbc.gridy++;
        gbc.gridwidth = 2;
        dialogoBusqueda.add(panelOpciones, gbc);

        // Botón para realizar la búsqueda
        JButton botonBuscar = new JButton("Buscar");
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        dialogoBusqueda.add(botonBuscar, gbc);

        // Acción del botón de búsqueda
        botonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoBusqueda = campoBusqueda.getText().trim();
                List<String> columnasSeleccionadas = new ArrayList<>();
                for (JCheckBox checkBox : checkBoxes) {
                    if (checkBox.isSelected()) {
                        columnasSeleccionadas.add(checkBox.getText());
                    }
                }
                List<Personal> resultadosBusqueda = buscarPersonal(textoBusqueda, columnasSeleccionadas);
                actualizarTablaConResultados(resultadosBusqueda);
                dialogoBusqueda.dispose();
            }
        });

        dialogoBusqueda.pack();
        dialogoBusqueda.setLocationRelativeTo(this);
        dialogoBusqueda.setVisible(true);
    }

private List<Personal> buscarPersonal(String textoBusqueda, List<String> columnasSeleccionadas) {
        if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
            return personalDAO.obtenerPersonal();
        }

        String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

        List<Personal> personalList = personalDAO.obtenerPersonal();

        return personalList.stream()
            .filter(personal -> {
                // Convertir los valores de las propiedades a minúsculas para la comparación
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Personal")) {
                    texto = personal.getIdPersonal().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Nombre")) {
                    texto = personal.getNombre().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Cantidad")) {
                    texto = String.valueOf(personal.getCantidad()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }

                return match;
            })
            .collect(Collectors.toList());
    }
    
private void actualizarTablaConResultados(List<Personal> personalFiltrado) {
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        // Añadir el personal filtrado al modelo de la tabla
        for (Personal personal : personalFiltrado) {
            modeloTabla.addRow(new Object[]{
                personal.getIdPersonal(),
                personal.getNombre(),
                personal.getCantidad()
            });
        }
    }

private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID Personal", "Personal", "Cantidad"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486503760-backup-disk-data-data-storage-floppy-save_81268.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 876, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7)
                                .addGap(7, 7, 7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)))
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 529, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        jLabel4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                agregarPersonal(); // Llamar al método para agregar insumo
            }
        });// TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        jLabel2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                eliminarPersonal(); // Llamar al método para agregar insumo
            }
        });    // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        jLabel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    exportarDatosATxt(); // Llamar al método para agregar insumo
                } catch (IOException ex) {
                    Logger.getLogger(Control_personal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        jLabel1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
               modificarPersonal(); // Llamar al método para agregar insumo
            }
        });   // TODO// TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
         @Override
         public void mouseClicked(MouseEvent e) {
        mostrarDialogoFiltroPersonal(); // Llamar al método para agregar insumo
    }
});  
      }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
    jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();    }
});          // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
 actualizarJFrame();
    }
});  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Control_personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Control_personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Control_personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Control_personal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Control_personal().setVisible(true);
          
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    


    
}
