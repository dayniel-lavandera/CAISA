
package com.unah.vista;

import configuracion.ConexionBD;
import dao.OperacionesDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Operacion;
import dao.OperacionesDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.stream.Collectors;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.TableModel;
import static org.postgresql.PGProperty.USER;
/**
 *
 * @author pango
 */
public class Registro_operaciones extends javax.swing.JFrame {

    private OperacionesDAO operacionesDAO;

    public Registro_operaciones() {
        initComponents();
        operacionesDAO = new OperacionesDAO();
        cargarDatosTabla();
    }

    private void cargarDatosTabla() {
        // Verifica que jTable1 no sea null
        if (jTable1 == null) {
            System.out.println("jTable1 es null");
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        List<Operacion> operaciones = operacionesDAO.cargarDatos(); // Obtener los datos desde el DAO

        // Agregar los datos al modelo de la tabla
        for (Operacion operacion : operaciones) {
            modeloTabla.addRow(new Object[]{
                operacion.getIdOperacion(),
                operacion.getNombreOperacion(),
                operacion.getDescripcion()
            });
        }}
    
    private void agregarOperacion() {
    // Crear un panel para contener todos los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    // Crear los campos de entrada
    JTextField nombreOperacionField = new JTextField();
    JTextField descripcionField = new JTextField();

    // Añadir los campos al panel
    panel.add(new JLabel("Nombre de la operación:"));
    panel.add(nombreOperacionField);
    panel.add(new JLabel("Descripción:"));
    panel.add(descripcionField);

    // Mostrar el panel en un JOptionPane
    int result = JOptionPane.showConfirmDialog(null, panel, "Ingrese los datos de la operación", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        try {
            String nombreOperacion = nombreOperacionField.getText();
            String descripcion = descripcionField.getText();

            // Crear el objeto Operacion
            Operacion nuevaOperacion = new Operacion(0, nombreOperacion, descripcion);

            // Llamar al DAO para agregar la operación
            boolean exito = operacionesDAO.agregarOperacion(nuevaOperacion);

            // Informar al usuario del resultado
            if (exito) {
                JOptionPane.showMessageDialog(null, "Operación agregada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al agregar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar todos los datos. La operación de agregar ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
    
    private void eliminarOperacion() {
    // Solicitar al usuario el ID de la operación que desea eliminar
    String idStr = JOptionPane.showInputDialog("Ingrese el ID de la operación que desea eliminar:");
    
    if (idStr != null && !idStr.trim().isEmpty()) {
        int idOperacion;
        try {
            idOperacion = Integer.parseInt(idStr.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Eliminar la operación usando el ID proporcionado
        boolean exito = operacionesDAO.eliminarOperacion(idOperacion);
        
        if (exito) {
            JOptionPane.showMessageDialog(null, "Operación eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            cargarDatosTabla(); // Recargar datos en la tabla
        } else {
            JOptionPane.showMessageDialog(null, "Error al eliminar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
    
    private void modificarOperacion() {
    // Solicitar al usuario el ID de la operación que desea modificar
    String idStr = JOptionPane.showInputDialog("Ingrese el ID de la operación que desea modificar:");
    
    if (idStr != null && !idStr.trim().isEmpty()) {
        try {
            int idOperacion = Integer.parseInt(idStr);
            
            // Obtener la operación actual usando el ID proporcionado
            Operacion operacionActual = operacionesDAO.obtenerOperacionPorId(idOperacion);
            
            if (operacionActual == null) {
                JOptionPane.showMessageDialog(null, "Operación no encontrada para el ID proporcionado.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Crear un panel para contener todos los campos de entrada
            JPanel panel = new JPanel(new GridLayout(0, 2));

            // Crear los campos de entrada con los valores actuales
            JTextField nombreOperacionField = new JTextField(operacionActual.getNombreOperacion());
            JTextField descripcionField = new JTextField(operacionActual.getDescripcion());

            // Añadir los campos al panel
            panel.add(new JLabel("Nuevo nombre de la operación:"));
            panel.add(nombreOperacionField);
            panel.add(new JLabel("Nueva descripción:"));
            panel.add(descripcionField);

            // Mostrar el panel en un JOptionPane
            int result = JOptionPane.showConfirmDialog(null, panel, "Modificar datos de la operación", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                try {
                    String nombreOperacion = nombreOperacionField.getText().trim();
                    String descripcion = descripcionField.getText().trim();

                    // Crear el objeto Operacion actualizado
                    Operacion operacionActualizada = new Operacion(idOperacion, nombreOperacion, descripcion);

                    // Actualizar la operación en la base de datos
                    boolean exito = operacionesDAO.actualizarOperacion(operacionActualizada);

                    if (exito) {
                        JOptionPane.showMessageDialog(null, "Operación actualizada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarDatosTabla(); // Recargar datos en la tabla
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al actualizar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error al actualizar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe completar todos los campos para modificar la operación.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

    private void exportarOperacionesATxt() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(this);

    if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = fileChooser.getSelectedFile();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave + ".txt"))) {
            TableModel model = jTable1.getModel();

            // Escribir encabezados
            for (int i = 0; i < model.getColumnCount(); i++) {
                writer.write(model.getColumnName(i) + "\t");
            }
            writer.write("\n");

            // Escribir filas de datos
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString() + "\t");
                }
                writer.write("\n");
            }

            JOptionPane.showMessageDialog(this, "Datos exportados exitosamente a TXT.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    private void mostrarDialogoFiltroOperaciones() {
    // Opciones de columnas para la tabla de Operaciones
    String[] opcionesFiltro = {"ID", "Nombre Operación", "Descripción"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    
    // Crear checkboxes para cada opción de columna
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    // Opciones de ordenación (Ascendente o Descendente)
    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    // Crear panel principal para el diálogo
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());

    // Panel para las opciones de filtro
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    
    // Añadir checkboxes al panel de filtro
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }

    // Panel para las opciones de ordenación
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    // Añadir paneles al panel principal
    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    // Mostrar diálogo de opciones
    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        // Obtener columnas seleccionadas y orden de las opciones elegidas por el usuario
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        // Aplicar filtro y ordenación a la tabla de Operaciones
        aplicarFiltroYOrdenOperaciones(columnasSeleccionadas, ordenSeleccionado);
    }
}
    
    private void aplicarFiltroYOrdenOperaciones(List<String> columnasSeleccionadas, String orden) {
    // Cargar todos los datos de operaciones desde la base de datos
    List<Operacion> operaciones = operacionesDAO.cargarDatos();

    // Ordenar la lista de operaciones
    operaciones.sort((o1, o2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(o1.getIdOperacion(), o2.getIdOperacion());
                    break;
                case "Nombre Operación":
                    comparacion = o1.getNombreOperacion().compareTo(o2.getNombreOperacion());
                    break;
                case "Descripción":
                    comparacion = o1.getDescripcion().compareTo(o2.getDescripcion());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla dinámicamente basado en las columnas seleccionadas
    DefaultTableModel modeloTabla = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modeloTabla);

    // Llenar el modelo de la tabla con los datos filtrados y ordenados
    for (Operacion operacion : operaciones) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(operacion.getIdOperacion());
                    break;
                case "Nombre Operación":
                    fila.add(operacion.getNombreOperacion());
                    break;
                case "Descripción":
                    fila.add(operacion.getDescripcion());
                    break;
            }
        }
        modeloTabla.addRow(fila.toArray());
    }
}
 
    private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}  
    
    // Método para mostrar el diálogo de búsqueda
private void mostrarDialogoBusqueda() {
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Operaciones", true);
    dialogoBusqueda.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;

    JTextField campoBusqueda = new JTextField();
    dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
    gbc.gridy++;
    dialogoBusqueda.add(campoBusqueda, gbc);

    String[] opcionesFiltro = {"ID Operación", "Nombre Operación", "Descripción"};
    JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); 
        panelOpciones.add(checkBoxes[i]);
    }
    gbc.gridy++;
    gbc.gridwidth = 2;
    dialogoBusqueda.add(panelOpciones, gbc);

    JButton botonBuscar = new JButton("Buscar");
    gbc.gridwidth = 1;
    gbc.gridy++;
    gbc.gridx = 0;
    dialogoBusqueda.add(botonBuscar, gbc);

    botonBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String textoBusqueda = campoBusqueda.getText().trim();
            List<String> columnasSeleccionadas = new ArrayList<>();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    columnasSeleccionadas.add(checkBox.getText());
                }
            }
            List<Operacion> resultadosBusqueda = buscarOperaciones(textoBusqueda, columnasSeleccionadas);
            actualizarTablaConResultados(resultadosBusqueda);
            dialogoBusqueda.dispose();
        }
    });

    dialogoBusqueda.pack();
    dialogoBusqueda.setLocationRelativeTo(this);
    dialogoBusqueda.setVisible(true);
}

// Método para buscar operaciones
private List<Operacion> buscarOperaciones(String textoBusqueda, List<String> columnasSeleccionadas) {
    if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
        return operacionesDAO.cargarDatos();
    }

    String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

    List<Operacion> operacionesList = operacionesDAO.cargarDatos();

    return operacionesList.stream()
            .filter(operacion -> {
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Operación")) {
                    texto = String.valueOf(operacion.getIdOperacion()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Nombre Operación")) {
                    texto = operacion.getNombreOperacion().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Descripción")) {
                    texto = operacion.getDescripcion().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }

                return match;
            })
            .collect(Collectors.toList());
}

// Método para actualizar la tabla con los resultados de la búsqueda
private void actualizarTablaConResultados(List<Operacion> operacionesFiltradas) {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    for (Operacion operacion : operacionesFiltradas) {
        modeloTabla.addRow(new Object[]{
            operacion.getIdOperacion(),
            operacion.getNombreOperacion(),
            operacion.getDescripcion()
        });
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setModalExclusionType(java.awt.Dialog.ModalExclusionType.TOOLKIT_EXCLUDE);
        setUndecorated(true);
        setSize(new java.awt.Dimension(888, 604));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.setText("Buscar");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID Operaciones", "Nombre de Operación", "Descripción"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486503760-backup-disk-data-data-storage-floppy-save_81268.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addGap(6, 6, 6))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1079, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 556, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel1)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        jLabel4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                agregarOperacion(); // Llamar al método para agregar insumo
            }
        });              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        jLabel2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                eliminarOperacion(); // Llamar al método para agregar insumo
            }
        });              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        jLabel1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                modificarOperacion(); // Llamar al método para agregar insumo
            }
        });              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        jLabel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                exportarOperacionesATxt(); // Llamar al método para agregar insumo
            }
        });              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
   jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltroOperaciones(); // Llamar al método para agregar insumo
            }
        });       // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
       jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();    }
});    
    }//GEN-LAST:event_jLabel6MouseClicked
       
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro_operaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro_operaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro_operaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro_operaciones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro_operaciones().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}