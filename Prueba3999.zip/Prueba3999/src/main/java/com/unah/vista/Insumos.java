
package com.unah.vista;
import model.Insumos1;
import dao.HerramientasDAO;
import dao.InsumosDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class Insumos extends javax.swing.JFrame {
  private InsumosDAO insumosDAO;
    public Insumos() {
        initComponents(); // Inicializa los componentes de la interfaz
        insumosDAO = new InsumosDAO(); // Crea una instancia del DAO
        cargarDatosTabla(); // Carga datos en la tabla después de inicializar los componentes
    
        
        actualizarTabla();
    }
    
    private void actualizarTabla() {
    List<Insumos1> listaInsumos = insumosDAO.cargarDatos(); // Obtener los datos actualizados

    // Obtén el modelo de la tabla
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
    
    // Limpiar el modelo existente
    modelo.setRowCount(0);

    // Llenar el modelo con los nuevos datos
    for (Insumos1 insumo : listaInsumos) {
        modelo.addRow(new Object[]{
            insumo.getIdInsumos(),
            insumo.getNombre(),
            insumo.getUm(),
            insumo.getCantidad(),
            insumo.getCausa(),
            insumo.getPuestoIdPuesto()
        });
    }}

    private void cargarDatosTabla() {
        // Verifica que jTable1 no sea null
        if (jTable1 == null) {
            System.out.println("jTable1 es null");
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        List<Insumos1> insumos = insumosDAO.cargarDatos(); // Obtener los datos desde el DAO

        // Agregar los datos al modelo de la tabla
        for (Insumos1 insumo : insumos) {
            modeloTabla.addRow(new Object[]{
                insumo.getIdInsumos(),
                insumo.getNombre(),
                insumo.getUm(),
                insumo.getCantidad(),
                insumo.getCausa(),
                insumo.getPuestoIdPuesto()
            });
        }
    }

    private void agregarInsumo() {
    // Crear un panel para contener todos los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    // Crear los campos de entrada
    JTextField nombreField = new JTextField();
    JTextField umField = new JTextField();
    JTextField cantidadField = new JTextField();
    JTextField causaField = new JTextField();
    JTextField puestoIdPuestoField = new JTextField();

    // Añadir los campos al panel
    panel.add(new JLabel("Nombre del insumo:"));
    panel.add(nombreField);
    panel.add(new JLabel("Unidad de medida (U/M):"));
    panel.add(umField);
    panel.add(new JLabel("Cantidad:"));
    panel.add(cantidadField);
    panel.add(new JLabel("Causa:"));
    panel.add(causaField);
    panel.add(new JLabel("ID del puesto:"));
    panel.add(puestoIdPuestoField);

    // Mostrar el panel en un JOptionPane
    int option = JOptionPane.showConfirmDialog(null, panel, "Agregar Insumo", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (option == JOptionPane.OK_OPTION) {
        try {
            String nombre = nombreField.getText().trim();
            String um = umField.getText().trim();
            BigDecimal cantidad = new BigDecimal(cantidadField.getText().trim());
            int puestoIdPuesto = Integer.parseInt(puestoIdPuestoField.getText().trim());
            String causa = causaField.getText().trim();

            // Crear el objeto Insumos1
            Insumos1 nuevoInsumo = new Insumos1(0, nombre, um, cantidad, causa, puestoIdPuesto);

            // Llamar al DAO para agregar el insumo
            boolean exito = insumosDAO.agregarInsumo(nuevoInsumo);

            // Informar al usuario del resultado
            if (exito) {
                JOptionPane.showMessageDialog(null, "Insumo agregado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar el insumo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID del puesto y la cantidad deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "La cantidad ingresada no es válida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}  

    private void eliminarInsumo() {
    // Mostrar un cuadro de diálogo para que el usuario ingrese el ID del insumo
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID del insumo que desea eliminar:", "Eliminar Insumo", JOptionPane.QUESTION_MESSAGE);
    
    // Verificar si el usuario presionó Cancelar
    if (input != null && !input.trim().isEmpty()) {
        try {
            // Convertir el valor ingresado a un entero
            int idInsumo = Integer.parseInt(input.trim());
            
            // Confirmar la eliminación
            int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el insumo con ID " + idInsumo + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            
            if (confirmacion == JOptionPane.YES_OPTION) {
                // Llamar al DAO para eliminar el insumo
                boolean exito = insumosDAO.eliminarInsumo(idInsumo);
                
                if (exito) {
                    JOptionPane.showMessageDialog(null, "Insumo eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    cargarDatosTabla(); // Recargar datos en la tabla
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar el insumo. Verifique si el ID es correcto.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de eliminación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

    private void modificarInsumo() {
    // Solicitar al usuario el ID del insumo que desea modificar
    String idStr = JOptionPane.showInputDialog("Ingrese el ID del insumo que desea modificar:");
    
    if (idStr != null && !idStr.trim().isEmpty()) {
        try {
            int idInsumo = Integer.parseInt(idStr);
            
            // Obtener el insumo actual usando el ID proporcionado
            Insumos1 insumoActual = insumosDAO.obtenerInsumoPorId(idInsumo);
            
            if (insumoActual == null) {
                JOptionPane.showMessageDialog(null, "Insumo no encontrado para el ID proporcionado.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Crear un panel para contener todos los campos de entrada
            JPanel panel = new JPanel(new GridLayout(0, 2));

            // Crear los campos de entrada con los valores actuales
            JTextField nombreField = new JTextField(insumoActual.getNombre());
            JTextField umField = new JTextField(insumoActual.getUm());
            JTextField cantidadField = new JTextField(insumoActual.getCantidad().toString());
            JTextField causaField = new JTextField(insumoActual.getCausa());
            JTextField puestoIdPuestoField = new JTextField(String.valueOf(insumoActual.getPuestoIdPuesto()));

            // Añadir los campos al panel
            panel.add(new JLabel("Nuevo nombre del insumo:"));
            panel.add(nombreField);
            panel.add(new JLabel("Nueva unidad de medida (U/M):"));
            panel.add(umField);
            panel.add(new JLabel("Nueva cantidad:"));
            panel.add(cantidadField);
            panel.add(new JLabel("Nueva causa:"));
            panel.add(causaField);
            panel.add(new JLabel("Nuevo ID del puesto:"));
            panel.add(puestoIdPuestoField);

            // Mostrar el panel en un JOptionPane
            int result = JOptionPane.showConfirmDialog(null, panel, "Modificar datos del insumo", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                try {
                    String nombre = nombreField.getText().trim();
                    String um = umField.getText().trim();
                    BigDecimal cantidad = new BigDecimal(cantidadField.getText().trim());
                    int puestoIdPuesto = Integer.parseInt(puestoIdPuestoField.getText().trim());
                    String causa = causaField.getText().trim();

                    // Crear el objeto Insumos1 actualizado
                    Insumos1 insumoActualizado = new Insumos1(idInsumo, nombre, um, cantidad, causa, puestoIdPuesto);

                    // Actualizar el insumo en la base de datos
                    boolean exito = insumosDAO.actualizarInsumo(insumoActualizado);

                    if (exito) {
                        JOptionPane.showMessageDialog(null, "Insumo actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarDatosTabla(); // Recargar datos en la tabla
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al actualizar el insumo.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "El ID del puesto debe ser un número entero y la cantidad debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IllegalArgumentException e) {
                    JOptionPane.showMessageDialog(null, "La cantidad ingresada no es válida.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe completar todos los campos para modificar el insumo.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

    private void exportarDatosATxt() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(this);

    if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = fileChooser.getSelectedFile();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave + ".txt"))) {
            TableModel model = jTable1.getModel();

            // Escribir encabezados
            for (int i = 0; i < model.getColumnCount(); i++) {
                writer.write(model.getColumnName(i) + "\t");
            }
            writer.write("\n");

            // Escribir filas de datos
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString() + "\t");
                }
                writer.write("\n");
            }

            JOptionPane.showMessageDialog(this, "Datos exportados exitosamente a TXT.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    private void mostrarDialogoFiltroInsumos() 
    {
    String[] opcionesFiltro = {"ID", "Nombre", "Unidad de Medida", "Cantidad", "Causa", "Puesto ID"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrdenInsumos(columnasSeleccionadas, ordenSeleccionado);
    }
}
    private void aplicarFiltroYOrdenInsumos(List<String> columnasSeleccionadas, String orden) {
    // Cargar todos los datos de insumos desde la base de datos
    List<Insumos1> insumos = insumosDAO.cargarDatos();

    // Ordenar la lista de insumos
    insumos.sort((i1, i2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(i1.getIdInsumos(), i2.getIdInsumos());
                    break;
                case "Nombre":
                    comparacion = i1.getNombre().compareTo(i2.getNombre());
                    break;
                case "Unidad de Medida":
                    comparacion = i1.getUm().compareTo(i2.getUm());
                    break;
                case "Cantidad":
                    comparacion = i1.getCantidad().compareTo(i2.getCantidad());
                    break;
                case "Causa":
                    comparacion = i1.getCausa().compareTo(i2.getCausa());
                    break;
                case "Puesto ID":
                    comparacion = Integer.compare(i1.getPuestoIdPuesto(), i2.getPuestoIdPuesto());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla dinámicamente basado en las columnas seleccionadas
    DefaultTableModel modeloTabla = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modeloTabla);

    // Llenar el modelo de la tabla con los datos filtrados y ordenados
    for (Insumos1 insumo : insumos) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(insumo.getIdInsumos());
                    break;
                case "Nombre":
                    fila.add(insumo.getNombre());
                    break;
                case "Unidad de Medida":
                    fila.add(insumo.getUm());
                    break;
                case "Cantidad":
                    fila.add(insumo.getCantidad());
                    break;
                case "Causa":
                    fila.add(insumo.getCausa());
                    break;
                case "Puesto ID":
                    fila.add(insumo.getPuestoIdPuesto());
                    break;
            }
        }
        modeloTabla.addRow(fila.toArray());
    }
}
    
    private void mostrarDialogoBusqueda() {
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Insumos", true);
    dialogoBusqueda.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;

    JTextField campoBusqueda = new JTextField();
    dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
    gbc.gridy++;
    dialogoBusqueda.add(campoBusqueda, gbc);

    String[] opcionesFiltro = {"ID Insumo", "Nombre", "U/M", "Cantidad", "Causa"};
    JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); 
        panelOpciones.add(checkBoxes[i]);
    }
    gbc.gridy++;
    gbc.gridwidth = 2;
    dialogoBusqueda.add(panelOpciones, gbc);

    JButton botonBuscar = new JButton("Buscar");
    gbc.gridwidth = 1;
    gbc.gridy++;
    gbc.gridx = 0;
    dialogoBusqueda.add(botonBuscar, gbc);

    botonBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String textoBusqueda = campoBusqueda.getText().trim();
            List<String> columnasSeleccionadas = new ArrayList<>();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    columnasSeleccionadas.add(checkBox.getText());
                }
            }
            List<Insumos1> resultadosBusqueda = buscarInsumos(textoBusqueda, columnasSeleccionadas);
            actualizarTablaConResultados(resultadosBusqueda);
            dialogoBusqueda.dispose();
        }
    });

    dialogoBusqueda.pack();
    dialogoBusqueda.setLocationRelativeTo(this);
    dialogoBusqueda.setVisible(true);
}

private List<Insumos1> buscarInsumos(String textoBusqueda, List<String> columnasSeleccionadas) {
    if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
        return insumosDAO.cargarDatos();
    }

    String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

    List<Insumos1> insumosList = insumosDAO.cargarDatos();

    return insumosList.stream()
            .filter(insumo -> {
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Insumo")) {
                    texto = String.valueOf(insumo.getIdInsumos()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Nombre")) {
                    texto = insumo.getNombre().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("U/M")) {
                    texto = insumo.getUm().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Cantidad")) {
                    texto = String.valueOf(insumo.getCantidad()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Causa")) {
                    texto = insumo.getCausa().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }

                return match;
            })
            .collect(Collectors.toList());
}

private void actualizarTablaConResultados(List<Insumos1> insumosFiltrados) {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    for (Insumos1 insumo : insumosFiltrados) {
        modeloTabla.addRow(new Object[]{
            insumo.getIdInsumos(),
            insumo.getNombre(),
            insumo.getUm(),
            insumo.getCantidad(),
            insumo.getCausa()
        });
    }
}


    private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(888, 604));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486503760-backup-disk-data-data-storage-floppy-save_81268.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Insumo", "Nombre", "U/M", "Cantidad", "Causa", "puestoid_puesto"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1023, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7)
                                .addGap(12, 12, 12)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(6, 6, 6))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
    jLabel4.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        agregarInsumo(); // Llamar al método para agregar insumo
    }
});
    // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
jLabel2.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        eliminarInsumo(); // Llamar al método para eliminar insumo
    }
});
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
jLabel1.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        modificarInsumo(); // Llamar al método para eliminar insumo
    }
});
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
 jLabel3.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        exportarDatosATxt(); // Llamar al método para agregar insumo
    }
});        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
jLabel5.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
    mostrarDialogoFiltroInsumos(); // Llamar al método para agregar insumo
    }
});      }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();    }
});               // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Insumos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Insumos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Insumos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Insumos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                SwingUtilities.invokeLater(() -> new Insumos().setVisible(true));
                new Insumos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
