package configuracion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase para manejar la conexión a la base de datos PostgreSQL.
 * 
 * @autor pango
 */
public class ConexionBD {
    
    private static final String URL = "jdbc:postgresql://localhost:5432/Caisa";
    private static final String USER = "postgres";
    private static final String PASSWORD = "24682468";
    
    private static Connection connection = null;

    // Método para obtener la conexión a la base de datos
    public static Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Conexión establecida con éxito.");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al conectar con la base de datos.");
            }
        }
        return connection;
    }

    // Método para cerrar la conexión a la base de datos
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                System.out.println("Conexión cerrada con éxito.");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al cerrar la conexión con la base de datos.");
            }
        }
    }

    // Método para preparar una declaración SQL
    public static PreparedStatement prepareStatement(String sql) throws SQLException {
        return getConnection().prepareStatement(sql);
    }
}
