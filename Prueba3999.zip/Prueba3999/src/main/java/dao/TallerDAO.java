package dao;
import configuracion.ConexionBD;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Taller;

public class TallerDAO {

    private Connection getConnection() throws SQLException {
        // Cambia estos parámetros por los de tu configuración
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Caisa", "postgres", "24682468");
    }

public List<Taller> cargarDatos() {
    return cargarDatos(""); // Llamar al método con un filtro vacío
}

public List<Taller> cargarDatos(String textoFiltro) {
    List<Taller> talleres = new ArrayList<>();
    Connection conexion = ConexionBD.getConnection();

    if (conexion == null) {
        JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return talleres;
    }

    String sql = "SELECT id_taller, nombre_taller FROM taller WHERE LOWER(nombre_taller) LIKE ?";

    try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
        preparedStatement.setString(1, "%" + textoFiltro.toLowerCase() + "%");
        ResultSet resultSet = preparedStatement.executeQuery();

        while (resultSet.next()) {
            int idTaller = resultSet.getInt("id_taller");
            String nombreTaller = resultSet.getString("nombre_taller");
            talleres.add(new Taller(idTaller, nombreTaller));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener los datos de la tabla Taller.", "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        ConexionBD.closeConnection();
    }

    return talleres;
}

    public boolean agregarTaller(Taller taller) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "INSERT INTO taller (nombre_taller) VALUES (?)";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, taller.getNombreTaller());

            int filasAfectadas = preparedStatement.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al agregar el taller.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }

    public boolean eliminarTaller(int idTaller) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "DELETE FROM taller WHERE id_taller = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, idTaller);

            int filasAfectadas = preparedStatement.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al eliminar el taller.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }
 
    public Taller obtenerTallerPorId(int idTaller) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        String sql = "SELECT id_taller, nombre_taller FROM taller WHERE id_taller = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, idTaller);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String nombreTaller = resultSet.getString("nombre_taller");

                return new Taller(idTaller, nombreTaller);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener el taller.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return null;
    }

    public boolean actualizarTaller(Taller taller) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "UPDATE taller SET nombre_taller = ? WHERE id_taller = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, taller.getNombreTaller());
            preparedStatement.setInt(2, taller.getIdTaller());

            int filasAfectadas = preparedStatement.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar el taller.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }

 public void exportarTallerATxt(File archivo) throws IOException {
        String sql = "SELECT id_taller, nombre_taller FROM taller";

        try (Connection conexion = getConnection();
             PreparedStatement preparedStatement = conexion.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery();
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {

            // Escribir encabezados
            writer.write("ID Taller\tNombre Taller");
            writer.newLine();

            // Escribir filas de datos
            while (resultSet.next()) {
                int idTaller = resultSet.getInt("id_taller");
                String nombreTaller = resultSet.getString("nombre_taller");

                writer.write(idTaller + "\t" + nombreTaller);
                writer.newLine();
            }

            JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a TXT.");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
