/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;


import model.Puesto;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PuestoDAO {

    private Connection getConnection() throws SQLException {
        // Cambia estos parámetros por los de tu configuración
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Caisa", "postgres", "24682468");
    }

   
public List<Puesto> cargarDatos() {
        List<Puesto> listaPuestos = new ArrayList<>();
        String query = "SELECT * FROM puesto";

        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int idPuesto = rs.getInt("id_puesto");
                String nombrePuesto = rs.getString("nombre_puesto");
                String puesto = rs.getString("puesto");
                int grupo = rs.getInt("grupo");
                int tallerIdTaller = rs.getInt("tallerid_taller");

                listaPuestos.add(new Puesto(idPuesto, nombrePuesto, puesto, grupo, tallerIdTaller));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaPuestos;
    }

public boolean agregarPuesto(Puesto puesto) {
    String query = "INSERT INTO puesto (nombre_puesto, puesto, grupo, tallerid_taller) VALUES (?, ?, ?, ?)";

    try (Connection connection = getConnection();
         PreparedStatement pstmt = connection.prepareStatement(query)) {
        pstmt.setString(1, puesto.getNombrePuesto());
        pstmt.setString(2, puesto.getPuesto());
        pstmt.setInt(3, puesto.getGrupo());
        pstmt.setInt(4, puesto.getTallerIdTaller());

        return pstmt.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

public boolean eliminarPuesto(int idPuesto) {
        String query = "DELETE FROM puesto WHERE id_puesto = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, idPuesto);
            int rowsAffected = stmt.executeUpdate();

            return rowsAffected > 0; // Retorna true si se eliminó al menos una fila
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores en la conexión a la base de datos
            return false;
        }
    }

public boolean actualizarPuesto(Puesto puesto) {
    String query = "UPDATE puesto SET nombre_puesto = ?, puesto = ?, grupo = ?, tallerid_taller = ? WHERE id_puesto = ?";

    try (Connection connection = getConnection();
         PreparedStatement pstmt = connection.prepareStatement(query)) {
        pstmt.setString(1, puesto.getNombrePuesto());
        pstmt.setString(2, puesto.getPuesto());
        pstmt.setInt(3, puesto.getGrupo());
        pstmt.setInt(4, puesto.getTallerIdTaller());
        pstmt.setInt(5, puesto.getIdPuesto());

        return pstmt.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

public Puesto obtenerPuestoPorId(int idPuesto) {
    String query = "SELECT * FROM puesto WHERE id_puesto = ?";
    try (Connection connection = getConnection();
         PreparedStatement pstmt = connection.prepareStatement(query)) {
        pstmt.setInt(1, idPuesto);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            String nombrePuesto = rs.getString("nombre_puesto");
            String puesto = rs.getString("puesto");
            int grupo = rs.getInt("grupo");
            int tallerIdTaller = rs.getInt("tallerid_taller");

            return new Puesto(idPuesto, nombrePuesto, puesto, grupo, tallerIdTaller);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

public boolean exportarDatosAArchivoTxt(String rutaArchivo) {
        List<Puesto> listaPuestos = cargarDatos();

        try (PrintWriter writer = new PrintWriter(new FileWriter(rutaArchivo))) {
            writer.println("ID Puesto | Nombre Puesto | Puesto | Grupo | ID Taller");
            writer.println("------------------------------------------------------------");

            for (Puesto puesto : listaPuestos) {
                writer.printf("%d | %s | %s | %d | %d%n",
                        puesto.getIdPuesto(),
                        puesto.getNombrePuesto(),
                        puesto.getPuesto(),
                        puesto.getGrupo(),
                        puesto.getTallerIdTaller());
            }

            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Métodos para agregar, eliminar y actualizar puestos pueden ser añadidos aquí.
}
