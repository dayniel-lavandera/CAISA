package dao;

import configuracion.ConexionBD;
import static configuracion.ConexionBD.getConnection;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import model.Operacion;

public class OperacionesDAO {

    private Connection getConnection() throws SQLException {
        // Cambia estos parámetros por los de tu configuración
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Caisa", "postgres", "24682468");
    }

 
    public List<Operacion> cargarDatos() {
        List<Operacion> operaciones = new ArrayList<>();
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return operaciones;
        }

        String sql = "SELECT id_operaciones, nombre_operacion, descripcion FROM operaciones";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int idOperacion = resultSet.getInt("id_operaciones");
                String nombreOperacion = resultSet.getString("nombre_operacion");
                String descripcion = resultSet.getString("descripcion");

                operaciones.add(new Operacion(idOperacion, nombreOperacion, descripcion));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener los datos de la tabla Operaciones.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return operaciones;
    }
    
    public boolean agregarOperacion(Operacion operacion) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "INSERT INTO operaciones (nombre_operacion, descripcion) VALUES (?, ?)";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, operacion.getNombreOperacion());
            preparedStatement.setString(2, operacion.getDescripcion());

            int filasAfectadas = preparedStatement.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al agregar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }

    public boolean eliminarOperacion(int idOperacion) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "DELETE FROM operaciones WHERE id_operaciones = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, idOperacion);

            int filasAfectadas = preparedStatement.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al eliminar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }

    public Operacion obtenerOperacionPorId(int idOperacion) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        String sql = "SELECT id_operaciones, nombre_operacion, descripcion FROM operaciones WHERE id_operaciones = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, idOperacion);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String nombreOperacion = resultSet.getString("nombre_operacion");
                String descripcion = resultSet.getString("descripcion");

                return new Operacion(idOperacion, nombreOperacion, descripcion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener la operación.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return null;
    }

    public boolean actualizarOperacion(Operacion operacion) {
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "UPDATE operaciones SET nombre_operacion = ?, descripcion = ? WHERE id_operaciones = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, operacion.getNombreOperacion());
            preparedStatement.setString(2, operacion.getDescripcion());
            preparedStatement.setInt(3, operacion.getIdOperacion());

            int filasAfectadas = preparedStatement.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar la operación.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }

      public void exportarOperacionesATxt(File archivo) {
        String sql = "SELECT id_operaciones, nombre_operacion, descripcion FROM operaciones";

        try (Connection conexion = getConnection();
             PreparedStatement preparedStatement = conexion.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery();
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {

            // Escribir encabezados
            writer.write("ID Operación\tNombre Operación\tDescripción");
            writer.newLine();

            // Escribir filas de datos
            while (resultSet.next()) {
                int idOperacion = resultSet.getInt("id_operaciones");
                String nombreOperacion = resultSet.getString("nombre_operacion");
                String descripcion = resultSet.getString("descripcion");

                writer.write(idOperacion + "\t" + nombreOperacion + "\t" + descripcion);
                writer.newLine();
            }

            JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a TXT.");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



}