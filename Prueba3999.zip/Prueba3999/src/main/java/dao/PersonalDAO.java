package dao;

import configuracion.ConexionBD;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import model.Personal;

public class PersonalDAO {

    private Connection getConnection() throws SQLException {
        // Cambia estos parámetros por los de tu configuración
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Caisa", "postgres", "24682468");
    }


public List<Personal> obtenerPersonal() {
        List<Personal> listaPersonal = new ArrayList<>();
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return listaPersonal;
        }

        String sql = "SELECT id_personal, personal, cantidad FROM personal";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                String idPersonal = resultSet.getString("id_personal");
                String nombre = resultSet.getString("personal");
                BigDecimal cantidad = resultSet.getBigDecimal("cantidad");

                listaPersonal.add(new Personal(idPersonal, nombre, cantidad));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener los datos de la tabla Personal.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return listaPersonal;
    }

public boolean agregarPersonal(Personal personal) {
    Connection conexion = ConexionBD.getConnection();
    if (conexion == null) {
        JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    String sql = "INSERT INTO personal (id_personal, personal, cantidad) VALUES (?, ?, ?)";
    try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
        pstmt.setString(1, personal.getIdPersonal());
        pstmt.setString(2, personal.getNombre());
        pstmt.setBigDecimal(3, personal.getCantidad());
        int affectedRows = pstmt.executeUpdate();
        return affectedRows > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al agregar el personal: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    } finally {
        ConexionBD.closeConnection();
    }
}
 
public Personal obtenerPersonalPorId(String idPersonal) {
        Personal personal = null;
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        String sql = "SELECT id_personal, personal, cantidad FROM personal WHERE id_personal = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, idPersonal);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String nombre = resultSet.getString("personal");
                BigDecimal cantidad = resultSet.getBigDecimal("cantidad");

                personal = new Personal(idPersonal, nombre, cantidad);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener los datos del personal.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return personal;
    }

public boolean actualizarPersonal(Personal personal) {
        boolean exito = false;
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "UPDATE personal SET personal = ?, cantidad = ? WHERE id_personal = ?";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, personal.getNombre());
            preparedStatement.setBigDecimal(2, personal.getCantidad());
            preparedStatement.setString(3, personal.getIdPersonal());

            int filasAfectadas = preparedStatement.executeUpdate();
            exito = filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar los datos del personal.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return exito;
    }
    
public boolean eliminarPersonal(String idPersonal) {
    Connection conexion = ConexionBD.getConnection();
    if (conexion == null) {
        JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    String sql = "DELETE FROM personal WHERE id_personal = ?";
    try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
        pstmt.setString(1, idPersonal);
        int affectedRows = pstmt.executeUpdate();
        return affectedRows > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al eliminar el personal: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    } finally {
        ConexionBD.closeConnection();
    }
    }

public static void exportarDatosATxt(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar como");
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileChooser.getSelectedFile() + ".txt"))) {
                TableModel model = table.getModel();

                // Escribir encabezados
                for (int i = 0; i < model.getColumnCount(); i++) {
                    writer.write(model.getColumnName(i) + "\t");
                }
                writer.write("\n");

                // Escribir filas de datos
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        writer.write(model.getValueAt(i, j).toString() + "\t");
                    }
                    writer.write("\n");
                }

                JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a TXT.");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }



}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

