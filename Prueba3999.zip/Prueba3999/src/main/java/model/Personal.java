package model;

import java.math.BigDecimal;

public class Personal {
    private String idPersonal;
    private String nombre;
    private BigDecimal cantidad;

    // Constructor
    public Personal(String idPersonal, String nombre, BigDecimal cantidad) {
        this.idPersonal = idPersonal;
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public String getIdPersonal() {
        return idPersonal;
    }

    public void setIdPersonal(String idPersonal) {
        this.idPersonal = idPersonal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigDecimal cantidad) {
        this.cantidad = cantidad;
    }
}
