/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author JuanMi025
 */


public class Puesto {
    private int idPuesto;
    private String nombrePuesto;
    private String puesto;
    private int grupo;
    private int tallerIdTaller;

    public Puesto(int idPuesto, String nombrePuesto, String puesto, int grupo, int tallerIdTaller) {
        this.idPuesto = idPuesto;
        this.nombrePuesto = nombrePuesto;
        this.puesto = puesto;
        this.grupo = grupo;
        this.tallerIdTaller = tallerIdTaller;
    }

    // Getters y Setters

    public int getIdPuesto() {
        return idPuesto;
    }

    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }

    public String getNombrePuesto() {
        return nombrePuesto;
    }

    public void setNombrePuesto(String nombrePuesto) {
        this.nombrePuesto = nombrePuesto;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public int getGrupo() {
        return grupo;
    }

    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }

    public int getTallerIdTaller() {
        return tallerIdTaller;
    }

    public void setTallerIdTaller(int tallerIdTaller) {
        this.tallerIdTaller = tallerIdTaller;
    }

    @Override
    public String toString() {
        return "Puesto{" +
                "idPuesto=" + idPuesto +
                ", nombrePuesto='" + nombrePuesto + '\'' +
                ", puesto='" + puesto + '\'' +
                ", grupo=" + grupo +
                ", tallerIdTaller=" + tallerIdTaller +
                '}';
    }
}

