package model;

import java.math.BigDecimal;

public class Insumos1 {
    private int idInsumos;
    private String nombre;
    private String um;
    private BigDecimal cantidad;
    private String causa;
    private int puestoIdPuesto;

  public Insumos1(int idInsumos, String nombre, String um, BigDecimal cantidad, String causa, int puestoIdPuesto) {
    this.idInsumos = idInsumos;
    this.nombre = nombre;
    this.um = um;
    this.cantidad = cantidad; // Inicializa cantidad correctamente
    this.causa = causa;
    this.puestoIdPuesto = puestoIdPuesto;


}

    


    // Getters and Setters
    public int getIdInsumos() { return idInsumos; }
    public void setIdInsumos(int idInsumos) { this.idInsumos = idInsumos; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getUm() { return um; }
    public void setUm(String um) { this.um = um; }

    public BigDecimal getCantidad() { return cantidad; }
    public void setCantidad(BigDecimal cantidad) { this.cantidad = cantidad; }

    public String getCausa() { return causa; }
    public void setCausa(String causa) { this.causa = causa; }

    public int getPuestoIdPuesto() { return puestoIdPuesto; }
    public void setPuestoIdPuesto(int puestoIdPuesto) { this.puestoIdPuesto = puestoIdPuesto; }
}
