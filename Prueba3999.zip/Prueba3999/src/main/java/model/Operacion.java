package model;
public class Operacion {
    private int idOperacion;
    private String nombreOperacion;
    private String descripcion;

    public Operacion(int idOperacion, String nombreOperacion, String descripcion) {
        this.idOperacion = idOperacion;
        this.nombreOperacion = nombreOperacion;
        this.descripcion = descripcion;
    }

    // Métodos get
    public int getIdOperacion() {
        return idOperacion;
    }

    public String getNombreOperacion() {
        return nombreOperacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    // Métodos set
    public void setIdOperacion(int idOperacion) {
        this.idOperacion = idOperacion;
    }

    public void setNombreOperacion(String nombreOperacion) {
        this.nombreOperacion = nombreOperacion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
