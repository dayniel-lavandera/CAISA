package servicio;

import com.unah.modelos.Usuario;
import dao.LoginDAO;

public class LoginService {
    
    private LoginDAO loginDAO;
    
    public LoginService() {
        this.loginDAO = new LoginDAO();
    }public String login(String username, String password) {
    // Buscar el usuario por nombre de usuario
    Usuario usuario = loginDAO.buscarUsuarioPorUsername(username);
    
    // Si el usuario es encontrado y la contraseña coincide
    if (usuario != null && usuario.getPassword().equals(password)) {
        return usuario.getRol().toString(); // Convertir el rol a String
    }
    
    return null; // Inicio de sesión fallido
}

    
    public Usuario getUsuario(String username){
        return loginDAO.buscarUsuarioPorUsername(username);
    }
}
