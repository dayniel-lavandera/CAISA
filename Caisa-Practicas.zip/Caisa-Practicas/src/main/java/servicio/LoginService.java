package servicio;

import dao.LoginDAO;
import com.unah.modelos.Usuario;

/**
 *
 * @author pango
 */
public class LoginService {
    
    private LoginDAO loginDAO;
    
    public LoginService() {
        this.loginDAO = new LoginDAO();
    }

    public boolean login(String username, String password) {
        // Buscar el usuario por nombre de usuario
        Usuario usuario = loginDAO.buscarUsuarioPorUsername(username);
        
        // Si el usuario es encontrado y la contraseña coincide
        if (usuario != null && usuario.getPassword().equals(password)) {
            return true; // Inicio de sesión exitoso
        }
        
        return false; // Inicio de sesión fallido
    }
    
    public Usuario getUsuario(String username){
        return loginDAO.buscarUsuarioPorUsername(username);
        
    }
        
}
