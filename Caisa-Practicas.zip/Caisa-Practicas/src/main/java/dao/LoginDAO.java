
package dao;

import com.unah.modelos.Role;
import com.unah.modelos.Usuario;
import configuracion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author pango
 */
public class LoginDAO {
    
    Connection connection = null;
    
    public Usuario buscarUsuarioPorUsername(String username) {
        
        String SELECT_USER_BY_USERNAME = "SELECT * FROM usuarios WHERE username = ?";
        Usuario usuario = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = ConexionBD.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_USER_BY_USERNAME);
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int idUser = resultSet.getInt("idUser");
                String retrievedUsername = resultSet.getString("username");
                String password = resultSet.getString("password");
                String rolString = resultSet.getString("rol");
                Role rol = Role.valueOf(rolString.toUpperCase());

                usuario = new Usuario(idUser, retrievedUsername, password, rol);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    ConexionBD.closeConnection();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return usuario;
    }
    
    
    
    
    
}
