/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Taller {
    private int idTaller;
    private String nombreTaller;

    public Taller(int idTaller, String nombreTaller) {
        this.idTaller = idTaller;
        this.nombreTaller = nombreTaller;
    }

    // Métodos get
    public int getIdTaller() {
        return idTaller;
    }

    public String getNombreTaller() {
        return nombreTaller;
    }

    // Métodos set
    public void setIdTaller(int idTaller) {
        this.idTaller = idTaller;
    }

    public void setNombreTaller(String nombreTaller) {
        this.nombreTaller = nombreTaller;
    }
}
