/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Pieza {
    private int id_pieza;
    private int numero;
    private int codigo;
    private int cantidad;
    private int diseño;
    private String control_fisico;
    private String observaciones;
    private int sobrante;
    private String causa;
    private int puestoid_puesto;
    private int operacionesid_operaciones;
    private int puestoid_puesto2;

    // Constructor con todos los parámetros
    public Pieza(int id_pieza, int numero, int codigo, int cantidad, int diseño,
                 String control_fisico, String observaciones, int sobrante, String causa,
                 int puestoid_puesto, int operacionesid_operaciones, int puestoid_puesto2) {
        this.id_pieza = id_pieza;
        this.numero = numero;
        this.codigo = codigo;
        this.cantidad = cantidad;
        this.diseño = diseño;
        this.control_fisico = control_fisico;
        this.observaciones = observaciones;
        this.sobrante = sobrante;
        this.causa = causa;
        this.puestoid_puesto = puestoid_puesto;
        this.operacionesid_operaciones = operacionesid_operaciones;
        this.puestoid_puesto2 = puestoid_puesto2;
    }

    // Getters and Setters
    public int getIdPieza() { return id_pieza; }
    public void setIdPieza(int idPieza) { this.id_pieza = idPieza; }
    public int getNumero() { return numero; }
    public void setNumero(int numero) { this.numero = numero; }
    public int getCodigo() { return codigo; }
    public void setCodigo(int codigo) { this.codigo = codigo; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public int getDiseño() { return diseño; }
    public void setDiseño(int diseño) { this.diseño = diseño; }
    public String getControlFisico() { return control_fisico; }
    public void setControlFisico(String controlFisico) { this.control_fisico = controlFisico; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
    public int getSobrante() { return sobrante; }
    public void setSobrante(int sobrante) { this.sobrante = sobrante; }
    public String getCausa() { return causa; }
    public void setCausa(String causa) { this.causa = causa; }
    public int getPuestoIdPuesto() { return puestoid_puesto; }
    public void setPuestoIdPuesto(int puestoIdPuesto) { this.puestoid_puesto = puestoIdPuesto; }
    public int getOperacionesIdOperaciones() { return operacionesid_operaciones; }
    public void setOperacionesIdOperaciones(int operacionesIdOperaciones) { this.operacionesid_operaciones = operacionesIdOperaciones; }
    public int getPuestoIdPuesto2() { return puestoid_puesto2; }
    public void setPuestoIdPuesto2(int puestoIdPuesto2) { this.puestoid_puesto2 = puestoIdPuesto2; }
}
