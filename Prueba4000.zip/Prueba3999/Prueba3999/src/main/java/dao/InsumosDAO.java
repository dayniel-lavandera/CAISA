package dao;

import configuracion.ConexionBD;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import model.Insumos1;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

public class InsumosDAO {
 
  

public List<Insumos1> cargarDatos() {
    List<Insumos1> insumos = new ArrayList<>();
    Connection conexion = ConexionBD.getConnection();

    if (conexion == null) {
        JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return insumos;
    }

    // Usa comillas dobles para el nombre de la columna con caracteres especiales
    String sql = "SELECT id_insumos, nombre, \"U/M\", cantidad, causa, puestoid_puesto FROM insumos";

    try (PreparedStatement preparedStatement = conexion.prepareStatement(sql);
         ResultSet resultSet = preparedStatement.executeQuery()) {

        while (resultSet.next()) {
            int idInsumos = resultSet.getInt("id_insumos");
            String nombre = resultSet.getString("nombre");
            String um = resultSet.getString("U/M");
            BigDecimal cantidad = resultSet.getBigDecimal("cantidad"); // Asegúrate de que esto sea BigDecimal
            String causa = resultSet.getString("causa");
            int puestoIdPuesto = resultSet.getInt("puestoid_puesto");

            // Usa el constructor adecuado
            insumos.add(new Insumos1(idInsumos, nombre, um, cantidad, causa, puestoIdPuesto));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener los datos de la tabla Insumos.", "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        ConexionBD.closeConnection();
    }

    return insumos;
}

public boolean agregarInsumo(Insumos1 insumo) {
        Connection conexion = ConexionBD.getConnection();
        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Usa comillas dobles para el nombre de la columna con caracteres especiales
        String sql = "INSERT INTO insumos (nombre, \"U/M\", cantidad, causa, puestoid_puesto) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql)) {
            preparedStatement.setString(1, insumo.getNombre());
            preparedStatement.setString(2, insumo.getUm());
            preparedStatement.setBigDecimal(3, insumo.getCantidad());
            preparedStatement.setString(4, insumo.getCausa());
            preparedStatement.setInt(5, insumo.getPuestoIdPuesto());

            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al agregar el insumo.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            ConexionBD.closeConnection();
        }
    }

public boolean eliminarInsumo(int idInsumo) {
    Connection conexion = null;
    PreparedStatement preparedStatement = null;

    try {
        conexion = ConexionBD.getConnection();
        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "DELETE FROM insumos WHERE id_insumos = ?";
        preparedStatement = conexion.prepareStatement(sql);
        preparedStatement.setInt(1, idInsumo);

        int rowsDeleted = preparedStatement.executeUpdate();
        return rowsDeleted > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al eliminar el insumo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    } finally {
        // Cerrar PreparedStatement y Connection
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conexion != null) {
            ConexionBD.closeConnection();
        }}}

public boolean actualizarInsumo(Insumos1 insumo) {
    Connection conexion = null;
    PreparedStatement preparedStatement = null;

    try {
        conexion = ConexionBD.getConnection();
        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Usa comillas dobles para el nombre de la columna con caracteres especiales
        String sql = "UPDATE insumos SET nombre = ?, \"U/M\" = ?, cantidad = ?, causa = ?, puestoid_puesto = ? WHERE id_insumos = ?";

        preparedStatement = conexion.prepareStatement(sql);
        preparedStatement.setString(1, insumo.getNombre());
        preparedStatement.setString(2, insumo.getUm());
        preparedStatement.setBigDecimal(3, insumo.getCantidad());
        preparedStatement.setString(4, insumo.getCausa());
        preparedStatement.setInt(5, insumo.getPuestoIdPuesto());
        preparedStatement.setInt(6, insumo.getIdInsumos());

        int rowsUpdated = preparedStatement.executeUpdate();
        return rowsUpdated > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al actualizar el insumo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    } finally {
        // Asegúrate de cerrar PreparedStatement y Connection
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conexion != null) {
            ConexionBD.closeConnection();
        }
    }
}

public Insumos1 obtenerInsumoPorId(int idInsumo) {
    Connection conexion = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    Insumos1 insumo = null;

    try {
        conexion = ConexionBD.getConnection();
        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        String sql = "SELECT id_insumos, nombre, \"U/M\", cantidad, causa, puestoid_puesto FROM insumos WHERE id_insumos = ?";
        preparedStatement = conexion.prepareStatement(sql);
        preparedStatement.setInt(1, idInsumo);

        resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            int id = resultSet.getInt("id_insumos");
            String nombre = resultSet.getString("nombre");
            String um = resultSet.getString("U/M");
            BigDecimal cantidad = resultSet.getBigDecimal("cantidad");
            String causa = resultSet.getString("causa");
            int puestoIdPuesto = resultSet.getInt("puestoid_puesto");

            insumo = new Insumos1(id, nombre, um, cantidad, causa, puestoIdPuesto);
        } else {
            JOptionPane.showMessageDialog(null, "Insumo no encontrado para el ID proporcionado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener el insumo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        // Asegúrate de cerrar ResultSet, PreparedStatement y Connection
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conexion != null) {
            ConexionBD.closeConnection();
        }
    }

    return insumo;
}

public static void exportarDatosATxt(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar como");
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileChooser.getSelectedFile() + ".txt"))) {
                TableModel model = table.getModel();

                // Escribir encabezados
                for (int i = 0; i < model.getColumnCount(); i++) {
                    writer.write(model.getColumnName(i) + "\t");
                }
                writer.write("\n");

                // Escribir filas de datos
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        writer.write(model.getValueAt(i, j).toString() + "\t");
                    }
                    writer.write("\n");
                }

                JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a TXT.");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}

