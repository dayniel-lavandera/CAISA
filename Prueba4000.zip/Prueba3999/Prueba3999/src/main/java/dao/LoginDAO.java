package dao;

import com.unah.modelos.Role;
import com.unah.modelos.Usuario;
import configuracion.ConexionBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class LoginDAO {

private Connection getConnection() throws SQLException {
        // Cambia estos parámetros por los de tu configuración
        return DriverManager.getConnection("jdbc:postgresql://localhost:5433/Caisa", "postgres", "03012564025");
    }

public Usuario buscarUsuarioPorUsername(String username) {
    String SELECT_USER_BY_USERNAME = "SELECT id_usuario, nombre, password, \"Rol\" FROM \"Usuarios\" WHERE nombre = ?";
    Usuario usuario = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    try {
        connection = ConexionBD.getConnection();
        if (connection == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        preparedStatement = connection.prepareStatement(SELECT_USER_BY_USERNAME);
        preparedStatement.setString(1, username);
        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int idUser = resultSet.getInt("id_usuario");
            String retrievedUsername = resultSet.getString("nombre");
            String password = resultSet.getString("password");
            String rolString = resultSet.getString("Rol");
            Role rol = Role.valueOf(rolString.toUpperCase());

            usuario = new Usuario(idUser, retrievedUsername, password, rol);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al buscar el usuario por nombre de usuario.", "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                ConexionBD.closeConnection();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    return usuario;
}

}