/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.unah.caisa.practicas;

/**
 *
 * @author JuanMi025
 */
public class Prueba3999 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Inicio inicio=new Inicio();
       inicio.setVisible(true);
    }
    
}
