/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vista;


import dao.PersonalDAO;
import dao.PiezaDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Pieza;



/**
 *
 * @author pango
 */
public class Control_piezas extends javax.swing.JFrame {
 private PiezaDAO piezaDAO;
    /**
     * Creates new form Control_piezas
     */
    public Control_piezas() {
        initComponents();
    piezaDAO = new PiezaDAO(); // Crea una instancia del DAO
        cargarDatosTabla();
    actualizarTabla();
    
    }
private void cargarDatosTabla() {
    // Verifica que jTable1 no sea null
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

    // Obtén el modelo de la tabla
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Obtener los datos desde el DAO
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Definir los nombres de las columnas
    String[] columnNames = {"ID", "Número", "Código", "Cantidad", "Diseño", "Control Físico", "Observaciones", "Sobrante", "Causa", "Puesto ID", "Operaciones ID", "Puesto ID 2"};

    // Crear el modelo de la tabla con los nombres de las columnas
    DefaultTableModel modelo = new DefaultTableModel(columnNames, 0);
    jTable1.setModel(modelo);

    // Agregar los datos al modelo de la tabla
    for (Pieza pieza : listaPiezas) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}

   private void agregarPieza() {
    // Solicitar información al usuario
    String numeroStr = JOptionPane.showInputDialog("Ingrese el número de la pieza:");
    String codigoStr = JOptionPane.showInputDialog("Ingrese el código de la pieza:");
    String cantidadStr = JOptionPane.showInputDialog("Ingrese la cantidad:");
    String diseñoStr = JOptionPane.showInputDialog("Ingrese el diseño:");
    String controlFisico = JOptionPane.showInputDialog("Ingrese el control físico:");
    String observaciones = JOptionPane.showInputDialog("Ingrese observaciones:");
    String sobranteStr = JOptionPane.showInputDialog("Ingrese el sobrante:");
    String causa = JOptionPane.showInputDialog("Ingrese la causa:");
    String puestoidPuestoStr = JOptionPane.showInputDialog("Ingrese el ID del puesto:");
    String operacionesidOperacionesStr = JOptionPane.showInputDialog("Ingrese el ID de operaciones:");
    String puestoidPuesto2Str = JOptionPane.showInputDialog("Ingrese el ID del segundo puesto:");

    // Verificar que los datos no sean null
    if (numeroStr != null && codigoStr != null && cantidadStr != null && diseñoStr != null &&
        controlFisico != null && observaciones != null && sobranteStr != null &&
        causa != null && puestoidPuestoStr != null && operacionesidOperacionesStr != null &&
        puestoidPuesto2Str != null) {
        try {
            int numero = Integer.parseInt(numeroStr);
            int codigo = Integer.parseInt(codigoStr);
            int cantidad = Integer.parseInt(cantidadStr);
            int diseño = Integer.parseInt(diseñoStr);
            int sobrante = Integer.parseInt(sobranteStr);
            int puestoidPuesto = Integer.parseInt(puestoidPuestoStr);
            int operacionesidOperaciones = Integer.parseInt(operacionesidOperacionesStr);
            int puestoidPuesto2 = Integer.parseInt(puestoidPuesto2Str);

            // Crear el objeto Pieza
            Pieza nuevaPieza = new Pieza(0, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoidPuesto, operacionesidOperaciones, puestoidPuesto2);

            // Llamar al DAO para agregar la pieza
            boolean exito = piezaDAO.agregarPieza(nuevaPieza);

            // Informar al usuario del resultado
            if (exito) {
                JOptionPane.showMessageDialog(null, "Pieza agregada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
                // Aquí puedes cerrar la ventana de entrada si está abierta, o resetear el formulario
                // Por ejemplo, si usas un JFrame o JDialog para la entrada, podrías hacer algo así:
                // this.dispose(); // Cerrar el JFrame actual (si corresponde)
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar la pieza.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Todos los campos numéricos deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar todos los datos. La operación de agregar ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void eliminarPieza() {
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID de la pieza que desea eliminar:", "Eliminar Pieza", JOptionPane.QUESTION_MESSAGE);

    if (input != null && !input.trim().isEmpty()) {
        try {
            int idPieza = Integer.parseInt(input.trim());

            int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar la pieza con ID " + idPieza + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                boolean exito = piezaDAO.eliminarPieza(idPieza);

                if (exito) {
                    JOptionPane.showMessageDialog(null, "Pieza eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                    // Actualizar la tabla después de eliminar la pieza
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    for (int i = 0; i < model.getRowCount(); i++) {
                        if ((int) model.getValueAt(i, 0) == idPieza) {
                            model.removeRow(i);
                            break;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar la pieza. Verifique si el ID es correcto o si existen dependencias.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de eliminación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
    private void modificarPieza() {
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID de la pieza que desea modificar:", "Modificar Pieza", JOptionPane.QUESTION_MESSAGE);

    if (input != null && !input.trim().isEmpty()) {
        try {
            int idPieza = Integer.parseInt(input.trim());

            // Aquí debes obtener los nuevos datos para la pieza. Simplificamos con valores fijos.
            Pieza piezaModificada = new Pieza(idPieza, 123, 456, 10, 789, "Control OK", "Observación actualizada", 5, "Causa actualizada", 1, 2, 3);

            boolean exito = piezaDAO.actualizarPieza(piezaModificada);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Pieza modificada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar la pieza. Verifique el ID y los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de modificación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
private void exportarDatosATxt() {
    // Solicitar el nombre del archivo al usuario
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(null);

    if (userSelection != JFileChooser.APPROVE_OPTION) {
        return; // Usuario canceló la operación
    }

    File fileToSave = fileChooser.getSelectedFile();
    
    // Verificar si el archivo ya tiene una extensión
    String filePath = fileToSave.getPath();
    if (!filePath.endsWith(".txt")) {
        filePath += ".txt";
    }

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        // Obtener el modelo de la tabla
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();

        // Escribir los nombres de las columnas
        for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
            writer.write(modeloTabla.getColumnName(i));
            if (i < modeloTabla.getColumnCount() - 1) {
                writer.write("\t"); // Separar columnas por tabulador
            }
        }
        writer.newLine();

        // Escribir los datos de las filas
        for (int row = 0; row < modeloTabla.getRowCount(); row++) {
            for (int col = 0; col < modeloTabla.getColumnCount(); col++) {
                writer.write(modeloTabla.getValueAt(row, col).toString());
                if (col < modeloTabla.getColumnCount() - 1) {
                    writer.write("\t"); // Separar columnas por tabulador
                }
            }
            writer.newLine();
        }

        JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a " + filePath, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(null, "Error al exportar los datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void mostrarDialogoFiltro() {
    String[] opcionesFiltro = {"ID", "Número", "Código", "Cantidad", "Diseño"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrden(columnasSeleccionadas, ordenSeleccionado);
    }
}
private void aplicarFiltroYOrden(List<String> columnasSeleccionadas, String orden) {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Ordenar la lista
    listaPiezas.sort((p1, p2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(p1.getIdPieza(), p2.getIdPieza());
                    break;
                case "Número":
                    comparacion = Integer.compare(p1.getNumero(), p2.getNumero());
                    break;
                case "Código":
                    comparacion = Integer.compare(p1.getCodigo(), p2.getCodigo());
                    break;
                case "Cantidad":
                    comparacion = Integer.compare(p1.getCantidad(), p2.getCantidad());
                    break;
                case "Diseño":
                    comparacion = Integer.compare(p1.getDiseño(), p2.getDiseño());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla con las columnas seleccionadas
    DefaultTableModel modelo = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modelo);

    // Agregar los datos filtrados y ordenados al modelo de la tabla
    for (Pieza pieza : listaPiezas) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(pieza.getIdPieza());
                    break;
                case "Número":
                    fila.add(pieza.getNumero());
                    break;
                case "Código":
                    fila.add(pieza.getCodigo());
                    break;
                case "Cantidad":
                    fila.add(pieza.getCantidad());
                    break;
                case "Diseño":
                    fila.add(pieza.getDiseño());
                    break;
            }
        }
        modelo.addRow(fila.toArray());
    }
}
private void actualizarTabla() {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Obtener el modelo de la tabla actual
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();

    // Crear un mapa para buscar piezas por ID
    Map<Integer, Pieza> mapaPiezas = new HashMap<>();
    for (Pieza pieza : listaPiezas) {
        mapaPiezas.put(pieza.getIdPieza(), pieza);
    }

    // Actualizar las filas existentes
    for (int i = 0; i < modelo.getRowCount(); i++) {
        int idPieza = (int) modelo.getValueAt(i, 0);
        Pieza pieza = mapaPiezas.get(idPieza);
        if (pieza != null) {
            modelo.setValueAt(pieza.getNumero(), i, 1);
            modelo.setValueAt(pieza.getCodigo(), i, 2);
            modelo.setValueAt(pieza.getCantidad(), i, 3);
            modelo.setValueAt(pieza.getDiseño(), i, 4);
            modelo.setValueAt(pieza.getControlFisico(), i, 5);
            modelo.setValueAt(pieza.getObservaciones(), i, 6);
            modelo.setValueAt(pieza.getSobrante(), i, 7);
            modelo.setValueAt(pieza.getCausa(), i, 8);
            modelo.setValueAt(pieza.getPuestoIdPuesto(), i, 9);
            modelo.setValueAt(pieza.getOperacionesIdOperaciones(), i, 10);
            modelo.setValueAt(pieza.getPuestoIdPuesto2(), i, 11);
            mapaPiezas.remove(idPieza); // Eliminar la pieza del mapa
        }
    }

    // Agregar nuevas filas para las piezas restantes en el mapa
    for (Pieza pieza : mapaPiezas.values()) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}



 











@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id_pieza", "numero", "codigo", "cantidad_aadicional", "diseño", "cantidad", "control_fisico", "observaciones", "sobrante", "causas", "operacionesid_operaciones ", "puestoid_puesto"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.setText("Buscar");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486503760-backup-disk-data-data-storage-floppy-save_81268.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 517, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        jLabel4.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        agregarPieza(); // Llamar al método para agregar insumo
    }
});// TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
    jLabel2.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        eliminarPieza(); // Llamar al método para agregar insumo
    }
});    // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
     jLabel3.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        exportarDatosATxt(); // Llamar al método para agregar insumo
    }
});   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
         jLabel1.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        modificarPieza(); // Llamar al método para agregar insumo
    }
});   // TODO// TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltro();
            }
        });
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
 jLabel7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
actualizarTabla();            }
        });         // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Control_piezas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
