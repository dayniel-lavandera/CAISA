/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vista;


import static com.unah.vista.Insumos.jTable1;
import dao.PuestoDAO;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Personal;
import model.Puesto;
import dao.PuestoDAO;


/**
 *
 * @author pango
 */
public class Registro_Puesto extends javax.swing.JFrame {
private PuestoDAO puestoDAO;
    
   
       

public Registro_Puesto() {
        initComponents();
     puestoDAO = new PuestoDAO(); // Crea una instancia del DAO
        cargarDatosTabla(); 
    }
private void cargarDatosTabla() {
    // Verifica que jTable1 no sea null
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

    // Obtén el modelo de la tabla
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Obtener los datos desde el DAO
    List<Puesto> listaPuestos = puestoDAO.cargarDatos();

    // Agregar los datos al modelo de la tabla
    for (Puesto puesto : listaPuestos) {
        modeloTabla.addRow(new Object[]{
            puesto.getIdPuesto(),           // ID del puesto
            puesto.getNombrePuesto(),       // Nombre del puesto
            puesto.getPuesto(),             // Puesto
            puesto.getGrupo(),              // Grupo
            puesto.getTallerIdTaller()      // ID del taller
        });
    }
  }
private void agregarPuesto() {
    // Crear un panel para contener todos los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    // Crear los campos de entrada
    JTextField nombrePuestoField = new JTextField();
    JTextField puestoField = new JTextField();
    JTextField grupoField = new JTextField();
    JTextField tallerIdTallerField = new JTextField();

    // Añadir los campos al panel
    panel.add(new JLabel("Nombre del puesto:"));
    panel.add(nombrePuestoField);
    panel.add(new JLabel("Puesto:"));
    panel.add(puestoField);
    panel.add(new JLabel("Grupo:"));
    panel.add(grupoField);
    panel.add(new JLabel("ID del taller:"));
    panel.add(tallerIdTallerField);

    // Mostrar el panel en un JOptionPane
    int option = JOptionPane.showConfirmDialog(null, panel, "Agregar Puesto", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (option == JOptionPane.OK_OPTION) {
        try {
            String nombrePuesto = nombrePuestoField.getText().trim();
            String puesto = puestoField.getText().trim();
            int grupo = Integer.parseInt(grupoField.getText().trim());
            int tallerIdTaller = Integer.parseInt(tallerIdTallerField.getText().trim());

            // Crear el objeto Puesto
            Puesto nuevoPuesto = new Puesto(0, nombrePuesto, puesto, grupo, tallerIdTaller);
            boolean exito = puestoDAO.agregarPuesto(nuevoPuesto); // Método `agregarPuesto` debe ser implementado

            if (exito) {
                JOptionPane.showMessageDialog(null, "Puesto agregado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar el puesto.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El grupo y el ID del taller deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
private void modificarPuesto() {
    String idStr = JOptionPane.showInputDialog("Ingrese el ID del puesto que desea modificar:");

    if (idStr != null && !idStr.trim().isEmpty()) {
        try {
            int idPuesto = Integer.parseInt(idStr);

            Puesto puestoActual = puestoDAO.obtenerPuestoPorId(idPuesto); // Método `obtenerPuestoPorId` debe ser implementado

            if (puestoActual == null) {
                JOptionPane.showMessageDialog(null, "Puesto no encontrado para el ID proporcionado.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Crear un panel para contener todos los campos de entrada
            JPanel panel = new JPanel(new GridLayout(0, 2));

            // Crear los campos de entrada con los valores actuales
            JTextField nombrePuestoField = new JTextField(puestoActual.getNombrePuesto());
            JTextField puestoField = new JTextField(puestoActual.getPuesto());
            JTextField grupoField = new JTextField(String.valueOf(puestoActual.getGrupo()));
            JTextField tallerIdTallerField = new JTextField(String.valueOf(puestoActual.getTallerIdTaller()));

            // Añadir los campos al panel
            panel.add(new JLabel("Nuevo nombre del puesto:"));
            panel.add(nombrePuestoField);
            panel.add(new JLabel("Nuevo puesto:"));
            panel.add(puestoField);
            panel.add(new JLabel("Nuevo grupo:"));
            panel.add(grupoField);
            panel.add(new JLabel("Nuevo ID del taller:"));
            panel.add(tallerIdTallerField);

            // Mostrar el panel en un JOptionPane
            int result = JOptionPane.showConfirmDialog(null, panel, "Modificar datos del puesto", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                try {
                    String nombrePuesto = nombrePuestoField.getText().trim();
                    String puesto = puestoField.getText().trim();
                    int grupo = Integer.parseInt(grupoField.getText().trim());
                    int tallerIdTaller = Integer.parseInt(tallerIdTallerField.getText().trim());

                    Puesto puestoActualizado = new Puesto(idPuesto, nombrePuesto, puesto, grupo, tallerIdTaller);
                    boolean exito = puestoDAO.actualizarPuesto(puestoActualizado); // Método `actualizarPuesto` debe ser implementado

                    if (exito) {
                        JOptionPane.showMessageDialog(null, "Puesto actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarDatosTabla(); // Recargar datos en la tabla
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al actualizar el puesto.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "El grupo y el ID del taller deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe completar todos los campos para modificar el puesto.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
private void eliminarPuesto() {
    // Mostrar un cuadro de diálogo para que el usuario ingrese el ID del puesto
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID del puesto que desea eliminar:", "Eliminar Puesto", JOptionPane.QUESTION_MESSAGE);

    // Verificar si el usuario presionó Cancelar
    if (input != null && !input.trim().isEmpty()) {
        try {
            // Convertir el valor ingresado a un entero
            int idPuesto = Integer.parseInt(input.trim());

            // Confirmar la eliminación
            int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el puesto con ID " + idPuesto + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                // Llamar al DAO para eliminar el puesto
                boolean exito = puestoDAO.eliminarPuesto(idPuesto);

                if (exito) {
                    JOptionPane.showMessageDialog(null, "Puesto eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                    // Actualizar la tabla después de eliminar el puesto
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    for (int i = 0; i < model.getRowCount(); i++) {
                        if ((int) model.getValueAt(i, 0) == idPuesto) {
                            model.removeRow(i);
                            break;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar el puesto. Verifique si el ID es correcto o si existen dependencias.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de eliminación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}
 
 private void exportarPuestos() {
        JFileChooser fileChooser = new JFileChooser();
        int resultado = fileChooser.showSaveDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            String rutaArchivo = archivo.getAbsolutePath();

            if (!rutaArchivo.endsWith(".txt")) {
                rutaArchivo += ".txt";
            }

            boolean exito = puestoDAO.exportarDatosAArchivoTxt(rutaArchivo);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Datos exportados correctamente a " + rutaArchivo, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al exportar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(888, 604));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id_puesto", "puesto", "grupo", "tallerid_taller"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486503760-backup-disk-data-data-storage-floppy-save_81268.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.setText("Buscar");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 980, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
jLabel4.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        agregarPuesto(); // Llamar al método para agregar insumo
    }
});              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
jLabel2.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        eliminarPuesto(); // Llamar al método para agregar insumo
    }
});              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
jLabel1.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
       modificarPuesto(); // Llamar al método para agregar insumo
    }
});              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
jLabel3.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        exportarPuestos(); // Llamar al método para agregar insumo
    }
});              // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro_Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro_Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro_Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro_Puesto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro_Puesto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
