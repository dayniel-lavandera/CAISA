/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.sql.*;

public class Control_personalDAO {
    private Connection conexion;

    public Control_personalDAO(String url, String usuario, String contraseña) {
        try {
            // Conectar a la base de datos
            conexion = DriverManager.getConnection(url, usuario, contraseña);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agregarPersonal(String personal, int cantidad, int id_personal) {
        try {
            // Crear un objeto PreparedStatement para ejecutar la consulta SQL
            PreparedStatement preparedStatement = conexion.prepareStatement(
                "INSERT INTO nombre_tabla (personal, cantidad, id_personal) VALUES (?, ?, ?)");

            // Establecer los valores de los parámetros
            preparedStatement.setString(1, personal);
            preparedStatement.setInt(2, cantidad);
            preparedStatement.setInt(3, id_personal);

            // Ejecutar la consulta SQL
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Aquí puedes agregar más métodos para realizar otras operaciones en la tabla
}