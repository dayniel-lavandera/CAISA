/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;

public class Registro_puestoDAO {
    private Connection conexion;

    public Registro_puestoDAO(String url, String usuario, String contraseña) {
        try {
            // Conectar a la base de datos
            conexion = DriverManager.getConnection(url, usuario, contraseña);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agregarPuesto(String nombre, String taller, String proceso, String grupo, String puesto) {
        try {
            // Crear un objeto PreparedStatement para ejecutar la consulta SQL
            PreparedStatement preparedStatement = conexion.prepareStatement(
                "INSERT INTO Registro_piezas (Nombre, Taller, Proceso, Grupo, Puesto) VALUES (?, ?, ?, ?, ?)");

            // Establecer los valores de los parámetros
            preparedStatement.setString(1, nombre);
            preparedStatement.setString(2, taller);
            preparedStatement.setString(3, proceso);
            preparedStatement.setString(4, grupo);
            preparedStatement.setString(5, puesto);

            // Ejecutar la consulta SQL
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Aquí puedes agregar más métodos para realizar otras operaciones en la tabla 'Registro_piezas'
}
