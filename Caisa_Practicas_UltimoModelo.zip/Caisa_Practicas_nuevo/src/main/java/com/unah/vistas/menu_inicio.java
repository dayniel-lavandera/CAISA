/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.plaf.DimensionUIResource;

/**
 *
 * @author JuanMi025
 */
public class menu_inicio extends javax.swing.JFrame {

   boolean estado = true;
    public menu_inicio() {
    
        initComponents();
    }
public static void izq(JComponent componente, int milisegundos, int saltos, int parar) {
    new Thread() {
        public void run() {
            for (int i = componente.getWidth(); i >= parar; i -= saltos) {
                try {
                    Thread.sleep(milisegundos);
                    final int width = i;
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            componente.setPreferredSize(new DimensionUIResource(width, componente.getHeight()));
                            componente.revalidate();
                            componente.repaint();
                        }
                    });
                } catch (InterruptedException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }.start();
}
        
  public static void derecha(JComponent componente, int milisegundos, int saltos, int parar) {
    new Thread() {
        public void run() {
            for (int i = componente.getWidth(); i <= parar; i += saltos) {
                try {
                    Thread.sleep(milisegundos);
                    final int width = i;
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            componente.setPreferredSize(new DimensionUIResource(width, componente.getHeight()));
                            componente.revalidate();
                            componente.repaint();
                        }
                    });
                } catch (InterruptedException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }.start();
}

    @SuppressWarnings("unchecked")
 

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                              
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jMenu1 = new javax.swing.JMenu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jLabel10 = new javax.swing.JLabel();
        bode_arriba = new javax.swing.JPanel();
        iconos = new javax.swing.JPanel();
        panelClose = new javax.swing.JPanel();
        bottonclose = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        panelMax = new javax.swing.JPanel();
        buttonMax = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        barramenu = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jMenu1.setText("jMenu1");

        jLabel10.setText("jLabel10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        bode_arriba.setBackground(new java.awt.Color(0, 102, 102));
        bode_arriba.setPreferredSize(new java.awt.Dimension(800, 50));
        bode_arriba.setLayout(new java.awt.BorderLayout());

        iconos.setBackground(new java.awt.Color(0, 102, 102));
        iconos.setPreferredSize(new java.awt.Dimension(150, 50));

        panelClose.setBackground(new java.awt.Color(0, 102, 102));
        panelClose.setPreferredSize(new java.awt.Dimension(50, 50));

        bottonclose.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        bottonclose.setForeground(new java.awt.Color(0, 153, 255));
        bottonclose.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bottonclose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/window_close_icon_135015.png"))); // NOI18N
        bottonclose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bottoncloseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bottoncloseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                bottoncloseMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelCloseLayout = new javax.swing.GroupLayout(panelClose);
        panelClose.setLayout(panelCloseLayout);
        panelCloseLayout.setHorizontalGroup(
            panelCloseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCloseLayout.createSequentialGroup()
                .addComponent(bottonclose, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelCloseLayout.setVerticalGroup(
            panelCloseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCloseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bottonclose)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 102, 102));
        jPanel4.setPreferredSize(new java.awt.Dimension(50, 50));
        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize_118918.png"))); // NOI18N
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        panelMax.setBackground(new java.awt.Color(0, 51, 153));
        panelMax.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout panelMaxLayout = new javax.swing.GroupLayout(panelMax);
        panelMax.setLayout(panelMaxLayout);
        panelMaxLayout.setHorizontalGroup(
            panelMaxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 42, Short.MAX_VALUE)
        );
        panelMaxLayout.setVerticalGroup(
            panelMaxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        buttonMax.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        buttonMax.setForeground(new java.awt.Color(0, 153, 255));
        buttonMax.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/maximize_expand_icon_195054.png"))); // NOI18N
        buttonMax.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonMaxMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonMaxMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonMaxMouseExited(evt);
            }
        });

        javax.swing.GroupLayout iconosLayout = new javax.swing.GroupLayout(iconos);
        iconos.setLayout(iconosLayout);
        iconosLayout.setHorizontalGroup(
            iconosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iconosLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(buttonMax)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelClose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iconosLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelMax, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );
        iconosLayout.setVerticalGroup(
            iconosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iconosLayout.createSequentialGroup()
                .addGroup(iconosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelClose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iconosLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(buttonMax, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelMax, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        bode_arriba.add(iconos, java.awt.BorderLayout.LINE_END);
        bode_arriba.add(jLabel2, java.awt.BorderLayout.LINE_START);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new java.awt.BorderLayout());
        bode_arriba.add(jPanel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(bode_arriba, java.awt.BorderLayout.PAGE_START);

        barramenu.setBackground(new java.awt.Color(0, 51, 51));
        barramenu.setMinimumSize(new java.awt.Dimension(200, 200));
        barramenu.setPreferredSize(new java.awt.Dimension(200, 502));
        barramenu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(100, 47));
        jPanel2.setPreferredSize(new java.awt.Dimension(100, 53));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1491313929-menu_82986.png"))); // NOI18N
        jLabel9.setText("         Menú");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 180, 30));

        barramenu.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/contact_people_14393.png"))); // NOI18N
        jLabel4.setText("          Personal");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        barramenu.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 188, 53));

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4288593creativejigsawspiecesplanningpuzzlestrategy-115763_115750.png"))); // NOI18N
        jLabel3.setText("           Piezas ");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        barramenu.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 190, 53));

        jLabel5.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/paintroller_23702.png"))); // NOI18N
        jLabel5.setText("          Insumos");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        barramenu.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 180, 53));

        jLabel6.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\JuanMi025\\Downloads\\growth_evolve_success_achieve_development_person_personal_icon_251249.png")); // NOI18N
        jLabel6.setText("           Puesto ");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        barramenu.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 180, 53));

        jLabel7.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1489186762-buildingconstructionequipmentheavymachinemachinerywork_81807.png"))); // NOI18N
        jLabel7.setText("      Operaciones");
        jLabel7.setMaximumSize(new java.awt.Dimension(37, 50));
        jLabel7.setPreferredSize(new java.awt.Dimension(37, 50));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        barramenu.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 190, -1));

        jLabel8.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/college_vocational_shool_job_icon_180354.png"))); // NOI18N
        jLabel8.setText("           Taller");
        jLabel8.setPreferredSize(new java.awt.Dimension(37, 50));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        barramenu.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 190, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/settings_78352.png"))); // NOI18N
        jLabel1.setText("       Herramientas");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        barramenu.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 190, 50));

        getContentPane().add(barramenu, java.awt.BorderLayout.LINE_START);

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setPreferredSize(new java.awt.Dimension(760, 75));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1070, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 75, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, java.awt.BorderLayout.PAGE_END);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 870, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel7, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void buttonMaxMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMaxMouseExited

    }//GEN-LAST:event_buttonMaxMouseExited

    private void buttonMaxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMaxMouseEntered

    }//GEN-LAST:event_buttonMaxMouseEntered

    private void buttonMaxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMaxMouseClicked
        if(this.getExtendedState()!=menu_inicio.MAXIMIZED_BOTH)  {
            this.setExtendedState(menu_inicio.MAXIMIZED_BOTH);
        }else{
            this.setExtendedState(menu_inicio.NORMAL);
    }//GEN-LAST:event_buttonMaxMouseClicked
    }
    private void bottoncloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bottoncloseMouseExited

    }//GEN-LAST:event_bottoncloseMouseExited

    private void bottoncloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bottoncloseMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_bottoncloseMouseEntered

    private void bottoncloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bottoncloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_bottoncloseMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
jLabel1.addMouseListener(new MouseAdapter() {
    Herramientas1 veHerramientas1 = new Herramientas1();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(veHerramientas1.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
      jLabel4.addMouseListener(new MouseAdapter() {
   Control_personal control_personal = new Control_personal();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(control_personal.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
   jLabel3.addMouseListener(new MouseAdapter() {
  Control_piezas control_piezas = new Control_piezas();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(control_piezas.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
if (estado) {
            derecha(barramenu, 1, 2, 200);
        estado=false;
        }else{
            izq(barramenu, 1, 2, 50);
        estado=true;
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
 Insumos insumos = new Insumos();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(insumos.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
           jLabel6.addMouseListener(new MouseAdapter() {
 Registro_Puesto registro_Puesto = new Registro_Puesto();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(registro_Puesto.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
 Registro_operaciones registro_operaciones = new Registro_operaciones();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(registro_operaciones.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
              jLabel8.addMouseListener(new MouseAdapter() {
 Registro_taller registro_taller = new Registro_taller();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanel7.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanel7.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanel7.add(registro_taller.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanel7.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanel7.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanel7.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanel7.revalidate();
        jPanel7.repaint();
    }
});  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked

    }//GEN-LAST:event_jPanel4MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked



    }//GEN-LAST:event_jLabel11MouseClicked

                                     
     public void changecolor(JPanel hover, Color rand){
    
    hover.setBackground(rand);
      
    }   
  
    
   

        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu_inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barramenu;
    private javax.swing.JPanel bode_arriba;
    private javax.swing.JLabel bottonclose;
    private javax.swing.JLabel buttonMax;
    private javax.swing.JPanel iconos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPanel panelClose;
    private javax.swing.JPanel panelMax;
    // End of variables declaration//GEN-END:variables

}
