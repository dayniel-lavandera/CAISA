
package com.unah.modelos;

/**
 *
 * @author pango
 */
public enum Role {
    ADMIN, INFORMATICO, VISIATNTE
    
}
