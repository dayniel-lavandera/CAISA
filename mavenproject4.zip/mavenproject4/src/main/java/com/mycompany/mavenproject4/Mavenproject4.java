/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import login.login_user;

/**
 *
 * @author pango
 */
public class Mavenproject4 {
public static void main(String[] args) {
        String user = "postgres";
        String password = "941821156644";
        String url = "jdbc:postgresql://localhost:5432/caisa2";

        try {
            // Cargar el driver de PostgreSQL
            Class.forName("org.postgresql.Driver");

            // Establecer la conexión
            Connection connection = DriverManager.getConnection(url, user, password);

            // Si la conexión fue exitosa, imprimir un mensaje y abrir la interfaz de usuario
            System.out.println("Conexion exitosa");
            JOptionPane.showMessageDialog(null, "Conexion exitosa");
            login.login_user login = new login.login_user();
            login.setVisible(true); // Asegúrate de que tu clase login_user tenga un método setVisible

        } catch (ClassNotFoundException e) {
            // Error al cargar el driver
            System.out.println("No se pudo cargar el driver de PostgreSQL");
            e.printStackTrace();
        } catch (SQLException e) {
            // Error al establecer la conexión
            System.out.println("No se pudo establecer la conexión con la base de datos");
            e.printStackTrace();
        }
}
public class ConsultaTablaHerramientas {
    private Connection con;
    private Statement st;
    private ResultSet rs;

    public ConsultaTablaHerramientas(Connection con) {
        this.con = con;
        this.st = null;
        this.rs = null;
    }

    public void llenarTablaHerramientas(DefaultTableModel modelo) {
        try {
            st = con.createStatement();
            String sql = "SELECT * FROM herramientas";
            rs = st.executeQuery(sql);
            modelo.setRowCount(0); // Limpiar la tabla

            while (rs.next()) {
                Object[] fila = new Object[5]; // Asumiendo que hay 5 columnas: codigo_variante, proveedor, cantidad, no, herramientas
                for (int i = 0; i < fila.length; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
                }
            }
        }
    }
}


