/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.plaf.DimensionUIResource;

/**
 *
 * @author JuanMi025
 */
public class menu_inicio extends javax.swing.JFrame {

   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public class RedSocial {
    public static void abrirURL(String url) {
        if(Desktop.isDesktopSupported()){
            Desktop desktop = Desktop.getDesktop();
            try {
                desktop.browse(new URI(url));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("La función de navegación no es compatible con tu sistema operativo.");
        }
    }
}


    
    
    
    
   boolean estado = true;
    public menu_inicio() {
    
        initComponents();
    }
public static void izq(JComponent componente, int milisegundos, int saltos, int parar) {
    new Thread() {
        public void run() {
            for (int i = componente.getWidth(); i >= parar; i -= saltos) {
                try {
                    Thread.sleep(milisegundos);
                    final int width = i;
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            componente.setPreferredSize(new DimensionUIResource(width, componente.getHeight()));
                            componente.revalidate();
                            componente.repaint();
                        }
                    });
                } catch (InterruptedException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }.start();
}
        
  public static void derecha(JComponent componente, int milisegundos, int saltos, int parar) {
    new Thread() {
        public void run() {
            for (int i = componente.getWidth(); i <= parar; i += saltos) {
                try {
                    Thread.sleep(milisegundos);
                    final int width = i;
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            componente.setPreferredSize(new DimensionUIResource(width, componente.getHeight()));
                            componente.revalidate();
                            componente.repaint();
                        }
                    });
                } catch (InterruptedException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }.start();

  
  
  
  }

    @SuppressWarnings("unchecked")
 

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                              
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jMenu1 = new javax.swing.JMenu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jLabel10 = new javax.swing.JLabel();
        bode_arriba = new javax.swing.JPanel();
        iconos = new javax.swing.JPanel();
        panelClose = new javax.swing.JPanel();
        bottonclose = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        panelMax = new javax.swing.JPanel();
        buttonMax = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        barramenu = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        panelherram = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        panpizs = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        panpers = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        paninsm = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        panpues = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        panop = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        pantall = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanelimagenes = new javax.swing.JPanel();

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jMenu1.setText("jMenu1");

        jLabel10.setText("jLabel10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setName("Principal"); // NOI18N
        setUndecorated(true);

        bode_arriba.setBackground(new java.awt.Color(0, 102, 102));
        bode_arriba.setPreferredSize(new java.awt.Dimension(800, 50));
        bode_arriba.setLayout(new java.awt.BorderLayout());

        iconos.setBackground(new java.awt.Color(0, 102, 102));
        iconos.setPreferredSize(new java.awt.Dimension(150, 50));

        panelClose.setBackground(new java.awt.Color(0, 102, 102));
        panelClose.setPreferredSize(new java.awt.Dimension(50, 50));

        bottonclose.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        bottonclose.setForeground(new java.awt.Color(0, 153, 255));
        bottonclose.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bottonclose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/window_close_icon_135015.png"))); // NOI18N
        bottonclose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bottoncloseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bottoncloseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                bottoncloseMouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelCloseLayout = new javax.swing.GroupLayout(panelClose);
        panelClose.setLayout(panelCloseLayout);
        panelCloseLayout.setHorizontalGroup(
            panelCloseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCloseLayout.createSequentialGroup()
                .addComponent(bottonclose, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelCloseLayout.setVerticalGroup(
            panelCloseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCloseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bottonclose)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(0, 102, 102));
        jPanel4.setPreferredSize(new java.awt.Dimension(50, 50));
        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize_118918.png"))); // NOI18N
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        panelMax.setBackground(new java.awt.Color(0, 51, 153));
        panelMax.setPreferredSize(new java.awt.Dimension(50, 50));

        javax.swing.GroupLayout panelMaxLayout = new javax.swing.GroupLayout(panelMax);
        panelMax.setLayout(panelMaxLayout);
        panelMaxLayout.setHorizontalGroup(
            panelMaxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 42, Short.MAX_VALUE)
        );
        panelMaxLayout.setVerticalGroup(
            panelMaxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        buttonMax.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        buttonMax.setForeground(new java.awt.Color(0, 153, 255));
        buttonMax.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/maximize_expand_icon_195054.png"))); // NOI18N
        buttonMax.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonMaxMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonMaxMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonMaxMouseExited(evt);
            }
        });

        javax.swing.GroupLayout iconosLayout = new javax.swing.GroupLayout(iconos);
        iconos.setLayout(iconosLayout);
        iconosLayout.setHorizontalGroup(
            iconosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iconosLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(buttonMax)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelClose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iconosLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelMax, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );
        iconosLayout.setVerticalGroup(
            iconosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(iconosLayout.createSequentialGroup()
                .addGroup(iconosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelClose, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, iconosLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(buttonMax, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelMax, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        bode_arriba.add(iconos, java.awt.BorderLayout.LINE_END);
        bode_arriba.add(jLabel2, java.awt.BorderLayout.LINE_START);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new java.awt.BorderLayout());
        bode_arriba.add(jPanel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(bode_arriba, java.awt.BorderLayout.PAGE_START);

        barramenu.setBackground(new java.awt.Color(0, 51, 51));
        barramenu.setMinimumSize(new java.awt.Dimension(200, 200));
        barramenu.setPreferredSize(new java.awt.Dimension(200, 502));
        barramenu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(100, 47));
        jPanel2.setPreferredSize(new java.awt.Dimension(100, 53));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("PMingLiU-ExtB", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1491313929-menu_82986.png"))); // NOI18N
        jLabel9.setText("         Menú");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel9MouseExited(evt);
            }
        });
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 180, 30));

        barramenu.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, -1));

        panelherram.setBackground(new java.awt.Color(0, 51, 51));

        jLabel1.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/settings_78352.png"))); // NOI18N
        jLabel1.setText("       Herramientas");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panelherramLayout = new javax.swing.GroupLayout(panelherram);
        panelherram.setLayout(panelherramLayout);
        panelherramLayout.setHorizontalGroup(
            panelherramLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelherramLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelherramLayout.setVerticalGroup(
            panelherramLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelherramLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        barramenu.add(panelherram, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 200, 50));

        panpizs.setBackground(new java.awt.Color(0, 51, 51));

        jLabel3.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4288593creativejigsawspiecesplanningpuzzlestrategy-115763_115750.png"))); // NOI18N
        jLabel3.setText("           Piezas ");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel3MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panpizsLayout = new javax.swing.GroupLayout(panpizs);
        panpizs.setLayout(panpizsLayout);
        panpizsLayout.setHorizontalGroup(
            panpizsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panpizsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );
        panpizsLayout.setVerticalGroup(
            panpizsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panpizsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        barramenu.add(panpizs, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 200, 50));

        panpers.setBackground(new java.awt.Color(0, 51, 51));

        jLabel4.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/contact_people_14393.png"))); // NOI18N
        jLabel4.setText("          Personal");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel4MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panpersLayout = new javax.swing.GroupLayout(panpers);
        panpers.setLayout(panpersLayout);
        panpersLayout.setHorizontalGroup(
            panpersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panpersLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );
        panpersLayout.setVerticalGroup(
            panpersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panpersLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        barramenu.add(panpers, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 200, 50));

        paninsm.setBackground(new java.awt.Color(0, 51, 51));

        jLabel5.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/paintroller_23702.png"))); // NOI18N
        jLabel5.setText("          Insumos");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel5MouseExited(evt);
            }
        });

        javax.swing.GroupLayout paninsmLayout = new javax.swing.GroupLayout(paninsm);
        paninsm.setLayout(paninsmLayout);
        paninsmLayout.setHorizontalGroup(
            paninsmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paninsmLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );
        paninsmLayout.setVerticalGroup(
            paninsmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paninsmLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        barramenu.add(paninsm, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 200, 50));

        panpues.setBackground(new java.awt.Color(0, 51, 51));

        jLabel6.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\JuanMi025\\Downloads\\growth_evolve_success_achieve_development_person_personal_icon_251249.png")); // NOI18N
        jLabel6.setText("           Puesto ");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel6MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panpuesLayout = new javax.swing.GroupLayout(panpues);
        panpues.setLayout(panpuesLayout);
        panpuesLayout.setHorizontalGroup(
            panpuesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panpuesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );
        panpuesLayout.setVerticalGroup(
            panpuesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panpuesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        barramenu.add(panpues, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 200, 50));

        panop.setBackground(new java.awt.Color(0, 51, 51));

        jLabel7.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1489186762-buildingconstructionequipmentheavymachinemachinerywork_81807.png"))); // NOI18N
        jLabel7.setText("      Operaciones");
        jLabel7.setMaximumSize(new java.awt.Dimension(37, 50));
        jLabel7.setPreferredSize(new java.awt.Dimension(37, 50));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel7MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panopLayout = new javax.swing.GroupLayout(panop);
        panop.setLayout(panopLayout);
        panopLayout.setHorizontalGroup(
            panopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                .addContainerGap())
        );
        panopLayout.setVerticalGroup(
            panopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addContainerGap())
        );

        barramenu.add(panop, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 200, 50));

        pantall.setBackground(new java.awt.Color(0, 51, 51));

        jLabel8.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/college_vocational_shool_job_icon_180354.png"))); // NOI18N
        jLabel8.setText("           Taller");
        jLabel8.setPreferredSize(new java.awt.Dimension(37, 50));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel8MouseExited(evt);
            }
        });

        javax.swing.GroupLayout pantallLayout = new javax.swing.GroupLayout(pantall);
        pantall.setLayout(pantallLayout);
        pantallLayout.setHorizontalGroup(
            pantallLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pantallLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE))
        );
        pantallLayout.setVerticalGroup(
            pantallLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pantallLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        barramenu.add(pantall, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 200, 50));

        getContentPane().add(barramenu, java.awt.BorderLayout.LINE_START);

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setPreferredSize(new java.awt.Dimension(760, 75));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8-facebook-nuevo-50.png"))); // NOI18N
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8-gmail-nuevo-50.png"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Captura de pantalla 2024-06-17 214934.png"))); // NOI18N

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icons8-web-50.png"))); // NOI18N
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 764, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel16)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, java.awt.BorderLayout.PAGE_END);

        jPanelimagenes.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jPanelimagenesAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        javax.swing.GroupLayout jPanelimagenesLayout = new javax.swing.GroupLayout(jPanelimagenes);
        jPanelimagenes.setLayout(jPanelimagenesLayout);
        jPanelimagenesLayout.setHorizontalGroup(
            jPanelimagenesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 886, Short.MAX_VALUE)
        );
        jPanelimagenesLayout.setVerticalGroup(
            jPanelimagenesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 566, Short.MAX_VALUE)
        );

        getContentPane().add(jPanelimagenes, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void buttonMaxMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMaxMouseExited

    }//GEN-LAST:event_buttonMaxMouseExited

    private void buttonMaxMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMaxMouseEntered

    }//GEN-LAST:event_buttonMaxMouseEntered

    private void buttonMaxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMaxMouseClicked
        if(this.getExtendedState()!=menu_inicio.MAXIMIZED_BOTH)  {
            this.setExtendedState(menu_inicio.MAXIMIZED_BOTH);
        }else{
            this.setExtendedState(menu_inicio.NORMAL);
    }//GEN-LAST:event_buttonMaxMouseClicked
    }
    private void bottoncloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bottoncloseMouseExited

    }//GEN-LAST:event_bottoncloseMouseExited

    private void bottoncloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bottoncloseMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_bottoncloseMouseEntered

    private void bottoncloseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bottoncloseMouseClicked
        System.exit(0);
    }//GEN-LAST:event_bottoncloseMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
jLabel1.addMouseListener(new MouseAdapter() {
    Herramientas1 veHerramientas1 = new Herramientas1();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(veHerramientas1.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
      jLabel4.addMouseListener(new MouseAdapter() {
   Control_personal control_personal = new Control_personal();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(control_personal.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
   jLabel3.addMouseListener(new MouseAdapter() {
  Control_piezas control_piezas = new Control_piezas();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(control_piezas.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
if (estado) {
            derecha(barramenu, 1, 2, 200);
        estado=false;
        }else{
            izq(barramenu, 1, 2, 50);
        estado=true;
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
 Insumos insumos = new Insumos();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(insumos.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
           jLabel6.addMouseListener(new MouseAdapter() {
 Registro_Puesto registro_Puesto = new Registro_Puesto();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(registro_Puesto.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
 Registro_operaciones registro_operaciones = new Registro_operaciones();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(registro_operaciones.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
              jLabel8.addMouseListener(new MouseAdapter() {
 Registro_taller registro_taller = new Registro_taller();
    @Override
    public void mouseClicked(MouseEvent e) {
        jPanelimagenes.removeAll(); // Elimina cualquier contenido anterior en jPanel7
        jPanelimagenes.setLayout(new BorderLayout()); // Establece el layout del panel
        jPanelimagenes.add(registro_taller.getContentPane()); // Añade el contenido de veHerramientas1 a jPanel7
        jPanelimagenes.revalidate(); // Actualiza jPanel7 para mostrar el nuevo contenido
        jPanelimagenes.repaint(); // Repinta jPanel7
    }
});

// Asegura que jPanel7 se redimensione correctamente cuando la ventana cambia de tamaño
jPanelimagenes.addComponentListener(new ComponentAdapter() {
    @Override
    public void componentResized(ComponentEvent e) {
        jPanelimagenes.revalidate();
        jPanelimagenes.repaint();
    }
});  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked

    }//GEN-LAST:event_jPanel4MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked

    


    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseEntered
jPanel2.setBackground(Color.gray);        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseEntered

    private void jLabel9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseExited
        changecolor(jPanel2, new Color(0,51,51));        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseExited

    private void jLabel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseEntered
panelherram.setBackground(Color.gray);        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseEntered

    private void jLabel1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseExited
changecolor(panelherram, new Color(0,51,51));
    }//GEN-LAST:event_jLabel1MouseExited

    private void jLabel3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseEntered
      panpizs.setBackground(Color.gray);  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseEntered

    private void jLabel3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseExited
     changecolor(panpizs, new Color(0,51,51));   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseExited

    private void jLabel4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseEntered
      panpers.setBackground(Color.gray);  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseEntered

    private void jLabel4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseExited
         changecolor(panpers, new Color(0,51,51)); // TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseExited

    private void jLabel5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseEntered
      paninsm.setBackground(Color.gray);  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseEntered

    private void jLabel5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseExited
         changecolor(paninsm, new Color(0,51,51)); // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseExited

    private void jLabel6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseEntered
      panpues.setBackground(Color.gray);  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseEntered

    private void jLabel6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseExited
    changecolor(panpues, new Color(0,51,51));     // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseExited

    private void jLabel7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseEntered
       panop.setBackground(Color.gray); // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseEntered

    private void jLabel7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseExited
     changecolor(panop, new Color(0,51,51));   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseExited

    private void jLabel8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseEntered
       pantall.setBackground(Color.gray);  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseEntered

    private void jLabel8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseExited
changecolor(pantall, new Color(0,51,51));    }//GEN-LAST:event_jLabel8MouseExited

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
       jLabel13.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.facebook.com/people/Evelio-Prieto-Guillama/100079899777234"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
     jLabel14.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().mail(new URI("toledo@caisa.co.cu"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
          jLabel16.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.sime.cu/es/empresa-productora-de-mnibus-evelio-prieto-guillama-caisa"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });// TODO add your handling code here:
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jPanelimagenesAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jPanelimagenesAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanelimagenesAncestorAdded

                                     
     public void changecolor(JPanel hover, Color rand){
    
    hover.setBackground(rand);
      
    }   
  
    
   

        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu_inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu_inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barramenu;
    private javax.swing.JPanel bode_arriba;
    private javax.swing.JLabel bottonclose;
    private javax.swing.JLabel buttonMax;
    private javax.swing.JPanel iconos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanelimagenes;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPanel panelClose;
    private javax.swing.JPanel panelMax;
    private javax.swing.JPanel panelherram;
    private javax.swing.JPanel paninsm;
    private javax.swing.JPanel panop;
    private javax.swing.JPanel panpers;
    private javax.swing.JPanel panpizs;
    private javax.swing.JPanel panpues;
    private javax.swing.JPanel pantall;
    // End of variables declaration//GEN-END:variables

}
