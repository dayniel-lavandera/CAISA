package com.unah.vistas;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class Insumos extends javax.swing.JFrame {

    private DefaultTableModel model;

    public Insumos() {
        initComponents();
        loadTableData();
    }

    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] {"Codigo Insumo", "Insumo", "U_M", "Origen", "Obtencion", "Cantidad"}
        ) {
            Class[] types = new Class[] {
                    java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486485588-add-create-new-math-sign-cross-plus_81186.png")));
        jLabel2.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361.png")));
        jLabel3.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/edit_pencil_modify_write_icon_179065.png")));
        jLabel5.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png")));
        jLabel1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png")));
        jLabel4.setText("Buscar");
        jLabel4.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel4))
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 746, Short.MAX_VALUE))
                                .addGap(38, 38, 38)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel1)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel5))
                                .addGap(32, 32, 32))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(8, 8, 8)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(50, 50, 50)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(50, 50, 50)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(50, 50, 50)
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE))
                                .addGap(42, 42, 42))
        );

        pack();
    }
    public DefaultTableModel getTableModel() {
        return (DefaultTableModel) jTable1.getModel();
    }

    private void jLabel2MouseClicked(MouseEvent evt) {
        JTextField codigoInsumo = new JTextField();
        JTextField insumo = new JTextField();
        JTextField u_m = new JTextField();
        JTextField origen = new JTextField();
        JTextField obtencion = new JTextField();
        JTextField cantidad = new JTextField();

        Object[] message = {
                "Codigo Insumo:", codigoInsumo,
                "Insumo:", insumo,
                "U_M:", u_m,
                "Origen:", origen,
                "Obtencion:", obtencion,
                "Cantidad:", cantidad,
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Agregar", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/caisa2", "postgres", "941821156644");
                String sql = "INSERT INTO insumos (codigo_insumo, insumo, u_m, origen, obtencion, cantidad) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, Integer.parseInt(codigoInsumo.getText()));
                pstmt.setString(2, insumo.getText());
                pstmt.setString(3, u_m.getText());
                pstmt.setString(4, origen.getText());
                pstmt.setString(5, obtencion.getText());
                pstmt.setDouble(6, Double.parseDouble(cantidad.getText()));
                pstmt.executeUpdate();
                loadTableData();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void jLabel3MouseClicked(MouseEvent evt) {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow != -1) {
            String codigoInsumo = jTable1.getValueAt(selectedRow, 0).toString();

            try {
                Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/caisa2", "postgres", "941821156644");
                String sql = "DELETE FROM insumos WHERE codigo_insumo = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, Integer.parseInt(codigoInsumo));
                pstmt.executeUpdate();
                loadTableData();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jLabel5MouseClicked(MouseEvent evt) {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow != -1) {
            String codigoInsumoActual = jTable1.getValueAt(selectedRow, 0).toString();

            JTextField codigoInsumo = new JTextField(jTable1.getValueAt(selectedRow, 0).toString());
            JTextField insumo = new JTextField(jTable1.getValueAt(selectedRow, 1).toString());
            JTextField u_m = new JTextField(jTable1.getValueAt(selectedRow, 2).toString());
            JTextField origen = new JTextField(jTable1.getValueAt(selectedRow, 3).toString());
            JTextField obtencion = new JTextField(jTable1.getValueAt(selectedRow, 4).toString());
            JTextField cantidad = new JTextField(jTable1.getValueAt(selectedRow, 5).toString());

            Object[] message = {
                    "Codigo Insumo:", codigoInsumo,
                    "Insumo:", insumo,
                    "U_M:", u_m,
                    "Origen:", origen,
                    "Obtencion:", obtencion,
                    "Cantidad:", cantidad,
            };

            int option = JOptionPane.showConfirmDialog(null, message, "Modificar", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                try {
                    Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/caisa2", "postgres", "941821156644");
                    String sql = "UPDATE insumos SET codigo_insumo = ?, insumo = ?, u_m = ?, origen = ?, obtencion = ?, cantidad = ? WHERE codigo_insumo = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, Integer.parseInt(codigoInsumo.getText()));
                    pstmt.setString(2, insumo.getText());
                    pstmt.setString(3, u_m.getText());
                    pstmt.setString(4, origen.getText());
                    pstmt.setString(5, obtencion.getText());
                    pstmt.setDouble(6, Double.parseDouble(cantidad.getText()));
                    pstmt.setInt(7, Integer.parseInt(codigoInsumoActual));
                    pstmt.executeUpdate();
                    loadTableData();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jLabel1MouseClicked(MouseEvent evt) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV files", "csv"));
        int result = fileChooser.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                for (int i = 0; i < jTable1.getColumnCount(); i++) {
                    writer.write(jTable1.getColumnName(i) + ",");
                }
                writer.newLine();

                for (int i = 0; i < jTable1.getRowCount(); i++) {
                    for (int j = 0; j < jTable1.getColumnCount(); j++) {
                        writer.write(jTable1.getValueAt(i, j) + ",");
                    }
                    writer.newLine();
                }
                JOptionPane.showMessageDialog(null, "Datos exportados exitosamente.");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void jLabel4MouseClicked(MouseEvent evt) {
        String searchText = jTextField1.getText();
        if (!searchText.isEmpty()) {
            try {
                Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/caisa2", "postgres", "941821156644");
                String sql = "SELECT * FROM insumos WHERE insumo ILIKE ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + searchText + "%");
                ResultSet rs = pstmt.executeQuery();

                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                model.setRowCount(0); // Limpiar la tabla actual

                while (rs.next()) {
                    int codigoInsumo = rs.getInt("codigo_insumo");
                    String insumo = rs.getString("insumo");
                    String u_m = rs.getString("u_m");
                    String origen = rs.getString("origen");
                    String obtencion = rs.getString("obtencion");
                    double cantidad = rs.getDouble("cantidad");
                    model.addRow(new Object[]{codigoInsumo, insumo, u_m, origen, obtencion, cantidad});
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            loadTableData(); // Recargar todos los datos si el campo de búsqueda está vacío
        }
    }

    private void loadTableData() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/caisa2", "postgres", "941821156644");
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM insumos");
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int codigoInsumo = rs.getInt("codigo_insumo");
                String insumo = rs.getString("insumo");
                String u_m = rs.getString("u_m");
                String origen = rs.getString("origen");
                String obtencion = rs.getString("obtencion");
                double cantidad = rs.getDouble("cantidad");
                model.addRow(new Object[]{codigoInsumo, insumo, u_m, origen, obtencion, cantidad});
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los datos de la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
}
