package org.example;

import com.interfaces_user.Login_1;
import com.interfaces_user.Login_1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    // Parámetros de conexión
    static final String URL = "jdbc:postgresql://localhost:5432/caisa";
    static final String USER = "postgres";
    static final String PASS = "Juanmi025@";

    public static void main(String[] args) {
        Connection conn = null;
        try{
            // Registrando el Driver de PostgreSQL
            Class.forName("org.postgresql.Driver");

            // Realizando la conexión
            conn = DriverManager.getConnection(URL, USER, PASS);

            if (conn != null) {
                System.out.println("Conexión exitosa a la base de datos!");

                // Abriendo la interfaz de usuario
               com.interfaces_user.Login_1 interfaz = new Login_1();
                interfaz.setVisible(true);
            }
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
    
    
    
    