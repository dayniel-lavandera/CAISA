/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "insumos", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "Insumos.findAll", query = "SELECT i FROM Insumos i"),
    @NamedQuery(name = "Insumos.findByIdInsumos", query = "SELECT i FROM Insumos i WHERE i.idInsumos = :idInsumos"),
    @NamedQuery(name = "Insumos.findByNombre", query = "SELECT i FROM Insumos i WHERE i.nombre = :nombre"),
    @NamedQuery(name = "Insumos.findByCantidad", query = "SELECT i FROM Insumos i WHERE i.cantidad = :cantidad"),
    @NamedQuery(name = "Insumos.findByM", query = "SELECT i FROM Insumos i WHERE i.m = :m"),
    @NamedQuery(name = "Insumos.findByCausa", query = "SELECT i FROM Insumos i WHERE i.causa = :causa")})
public class Insumos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_insumos")
    private Integer idInsumos;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "cantidad")
    private int cantidad;
    @Basic(optional = false)
    @Column(name = "M")
    private String m;
    @Basic(optional = false)
    @Column(name = "causa")
    private String causa;
    @JoinColumn(name = "puestoid_puesto", referencedColumnName = "id_puesto")
    @ManyToOne(optional = false)
    private Puesto puestoidPuesto;

    public Insumos() {
    }

    public Insumos(Integer idInsumos) {
        this.idInsumos = idInsumos;
    }

    public Insumos(Integer idInsumos, String nombre, int cantidad, String m, String causa) {
        this.idInsumos = idInsumos;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.m = m;
        this.causa = causa;
    }

    public Integer getIdInsumos() {
        return idInsumos;
    }

    public void setIdInsumos(Integer idInsumos) {
        this.idInsumos = idInsumos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public Puesto getPuestoidPuesto() {
        return puestoidPuesto;
    }

    public void setPuestoidPuesto(Puesto puestoidPuesto) {
        this.puestoidPuesto = puestoidPuesto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idInsumos != null ? idInsumos.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Insumos)) {
            return false;
        }
        Insumos other = (Insumos) object;
        if ((this.idInsumos == null && other.idInsumos != null) || (this.idInsumos != null && !this.idInsumos.equals(other.idInsumos))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.Insumos[ idInsumos=" + idInsumos + " ]";
    }
    
}
