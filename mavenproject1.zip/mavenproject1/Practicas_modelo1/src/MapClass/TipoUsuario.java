/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "tipo_usuario", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "TipoUsuario.findAll", query = "SELECT t FROM TipoUsuario t"),
    @NamedQuery(name = "TipoUsuario.findByIdTipo", query = "SELECT t FROM TipoUsuario t WHERE t.idTipo = :idTipo"),
    @NamedQuery(name = "TipoUsuario.findByAdmin", query = "SELECT t FROM TipoUsuario t WHERE t.admin = :admin"),
    @NamedQuery(name = "TipoUsuario.findByUser", query = "SELECT t FROM TipoUsuario t WHERE t.user = :user"),
    @NamedQuery(name = "TipoUsuario.findByUserSpecial", query = "SELECT t FROM TipoUsuario t WHERE t.userSpecial = :userSpecial")})
public class TipoUsuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_tipo")
    private Integer idTipo;
    @Basic(optional = false)
    @Column(name = "admin")
    private String admin;
    @Basic(optional = false)
    @Column(name = "user")
    private String user;
    @Basic(optional = false)
    @Column(name = "user_special")
    private String userSpecial;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tipoUsuario")
    private Collection<Personal> personalCollection;

    public TipoUsuario() {
    }

    public TipoUsuario(Integer idTipo) {
        this.idTipo = idTipo;
    }

    public TipoUsuario(Integer idTipo, String admin, String user, String userSpecial) {
        this.idTipo = idTipo;
        this.admin = admin;
        this.user = user;
        this.userSpecial = userSpecial;
    }

    public Integer getIdTipo() {
        return idTipo;
    }

    public void setIdTipo(Integer idTipo) {
        this.idTipo = idTipo;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getUserSpecial() {
        return userSpecial;
    }

    public void setUserSpecial(String userSpecial) {
        this.userSpecial = userSpecial;
    }

    public Collection<Personal> getPersonalCollection() {
        return personalCollection;
    }

    public void setPersonalCollection(Collection<Personal> personalCollection) {
        this.personalCollection = personalCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTipo != null ? idTipo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TipoUsuario)) {
            return false;
        }
        TipoUsuario other = (TipoUsuario) object;
        if ((this.idTipo == null && other.idTipo != null) || (this.idTipo != null && !this.idTipo.equals(other.idTipo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.TipoUsuario[ idTipo=" + idTipo + " ]";
    }
    
}
