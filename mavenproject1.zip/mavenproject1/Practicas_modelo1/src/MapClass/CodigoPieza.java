/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "codigo_pieza", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "CodigoPieza.findAll", query = "SELECT c FROM CodigoPieza c"),
    @NamedQuery(name = "CodigoPieza.findByIdCodigoPieza", query = "SELECT c FROM CodigoPieza c WHERE c.idCodigoPieza = :idCodigoPieza"),
    @NamedQuery(name = "CodigoPieza.findByDescripcion", query = "SELECT c FROM CodigoPieza c WHERE c.descripcion = :descripcion"),
    @NamedQuery(name = "CodigoPieza.findByOrigen", query = "SELECT c FROM CodigoPieza c WHERE c.origen = :origen"),
    @NamedQuery(name = "CodigoPieza.findByObtencion", query = "SELECT c FROM CodigoPieza c WHERE c.obtencion = :obtencion"),
    @NamedQuery(name = "CodigoPieza.findByClasificacion", query = "SELECT c FROM CodigoPieza c WHERE c.clasificacion = :clasificacion"),
    @NamedQuery(name = "CodigoPieza.findByM", query = "SELECT c FROM CodigoPieza c WHERE c.m = :m")})
public class CodigoPieza implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_codigo_pieza")
    private Integer idCodigoPieza;
    @Basic(optional = false)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @Column(name = "origen")
    private String origen;
    @Basic(optional = false)
    @Column(name = "obtencion")
    private String obtencion;
    @Basic(optional = false)
    @Column(name = "clasificacion")
    private String clasificacion;
    @Column(name = "M")
    private String m;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "codigo")
    private DatosPiezas datosPiezas;

    public CodigoPieza() {
    }

    public CodigoPieza(Integer idCodigoPieza) {
        this.idCodigoPieza = idCodigoPieza;
    }

    public CodigoPieza(Integer idCodigoPieza, String descripcion, String origen, String obtencion, String clasificacion) {
        this.idCodigoPieza = idCodigoPieza;
        this.descripcion = descripcion;
        this.origen = origen;
        this.obtencion = obtencion;
        this.clasificacion = clasificacion;
    }

    public Integer getIdCodigoPieza() {
        return idCodigoPieza;
    }

    public void setIdCodigoPieza(Integer idCodigoPieza) {
        this.idCodigoPieza = idCodigoPieza;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getObtencion() {
        return obtencion;
    }

    public void setObtencion(String obtencion) {
        this.obtencion = obtencion;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public DatosPiezas getDatosPiezas() {
        return datosPiezas;
    }

    public void setDatosPiezas(DatosPiezas datosPiezas) {
        this.datosPiezas = datosPiezas;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCodigoPieza != null ? idCodigoPieza.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CodigoPieza)) {
            return false;
        }
        CodigoPieza other = (CodigoPieza) object;
        if ((this.idCodigoPieza == null && other.idCodigoPieza != null) || (this.idCodigoPieza != null && !this.idCodigoPieza.equals(other.idCodigoPieza))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.CodigoPieza[ idCodigoPieza=" + idCodigoPieza + " ]";
    }
    
}
