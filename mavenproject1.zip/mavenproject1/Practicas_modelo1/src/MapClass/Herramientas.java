/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "herramientas", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "Herramientas.findAll", query = "SELECT h FROM Herramientas h"),
    @NamedQuery(name = "Herramientas.findByIdHerramientas", query = "SELECT h FROM Herramientas h WHERE h.idHerramientas = :idHerramientas"),
    @NamedQuery(name = "Herramientas.findByNombre", query = "SELECT h FROM Herramientas h WHERE h.nombre = :nombre"),
    @NamedQuery(name = "Herramientas.findByCantidad", query = "SELECT h FROM Herramientas h WHERE h.cantidad = :cantidad"),
    @NamedQuery(name = "Herramientas.findByProveedor", query = "SELECT h FROM Herramientas h WHERE h.proveedor = :proveedor"),
    @NamedQuery(name = "Herramientas.findByPuesto", query = "SELECT h FROM Herramientas h WHERE h.puesto = :puesto")})
public class Herramientas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_herramientas")
    private Integer idHerramientas;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "cantidad")
    private int cantidad;
    @Basic(optional = false)
    @Column(name = "proveedor")
    private String proveedor;
    @Basic(optional = false)
    @Column(name = "puesto")
    private String puesto;
    @JoinColumn(name = "puestoid_puesto", referencedColumnName = "id_puesto")
    @ManyToOne(optional = false)
    private Puesto puestoidPuesto;

    public Herramientas() {
    }

    public Herramientas(Integer idHerramientas) {
        this.idHerramientas = idHerramientas;
    }

    public Herramientas(Integer idHerramientas, String nombre, int cantidad, String proveedor, String puesto) {
        this.idHerramientas = idHerramientas;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.proveedor = proveedor;
        this.puesto = puesto;
    }

    public Integer getIdHerramientas() {
        return idHerramientas;
    }

    public void setIdHerramientas(Integer idHerramientas) {
        this.idHerramientas = idHerramientas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public Puesto getPuestoidPuesto() {
        return puestoidPuesto;
    }

    public void setPuestoidPuesto(Puesto puestoidPuesto) {
        this.puestoidPuesto = puestoidPuesto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHerramientas != null ? idHerramientas.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Herramientas)) {
            return false;
        }
        Herramientas other = (Herramientas) object;
        if ((this.idHerramientas == null && other.idHerramientas != null) || (this.idHerramientas != null && !this.idHerramientas.equals(other.idHerramientas))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.Herramientas[ idHerramientas=" + idHerramientas + " ]";
    }
    
}
