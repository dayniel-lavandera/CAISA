/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "operaciones", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "Operaciones.findAll", query = "SELECT o FROM Operaciones o"),
    @NamedQuery(name = "Operaciones.findByIdOperaciones", query = "SELECT o FROM Operaciones o WHERE o.idOperaciones = :idOperaciones"),
    @NamedQuery(name = "Operaciones.findByNombreOperacion", query = "SELECT o FROM Operaciones o WHERE o.nombreOperacion = :nombreOperacion"),
    @NamedQuery(name = "Operaciones.findByDescripcion", query = "SELECT o FROM Operaciones o WHERE o.descripcion = :descripcion")})
public class Operaciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_operaciones")
    private Integer idOperaciones;
    @Basic(optional = false)
    @Column(name = "nombre_operacion")
    private String nombreOperacion;
    @Basic(optional = false)
    @Column(name = "descripcion")
    private String descripcion;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "operaciones")
    private Collection<DatosPiezas> datosPiezasCollection;
    @JoinColumn(name = "taller", referencedColumnName = "id_taller")
    @ManyToOne(optional = false)
    private Taller taller;

    public Operaciones() {
    }

    public Operaciones(Integer idOperaciones) {
        this.idOperaciones = idOperaciones;
    }

    public Operaciones(Integer idOperaciones, String nombreOperacion, String descripcion) {
        this.idOperaciones = idOperaciones;
        this.nombreOperacion = nombreOperacion;
        this.descripcion = descripcion;
    }

    public Integer getIdOperaciones() {
        return idOperaciones;
    }

    public void setIdOperaciones(Integer idOperaciones) {
        this.idOperaciones = idOperaciones;
    }

    public String getNombreOperacion() {
        return nombreOperacion;
    }

    public void setNombreOperacion(String nombreOperacion) {
        this.nombreOperacion = nombreOperacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Collection<DatosPiezas> getDatosPiezasCollection() {
        return datosPiezasCollection;
    }

    public void setDatosPiezasCollection(Collection<DatosPiezas> datosPiezasCollection) {
        this.datosPiezasCollection = datosPiezasCollection;
    }

    public Taller getTaller() {
        return taller;
    }

    public void setTaller(Taller taller) {
        this.taller = taller;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idOperaciones != null ? idOperaciones.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Operaciones)) {
            return false;
        }
        Operaciones other = (Operaciones) object;
        if ((this.idOperaciones == null && other.idOperaciones != null) || (this.idOperaciones != null && !this.idOperaciones.equals(other.idOperaciones))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.Operaciones[ idOperaciones=" + idOperaciones + " ]";
    }
    
}
