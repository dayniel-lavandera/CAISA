/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "puesto", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "Puesto.findAll", query = "SELECT p FROM Puesto p"),
    @NamedQuery(name = "Puesto.findByIdPuesto", query = "SELECT p FROM Puesto p WHERE p.idPuesto = :idPuesto"),
    @NamedQuery(name = "Puesto.findByNombrePuesto", query = "SELECT p FROM Puesto p WHERE p.nombrePuesto = :nombrePuesto"),
    @NamedQuery(name = "Puesto.findByPuesto", query = "SELECT p FROM Puesto p WHERE p.puesto = :puesto"),
    @NamedQuery(name = "Puesto.findByGrupo", query = "SELECT p FROM Puesto p WHERE p.grupo = :grupo")})
public class Puesto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_puesto")
    private Integer idPuesto;
    @Basic(optional = false)
    @Column(name = "nombre_puesto")
    private String nombrePuesto;
    @Basic(optional = false)
    @Column(name = "puesto")
    private String puesto;
    @Basic(optional = false)
    @Column(name = "grupo")
    private String grupo;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "puestoidPuesto")
    private Collection<Herramientas> herramientasCollection;
    @JoinColumn(name = "taller", referencedColumnName = "id_taller")
    @ManyToOne(optional = false)
    private Taller taller;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "puestoidPuesto")
    private Collection<Insumos> insumosCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "puesto")
    private Collection<DatosPiezas> datosPiezasCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "puestoidPuesto")
    private Collection<Personal> personalCollection;

    public Puesto() {
    }

    public Puesto(Integer idPuesto) {
        this.idPuesto = idPuesto;
    }

    public Puesto(Integer idPuesto, String nombrePuesto, String puesto, String grupo) {
        this.idPuesto = idPuesto;
        this.nombrePuesto = nombrePuesto;
        this.puesto = puesto;
        this.grupo = grupo;
    }

    public Integer getIdPuesto() {
        return idPuesto;
    }

    public void setIdPuesto(Integer idPuesto) {
        this.idPuesto = idPuesto;
    }

    public String getNombrePuesto() {
        return nombrePuesto;
    }

    public void setNombrePuesto(String nombrePuesto) {
        this.nombrePuesto = nombrePuesto;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public Collection<Herramientas> getHerramientasCollection() {
        return herramientasCollection;
    }

    public void setHerramientasCollection(Collection<Herramientas> herramientasCollection) {
        this.herramientasCollection = herramientasCollection;
    }

    public Taller getTaller() {
        return taller;
    }

    public void setTaller(Taller taller) {
        this.taller = taller;
    }

    public Collection<Insumos> getInsumosCollection() {
        return insumosCollection;
    }

    public void setInsumosCollection(Collection<Insumos> insumosCollection) {
        this.insumosCollection = insumosCollection;
    }

    public Collection<DatosPiezas> getDatosPiezasCollection() {
        return datosPiezasCollection;
    }

    public void setDatosPiezasCollection(Collection<DatosPiezas> datosPiezasCollection) {
        this.datosPiezasCollection = datosPiezasCollection;
    }

    public Collection<Personal> getPersonalCollection() {
        return personalCollection;
    }

    public void setPersonalCollection(Collection<Personal> personalCollection) {
        this.personalCollection = personalCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPuesto != null ? idPuesto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Puesto)) {
            return false;
        }
        Puesto other = (Puesto) object;
        if ((this.idPuesto == null && other.idPuesto != null) || (this.idPuesto != null && !this.idPuesto.equals(other.idPuesto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.Puesto[ idPuesto=" + idPuesto + " ]";
    }
    
}
