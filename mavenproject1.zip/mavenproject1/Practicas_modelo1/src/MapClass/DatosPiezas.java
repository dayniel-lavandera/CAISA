/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MapClass;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author JuanMi025
 */
@Entity
@Table(name = "datos_piezas", catalog = "0", schema = "public")
@NamedQueries({
    @NamedQuery(name = "DatosPiezas.findAll", query = "SELECT d FROM DatosPiezas d"),
    @NamedQuery(name = "DatosPiezas.findByIdPieza", query = "SELECT d FROM DatosPiezas d WHERE d.idPieza = :idPieza"),
    @NamedQuery(name = "DatosPiezas.findByNumero", query = "SELECT d FROM DatosPiezas d WHERE d.numero = :numero"),
    @NamedQuery(name = "DatosPiezas.findByCantidad", query = "SELECT d FROM DatosPiezas d WHERE d.cantidad = :cantidad"),
    @NamedQuery(name = "DatosPiezas.findByDiseno", query = "SELECT d FROM DatosPiezas d WHERE d.diseno = :diseno"),
    @NamedQuery(name = "DatosPiezas.findByControlFisico", query = "SELECT d FROM DatosPiezas d WHERE d.controlFisico = :controlFisico"),
    @NamedQuery(name = "DatosPiezas.findByObssevaciones", query = "SELECT d FROM DatosPiezas d WHERE d.obssevaciones = :obssevaciones"),
    @NamedQuery(name = "DatosPiezas.findBySobrante", query = "SELECT d FROM DatosPiezas d WHERE d.sobrante = :sobrante"),
    @NamedQuery(name = "DatosPiezas.findByCausa", query = "SELECT d FROM DatosPiezas d WHERE d.causa = :causa")})
public class DatosPiezas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_pieza")
    private Integer idPieza;
    @Basic(optional = false)
    @Column(name = "numero")
    private int numero;
    @Basic(optional = false)
    @Column(name = "cantidad")
    private int cantidad;
    @Basic(optional = false)
    @Column(name = "diseno")
    private String diseno;
    @Basic(optional = false)
    @Column(name = "control_fisico")
    private String controlFisico;
    @Column(name = "obssevaciones")
    private String obssevaciones;
    @Column(name = "sobrante")
    private Integer sobrante;
    @Column(name = "causa")
    private String causa;
    @JoinColumn(name = "codigo", referencedColumnName = "id_codigo_pieza")
    @OneToOne(optional = false)
    private CodigoPieza codigo;
    @JoinColumn(name = "operaciones", referencedColumnName = "id_operaciones")
    @ManyToOne(optional = false)
    private Operaciones operaciones;
    @JoinColumn(name = "puesto", referencedColumnName = "id_puesto")
    @ManyToOne(optional = false)
    private Puesto puesto;

    public DatosPiezas() {
    }

    public DatosPiezas(Integer idPieza) {
        this.idPieza = idPieza;
    }

    public DatosPiezas(Integer idPieza, int numero, int cantidad, String diseno, String controlFisico) {
        this.idPieza = idPieza;
        this.numero = numero;
        this.cantidad = cantidad;
        this.diseno = diseno;
        this.controlFisico = controlFisico;
    }

    public Integer getIdPieza() {
        return idPieza;
    }

    public void setIdPieza(Integer idPieza) {
        this.idPieza = idPieza;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDiseno() {
        return diseno;
    }

    public void setDiseno(String diseno) {
        this.diseno = diseno;
    }

    public String getControlFisico() {
        return controlFisico;
    }

    public void setControlFisico(String controlFisico) {
        this.controlFisico = controlFisico;
    }

    public String getObssevaciones() {
        return obssevaciones;
    }

    public void setObssevaciones(String obssevaciones) {
        this.obssevaciones = obssevaciones;
    }

    public Integer getSobrante() {
        return sobrante;
    }

    public void setSobrante(Integer sobrante) {
        this.sobrante = sobrante;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public CodigoPieza getCodigo() {
        return codigo;
    }

    public void setCodigo(CodigoPieza codigo) {
        this.codigo = codigo;
    }

    public Operaciones getOperaciones() {
        return operaciones;
    }

    public void setOperaciones(Operaciones operaciones) {
        this.operaciones = operaciones;
    }

    public Puesto getPuesto() {
        return puesto;
    }

    public void setPuesto(Puesto puesto) {
        this.puesto = puesto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPieza != null ? idPieza.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DatosPiezas)) {
            return false;
        }
        DatosPiezas other = (DatosPiezas) object;
        if ((this.idPieza == null && other.idPieza != null) || (this.idPieza != null && !this.idPieza.equals(other.idPieza))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.Informatico.DatosPiezas[ idPieza=" + idPieza + " ]";
    }
    
}
