/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;


import configuracion.ConexionBD;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import model.Pieza;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import java.sql.SQLException;
import javax.swing.JOptionPane;

public class PiezaDAO {

    private Connection getConnection() throws SQLException {
        // Cambia estos parámetros por los de tu configuración
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/Caisa", "postgres", "24682468");
    }

    public boolean agregarPieza(Pieza pieza) {
        String query = "INSERT INTO datos_piezas (numero, codigo, cantidad, diseño, control_fisico, observaciones, sobrante, causa, puestoid_puesto, operacionesid_operaciones, puestoid_puesto2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, pieza.getNumero());
            stmt.setInt(2, pieza.getCodigo());
            stmt.setInt(3, pieza.getCantidad());
            stmt.setInt(4, pieza.getDiseño());
            stmt.setString(5, pieza.getControlFisico());
            stmt.setString(6, pieza.getObservaciones());
            stmt.setInt(7, pieza.getSobrante());
            stmt.setString(8, pieza.getCausa());
            stmt.setInt(9, pieza.getPuestoIdPuesto());
            stmt.setInt(10, pieza.getOperacionesIdOperaciones());
            stmt.setInt(11, pieza.getPuestoIdPuesto2());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Retorna true si se insertó al menos una fila
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminarPieza(int idPieza) {
        String query = "DELETE FROM datos_piezas WHERE id_pieza = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, idPieza);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean actualizarPieza(Pieza pieza) {
        String query = "UPDATE datos_piezas SET numero = ?, codigo = ?, cantidad = ?, diseño = ?, control_fisico = ?, observaciones = ?, sobrante = ?, causa = ?, puestoid_puesto = ?, operacionesid_operaciones = ?, puestoid_puesto2 = ? WHERE id_pieza = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, pieza.getNumero());
            stmt.setInt(2, pieza.getCodigo());
            stmt.setInt(3, pieza.getCantidad());
            stmt.setInt(4, pieza.getDiseño());
            stmt.setString(5, pieza.getControlFisico());
            stmt.setString(6, pieza.getObservaciones());
            stmt.setInt(7, pieza.getSobrante());
            stmt.setString(8, pieza.getCausa());
            stmt.setInt(9, pieza.getPuestoIdPuesto());
            stmt.setInt(10, pieza.getOperacionesIdOperaciones());
            stmt.setInt(11, pieza.getPuestoIdPuesto2());
            stmt.setInt(12, pieza.getIdPieza());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Pieza> cargarDatos() {
        List<Pieza> listaPiezas = new ArrayList<>();
        String query = "SELECT * FROM datos_piezas";

        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int idPieza = rs.getInt("id_pieza");
                int numero = rs.getInt("numero");
                int codigo = rs.getInt("codigo");
                int cantidad = rs.getInt("cantidad");
                int diseño = rs.getInt("diseño");
                String controlFisico = rs.getString("control_fisico");
                String observaciones = rs.getString("observaciones");
                int sobrante = rs.getInt("sobrante");
                String causa = rs.getString("causa");
                int puestoIdPuesto = rs.getInt("puestoid_puesto");
                int operacionesIdOperaciones = rs.getInt("operacionesid_operaciones");
                int puestoIdPuesto2 = rs.getInt("puestoid_puesto2");

                listaPiezas.add(new Pieza(idPieza, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoIdPuesto, operacionesIdOperaciones, puestoIdPuesto2));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaPiezas;
    }

    public void exportarDatosTXT() throws IOException {
        String query = "SELECT * FROM datos_piezas";
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query);
             PrintWriter writer = new PrintWriter(new FileWriter("piezas.txt"))) {

            while (rs.next()) {
                int idPieza = rs.getInt("id_pieza");
                int numero = rs.getInt("numero");
                int codigo = rs.getInt("codigo");
                int cantidad = rs.getInt("cantidad");
                int diseño = rs.getInt("diseño");
                String controlFisico = rs.getString("control_fisico");
                String observaciones = rs.getString("observaciones");
                int sobrante = rs.getInt("sobrante");
                String causa = rs.getString("causa");
                int puestoIdPuesto = rs.getInt("puestoid_puesto");
                int operacionesIdOperaciones = rs.getInt("operacionesid_operaciones");
                int puestoIdPuesto2 = rs.getInt("puestoid_puesto2");

                writer.printf("%d\t%d\t%d\t%d\t%d\t%s\t%s\t%d\t%s\t%d\t%d\t%d%n",
                        idPieza, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoIdPuesto, operacionesIdOperaciones, puestoIdPuesto2);
            }
            System.out.println("Datos exportados correctamente a piezas.txt");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
    
    public Pieza obtenerPiezaPorId(int idPieza) {
        Pieza pieza = null;
        String query = "SELECT * FROM datos_piezas WHERE id_pieza = ?";

        try (PreparedStatement stmt = ConexionBD.prepareStatement(query)) {
            stmt.setInt(1, idPieza);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int numero = rs.getInt("numero");
                int codigo = rs.getInt("codigo");
                int cantidad = rs.getInt("cantidad");
                int diseño = rs.getInt("diseño");
                String controlFisico = rs.getString("control_fisico");
                String observaciones = rs.getString("observaciones");
                int sobrante = rs.getInt("sobrante");
                String causa = rs.getString("causa");
                int puestoidPuesto = rs.getInt("puestoid_puesto");
                int operacionesidOperaciones = rs.getInt("operacionesid_operaciones");
                int puestoidPuesto2 = rs.getInt("puestoid_puesto2");

                pieza = new Pieza(idPieza, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoidPuesto, operacionesidOperaciones, puestoidPuesto2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener la pieza: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return pieza;
}

}
