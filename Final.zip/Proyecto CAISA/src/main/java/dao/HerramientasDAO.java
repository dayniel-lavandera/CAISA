package dao;

import configuracion.ConexionBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Herramienta;

public class HerramientasDAO {
 private static final String URL = "jdbc:mysql://localhost:3306/mi_base_de_datos";
    private static final String USER = "usuario";
    private static final String PASSWORD = "contraseña";
    private static ThreadLocal<Connection> connectionThreadLocal = new ThreadLocal<>();

    // Obtiene una conexión a la base de datos
    public static Connection getConnection() {
        Connection connection = connectionThreadLocal.get();
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                connectionThreadLocal.set(connection);
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
        }
        return connection;
    }

    // Cierra la conexión a la base de datos
    public static void closeConnection() {
        Connection connection = connectionThreadLocal.get();
        if (connection != null) {
            try {
                connection.close();
                connectionThreadLocal.remove();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

 public List<Herramienta> obtenerHerramientas() {
        List<Herramienta> herramientas = new ArrayList<>();
        Connection conexion = ConexionBD.getConnection();

        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return herramientas;
        }

        String sql = "SELECT id_herramienta, nombre, cantidad, proveedor, puesto, puestoid_puesto FROM herramientas";

        try (PreparedStatement preparedStatement = conexion.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int idHerramienta = resultSet.getInt("id_herramienta");
                String nombre = resultSet.getString("nombre");
                String cantidad = resultSet.getString("cantidad");
                String proveedor = resultSet.getString("proveedor");
                int puesto = resultSet.getInt("puesto");
                int puestoidPuesto = resultSet.getInt("puestoid_puesto");

                herramientas.add(new Herramienta(idHerramienta, nombre, cantidad, proveedor, puesto, puestoidPuesto));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener los datos de la tabla Herramientas.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConexionBD.closeConnection();
        }

        return herramientas;
    }
public boolean agregarHerramienta(Herramienta herramienta) {
    Connection conexion = null;
    PreparedStatement preparedStatement = null;

    try {
        conexion = ConexionBD.getConnection();
        if (conexion == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "INSERT INTO herramientas (nombre, cantidad, proveedor, puesto, puestoid_puesto) VALUES (?, ?, ?, ?, ?)";
        preparedStatement = conexion.prepareStatement(sql);

        // Establece los parámetros en el PreparedStatement
        preparedStatement.setString(1, herramienta.getNombre());
        preparedStatement.setString(2, herramienta.getCantidad());
        preparedStatement.setString(3, herramienta.getProveedor());
        preparedStatement.setInt(4, herramienta.getPuesto());
        preparedStatement.setInt(5, herramienta.getPuestoidPuesto());

        // Ejecuta la actualización
        int rowsInserted = preparedStatement.executeUpdate();
        return rowsInserted > 0;

    } catch (SQLException e) {
        e.printStackTrace();  // Imprime el error en la consola
        JOptionPane.showMessageDialog(null, "Error al agregar la herramienta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;

    } finally {
        // Asegúrate de cerrar el PreparedStatement y la conexión en el bloque finally
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conexion != null) {
            ConexionBD.closeConnection();
        }
    }
}


 public Herramienta obtenerHerramientaPorId(int idHerramienta) {
        String SELECT_HERRAMIENTA_BY_ID = "SELECT id_herramienta, nombre, cantidad, proveedor, puesto, puestoid_puesto FROM herramientas WHERE id_herramienta = ?";
        Herramienta herramienta = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = ConexionBD.getConnection();
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }

            preparedStatement = connection.prepareStatement(SELECT_HERRAMIENTA_BY_ID);
            preparedStatement.setInt(1, idHerramienta);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                String cantidad = resultSet.getString("cantidad");
                String proveedor = resultSet.getString("proveedor");
                int puesto = resultSet.getInt("puesto");
                int puestoidPuesto = resultSet.getInt("puestoid_puesto");

                herramienta = new Herramienta(idHerramienta, nombre, cantidad, proveedor, puesto, puestoidPuesto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener la herramienta por ID.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    ConexionBD.closeConnection();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        return herramienta;
    }

 public boolean actualizarHerramienta(Herramienta herramienta) {
        String UPDATE_HERRAMIENTA_SQL = "UPDATE herramientas SET nombre = ?, cantidad = ?, proveedor = ?, puesto = ?, puestoid_puesto = ? WHERE id_herramienta = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = ConexionBD.getConnection();
            if (connection == null) {
                JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            preparedStatement = connection.prepareStatement(UPDATE_HERRAMIENTA_SQL);
            preparedStatement.setString(1, herramienta.getNombre());
            preparedStatement.setString(2, herramienta.getCantidad());
            preparedStatement.setString(3, herramienta.getProveedor());
            preparedStatement.setInt(4, herramienta.getPuesto());
            preparedStatement.setInt(5, herramienta.getPuestoidPuesto());
            preparedStatement.setInt(6, herramienta.getIdHerramienta());

            int rowsUpdated = preparedStatement.executeUpdate();
            return rowsUpdated > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al actualizar la herramienta.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    ConexionBD.closeConnection();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }    

 public boolean eliminarHerramienta(int idHerramienta) {
    Connection conexion = ConexionBD.getConnection();
    if (conexion == null) {
        JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    String sql = "DELETE FROM herramientas WHERE id_herramienta = ?";
    try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
        pstmt.setInt(1, idHerramienta);
        int affectedRows = pstmt.executeUpdate();
        return affectedRows > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al eliminar la herramienta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    } finally {
        ConexionBD.closeConnection();
    }
}

    
    
    
}
