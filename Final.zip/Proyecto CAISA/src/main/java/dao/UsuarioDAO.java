package dao;

import com.unah.modelos.Usuario;
import configuracion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class UsuarioDAO {
public List<Usuario> cargarDatos() {
    List<Usuario> usuarios = new ArrayList<>();
    Connection conexion = ConexionBD.getConnection();

    if (conexion == null) {
        JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return usuarios;
    }

    // Usa comillas dobles para el nombre exacto de la tabla
    String sql = "SELECT id_usuario, nombre, password, \"Rol\" FROM \"Usuarios\"";

    try (PreparedStatement preparedStatement = conexion.prepareStatement(sql);
         ResultSet resultSet = preparedStatement.executeQuery()) {

        while (resultSet.next()) {
            int idUsuario = resultSet.getInt("id_usuario");
            String nombre = resultSet.getString("nombre");
            String password = resultSet.getString("password");
            String rol = resultSet.getString("Rol");

            // Usa el constructor adecuado
            usuarios.add(new Usuario(idUsuario, nombre, password, rol));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al obtener los datos de la tabla Usuarios.", "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        ConexionBD.closeConnection();
    }

    return usuarios;
}


// Método para agregar un usuario a la base de datos
public boolean agregarUsuario(Usuario usuario) {
    String sql = "INSERT INTO \"Usuarios\" (id_usuario, nombre, password, \"Rol\") VALUES (?, ?, ?, ?)";

    try (PreparedStatement pstmt = ConexionBD.getConnection().prepareStatement(sql)) {
        pstmt.setInt(1, usuario.getId());
        pstmt.setString(2, usuario.getNombre());
        pstmt.setString(3, usuario.getPassword());
        pstmt.setString(4, usuario.getRolString()); // Usa getRolString() para obtener el rol en formato String

        int filasAfectadas = pstmt.executeUpdate();
        return filasAfectadas > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
public boolean eliminarUsuario(int id) {
    String sql = "DELETE FROM \"Usuarios\" WHERE id_usuario = ?";
    
    try (PreparedStatement pstmt = ConexionBD.getConnection().prepareStatement(sql)) {
        pstmt.setInt(1, id);
        int filasAfectadas = pstmt.executeUpdate();
        return filasAfectadas > 0;
    } catch (SQLException e) {
        System.err.println("Error al eliminar usuario: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

 public boolean existeUsuario(int idUsuario) {
        String sql = "SELECT COUNT(*) FROM \"Usuarios\" WHERE id_usuario = ?";

        try (PreparedStatement pstmt = ConexionBD.prepareStatement(sql)) {
            pstmt.setInt(1, idUsuario);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean existeNombreUsuario(String nombre) {
        String sql = "SELECT COUNT(*) FROM \"Usuarios\" WHERE nombre = ?";

        try (PreparedStatement pstmt = ConexionBD.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

  public Usuario obtenerUsuarioPorId(int idUsuario) {
        String sql = "SELECT * FROM \"Usuarios\" WHERE id_usuario = ?";

        try (PreparedStatement pstmt = ConexionBD.prepareStatement(sql)) {
            pstmt.setInt(1, idUsuario);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("nombre"),
                    rs.getString("password"),
                    rs.getString("Rol")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
public boolean actualizarUsuario(Usuario usuario) {
    String sql = "UPDATE \"Usuarios\" SET nombre = ?, password = ?, \"Rol\" = ? WHERE id_usuario = ?";

    try (Connection con = ConexionBD.getConnection(); // Obtener conexión
         PreparedStatement ps = con.prepareStatement(sql)) { // Preparar declaración SQL

        // Verifica que la conexión esté activa
        if (con == null || con.isClosed()) {
            throw new SQLException("La conexión a la base de datos está cerrada.");
        }

        // Obtener el valor del rol y hacer debug
        String rol = usuario.getRol().name(); // Asegúrate de que Rol es un Enum y usa .name() para obtener el valor en String
        System.out.println("Rol a actualizar: " + rol);

        // Establecer los parámetros en la consulta
        ps.setString(1, usuario.getNombre());      // Establecer el nombre
        ps.setString(2, usuario.getPassword());    // Establecer la contraseña
        ps.setString(3, rol);                      // Establecer el rol
        ps.setInt(4, usuario.getId());             // Establecer el ID del usuario

        // Ejecutar la actualización
        int rowsAffected = ps.executeUpdate();
        
        // Retornar verdadero si se actualizó al menos una fila, de lo contrario, falso
        return rowsAffected > 0;
    } catch (SQLException e) {
        // Imprimir la traza del error
        System.err.println("Error al actualizar el usuario: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

}