/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas.ver;


import static com.unah.vista.Herramientas.jTable1;
import model.Herramienta;
import configuracion.ConexionBD;
import dao.HerramientasDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/**
 *
 * @author pango
 */
public class HerramientasVER extends javax.swing.JFrame {

    
    private HerramientasDAO herramientasDAO;    public HerramientasVER() {
      
     initComponents();
   herramientasDAO = new HerramientasDAO();
        cargarDatosTabla();   
 
 }
 private void cargarDatosTabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        List<Herramienta> herramientas = herramientasDAO.obtenerHerramientas();

        for (Herramienta herramienta : herramientas) {
            modeloTabla.addRow(new Object[]{
                herramienta.getIdHerramienta(),
                herramienta.getNombre(),
                herramienta.getCantidad(),
                herramienta.getProveedor(),
                herramienta.getPuesto(),
                herramienta.getPuestoidPuesto()
            
            });
        
            
        }
 
}

 
 private void mostrarDialogoFiltroHerramientas() {
    String[] opcionesFiltro = {"ID", "Nombre", "Cantidad", "Proveedor", "Puesto"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrdenHerramientas(columnasSeleccionadas, ordenSeleccionado);
    }
}

 private void aplicarFiltroYOrdenHerramientas(List<String> columnasSeleccionadas, String orden) {
    // Cargar todos los datos de herramientas desde la base de datos
    List<Herramienta> herramientas = herramientasDAO.obtenerHerramientas();

    // Ordenar la lista de herramientas
    herramientas.sort((h1, h2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(h1.getIdHerramienta(), h2.getIdHerramienta());
                    break;
                case "Nombre":
                    comparacion = h1.getNombre().compareTo(h2.getNombre());
                    break;
                case "Cantidad":
                    comparacion = h1.getCantidad().compareTo(h2.getCantidad());
                    break;
                case "Proveedor":
                    comparacion = h1.getProveedor().compareTo(h2.getProveedor());
                    break;
                case "Puesto":
                    comparacion = Integer.compare(h1.getPuesto(), h2.getPuesto());
                    break;
                case "Puesto ID":
                    comparacion = Integer.compare(h1.getPuestoidPuesto(), h2.getPuestoidPuesto());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla dinámicamente basado en las columnas seleccionadas
    DefaultTableModel modeloTabla = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modeloTabla);

    // Llenar el modelo de la tabla con los datos filtrados y ordenados
    for (Herramienta herramienta : herramientas) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(herramienta.getIdHerramienta());
                    break;
                case "Nombre":
                    fila.add(herramienta.getNombre());
                    break;
                case "Cantidad":
                    fila.add(herramienta.getCantidad());
                    break;
                case "Proveedor":
                    fila.add(herramienta.getProveedor());
                    break;
                case "Puesto":
                    fila.add(herramienta.getPuesto());
                    break;
                case "Puesto ID":
                    fila.add(herramienta.getPuestoidPuesto());
                    break;
            }
        }
        modeloTabla.addRow(fila.toArray());
    }
}

 private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}

  private void mostrarDialogoBusqueda() {
        JDialog dialogoBusqueda = new JDialog(this, "Buscar Herramientas", true);
        dialogoBusqueda.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        // Campo de texto para el término de búsqueda
        JTextField campoBusqueda = new JTextField();
        dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
        gbc.gridy++;
        dialogoBusqueda.add(campoBusqueda, gbc);

        // Opciones de columnas para buscar
        String[] opcionesFiltro = {"ID", "Nombre", "Cantidad", "Proveedor", "Puesto", "Puesto ID"};
        JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
        JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
        for (int i = 0; i < opcionesFiltro.length; i++) {
            checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
            checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
            panelOpciones.add(checkBoxes[i]);
        }
        gbc.gridy++;
        gbc.gridwidth = 2;
        dialogoBusqueda.add(panelOpciones, gbc);

        // Botón para realizar la búsqueda
        JButton botonBuscar = new JButton("Buscar");
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        dialogoBusqueda.add(botonBuscar, gbc);

        // Acción del botón de búsqueda
        botonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoBusqueda = campoBusqueda.getText().trim();
                List<String> columnasSeleccionadas = new ArrayList<>();
                for (JCheckBox checkBox : checkBoxes) {
                    if (checkBox.isSelected()) {
                        columnasSeleccionadas.add(checkBox.getText());
                    }
                }
                List<Herramienta> resultadosBusqueda = buscarHerramientas(textoBusqueda, columnasSeleccionadas);
                actualizarTablaConResultados(resultadosBusqueda);
                dialogoBusqueda.dispose();
            }
        });

        dialogoBusqueda.pack();
        dialogoBusqueda.setLocationRelativeTo(this);
        dialogoBusqueda.setVisible(true);
    }

    private List<Herramienta> buscarHerramientas(String textoBusqueda, List<String> columnasSeleccionadas) {
        if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
            return herramientasDAO.obtenerHerramientas();
        }

        String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

        List<Herramienta> herramientas = herramientasDAO.obtenerHerramientas();

        return herramientas.stream()
            .filter(herramienta -> {
                // Convertir los valores de las propiedades a minúsculas para la comparación
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID")) {
                    texto = String.valueOf(herramienta.getIdHerramienta()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Nombre")) {
                    texto = herramienta.getNombre().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Cantidad")) {
                    texto = herramienta.getCantidad().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Proveedor")) {
                    texto = herramienta.getProveedor().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Puesto")) {
                    texto = String.valueOf(herramienta.getPuesto()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Puesto ID")) {
                    texto = String.valueOf(herramienta.getPuestoidPuesto()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }

                return match;
            })
            .collect(Collectors.toList());
    }

    private void actualizarTablaConResultados(List<Herramienta> herramientasFiltradas) {
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        // Añadir las herramientas filtradas al modelo de la tabla
        for (Herramienta herramienta : herramientasFiltradas) {
            modeloTabla.addRow(new Object[]{
                herramienta.getIdHerramienta(),
                herramienta.getNombre(),
                herramienta.getCantidad(),
                herramienta.getProveedor(),
                herramienta.getPuesto(),
                herramienta.getPuestoidPuesto()
            });
        }
    }
 
 
 private void exportarDatosATxt() {
    JFileChooser fileChooser = new JFileChooser();
    int resultado = fileChooser.showSaveDialog(null);

    if (resultado == JFileChooser.APPROVE_OPTION) {
        File archivo = fileChooser.getSelectedFile();
        String rutaArchivo = archivo.getAbsolutePath();

        if (!rutaArchivo.endsWith(".txt")) {
            rutaArchivo += ".txt";
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            List<Herramienta> herramientas = herramientasDAO.obtenerHerramientas();
            for (Herramienta herramienta : herramientas) {
                writer.write(herramienta.getIdHerramienta() + "\t" +
                             herramienta.getNombre() + "\t" +
                             herramienta.getCantidad() + "\t" +
                             herramienta.getProveedor() + "\t" +
                             herramienta.getPuesto() + "\t" +
                             herramienta.getPuestoidPuesto());
                writer.newLine();
            }
            JOptionPane.showMessageDialog(null, "Datos exportados correctamente a " + rutaArchivo, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al exportar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Herramienta", "Nombre", "Cantidad", "Proveedor", "Puesto", "Puesto ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jLabel9.setText("Herramientas");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 896, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltroHerramientas(); // Llamar al método para agregar insumo
            }
        });
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                actualizarJFrame();
            }
        });  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
  jLabel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
exportarDatosATxt();
            }
        });        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
 jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();
    }
});         // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HerramientasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HerramientasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HerramientasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HerramientasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HerramientasVER().setVisible(true);
          
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    


    private static class ExportarTXT {

       public static void exportarTablaATXT(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar como");
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileChooser.getSelectedFile() + ".txt"))) {
                TableModel model = table.getModel();

                // Escribir encabezados
                for (int i = 0; i < model.getColumnCount(); i++) {
                    writer.write(model.getColumnName(i) + "\t");
                }
                writer.write("\n");

                // Escribir filas de datos
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        writer.write(model.getValueAt(i, j).toString() + "\t");
                    }
                    writer.write("\n");
                }

                JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a TXT.");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al exportar los datos a TXT: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    }

    private static class ExportarPDF {

       
    public static void exportarTablaAPDF(JTable table) {
        JFileChooser fileChooser = new JFileChooser();

    }
}
}
