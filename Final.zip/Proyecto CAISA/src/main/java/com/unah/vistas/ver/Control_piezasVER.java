/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas.ver;


import static com.unah.vista.Control_piezas.jTable1;
import dao.PiezaDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Pieza;



/**
 *
 * @author pango
 */
public class Control_piezasVER extends javax.swing.JFrame {
private PiezaDAO piezaDAO;
    /**
     * Creates new form Control_piezas
     */
    public Control_piezasVER() {
        initComponents();
    piezaDAO = new PiezaDAO(); // Crea una instancia del DAO
        cargarDatosTabla();
    
    
    }
private void cargarDatosTabla() {
    // Verifica que jTable1 no sea null
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

    // Obtén el modelo de la tabla
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Obtener los datos desde el DAO
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Definir los nombres de las columnas
    String[] columnNames = {"ID", "Número", "Código", "Cantidad", "Diseño", "Control Físico", "Observaciones", "Sobrante", "Causa", "Puesto ID", "Operaciones ID", "Puesto ID 2"};

    // Crear el modelo de la tabla con los nombres de las columnas
    DefaultTableModel modelo = new DefaultTableModel(columnNames, 0);
    jTable1.setModel(modelo);

    // Agregar los datos al modelo de la tabla
    for (Pieza pieza : listaPiezas) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}

private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}
private void mostrarDialogoFiltro() {
    String[] opcionesFiltro = {"ID", "Número", "Código", "Cantidad", "Diseño"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrden(columnasSeleccionadas, ordenSeleccionado);
    }
}
private void aplicarFiltroYOrden(List<String> columnasSeleccionadas, String orden) {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Ordenar la lista
    listaPiezas.sort((p1, p2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(p1.getIdPieza(), p2.getIdPieza());
                    break;
                case "Número":
                    comparacion = Integer.compare(p1.getNumero(), p2.getNumero());
                    break;
                case "Código":
                    comparacion = Integer.compare(p1.getCodigo(), p2.getCodigo());
                    break;
                case "Cantidad":
                    comparacion = Integer.compare(p1.getCantidad(), p2.getCantidad());
                    break;
                case "Diseño":
                    comparacion = Integer.compare(p1.getDiseño(), p2.getDiseño());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla con las columnas seleccionadas
    DefaultTableModel modelo = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modelo);

    // Agregar los datos filtrados y ordenados al modelo de la tabla
    for (Pieza pieza : listaPiezas) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(pieza.getIdPieza());
                    break;
                case "Número":
                    fila.add(pieza.getNumero());
                    break;
                case "Código":
                    fila.add(pieza.getCodigo());
                    break;
                case "Cantidad":
                    fila.add(pieza.getCantidad());
                    break;
                case "Diseño":
                    fila.add(pieza.getDiseño());
                    break;
            }
        }
        modelo.addRow(fila.toArray());
    }
}
private void mostrarDialogoBusqueda() {
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Piezas", true);
    dialogoBusqueda.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;

    // Campo de texto para el término de búsqueda
    JTextField campoBusqueda = new JTextField();
    dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
    gbc.gridy++;
    dialogoBusqueda.add(campoBusqueda, gbc);

    // Opciones de columnas para buscar
    String[] opcionesFiltro = {"ID Pieza", "Número", "Código", "Cantidad", "Diseño"};
    JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
        panelOpciones.add(checkBoxes[i]);
    }
    gbc.gridy++;
    gbc.gridwidth = 2;
    dialogoBusqueda.add(panelOpciones, gbc);

    // Botón para realizar la búsqueda
    JButton botonBuscar = new JButton("Buscar");
    gbc.gridwidth = 1;
    gbc.gridy++;
    gbc.gridx = 0;
    dialogoBusqueda.add(botonBuscar, gbc);

    // Acción del botón de búsqueda
    botonBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String textoBusqueda = campoBusqueda.getText().trim();
            List<String> columnasSeleccionadas = new ArrayList<>();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    columnasSeleccionadas.add(checkBox.getText());
                }
            }
            List<Pieza> resultadosBusqueda = buscarPiezas(textoBusqueda, columnasSeleccionadas);
            actualizarTablaConResultados(resultadosBusqueda);
            dialogoBusqueda.dispose();
        }
    });

    dialogoBusqueda.pack();
    dialogoBusqueda.setLocationRelativeTo(this);
    dialogoBusqueda.setVisible(true);
}

private List<Pieza> buscarPiezas(String textoBusqueda, List<String> columnasSeleccionadas) {
    if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
        return piezaDAO.cargarDatos();
    }

    String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

    List<Pieza> piezasList = piezaDAO.cargarDatos();

    return piezasList.stream()
            .filter(pieza -> {
                // Convertir los valores de las propiedades a minúsculas para la comparación
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Pieza")) {
                    texto = String.valueOf(pieza.getIdPieza()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Número")) {
                    texto = String.valueOf(pieza.getNumero()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Código")) {
                    texto = String.valueOf(pieza.getCodigo()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Cantidad Adicional")) {
                    texto = String.valueOf(pieza.getCantidad()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Diseño")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                    if (columnasSeleccionadas.contains("Cantidad")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                
                     if (columnasSeleccionadas.contains("Control Fisico")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                } 
                    
                    return match;
            })
            .collect(Collectors.toList());
}


private void actualizarTablaConResultados(List<Pieza> piezasFiltrado) {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Añadir las piezas filtradas al modelo de la tabla
    for (Pieza pieza : piezasFiltrado) {
        modeloTabla.addRow(new Object[]{
                pieza.getIdPieza(),
                pieza.getNumero(),
                pieza.getCodigo(),
                pieza.getCantidad(),
                pieza.getDiseño()
        });
    }
}
 
private void exportarDatosATxt() {
    // Solicitar el nombre del archivo al usuario
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(null);

    if (userSelection != JFileChooser.APPROVE_OPTION) {
        return; // Usuario canceló la operación
    }

    File fileToSave = fileChooser.getSelectedFile();
    
    // Verificar si el archivo ya tiene una extensión
    String filePath = fileToSave.getPath();
    if (!filePath.endsWith(".txt")) {
        filePath += ".txt";
    }

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        // Obtener el modelo de la tabla
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();

        // Escribir los nombres de las columnas
        for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
            writer.write(modeloTabla.getColumnName(i));
            if (i < modeloTabla.getColumnCount() - 1) {
                writer.write("\t"); // Separar columnas por tabulador
            }
        }
        writer.newLine();

        // Escribir los datos de las filas
        for (int row = 0; row < modeloTabla.getRowCount(); row++) {
            for (int col = 0; col < modeloTabla.getColumnCount(); col++) {
                writer.write(modeloTabla.getValueAt(row, col).toString());
                if (col < modeloTabla.getColumnCount() - 1) {
                    writer.write("\t"); // Separar columnas por tabulador
                }
            }
            writer.newLine();
        }

        JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a " + filePath, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(null, "Error al exportar los datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Pieza", "Número", "Código", "Cantidad Adicional", "Diseño", "Cantidad", "Control FÍsico", "Observaciones", "Sobrante", "Causas", "Operaciones ID ", "Puesto ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jLabel8.setText("Piezas ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1247, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
           mostrarDialogoFiltro();
            }
        });
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                actualizarJFrame();
            }
        });  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
      jLabel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
exportarDatosATxt();
       }
        });    // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
 jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();
    }
});         // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Control_piezasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Control_piezasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Control_piezasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Control_piezasVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Control_piezasVER().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
