/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vistas.ver;

import static com.unah.vista.Insumos.jTable1;
import dao.PuestoDAO;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Puesto;



/**
 *
 * @author pango
 */
public class Registro_PuestoVER extends javax.swing.JFrame {
private PuestoDAO puestoDAO;
    
   
       

public Registro_PuestoVER() {
        initComponents();
     puestoDAO = new PuestoDAO(); // Crea una instancia del DAO
        cargarDatosTabla(); 
    }
private void cargarDatosTabla() {
    // Verifica que jTable1 no sea null
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

    // Obtén el modelo de la tabla
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Obtener los datos desde el DAO
    List<Puesto> listaPuestos = puestoDAO.cargarDatos();

    // Agregar los datos al modelo de la tabla
    for (Puesto puesto : listaPuestos) {
        modeloTabla.addRow(new Object[]{
            puesto.getIdPuesto(),           // ID del puesto
            puesto.getNombrePuesto(),       // Nombre del puesto
            puesto.getPuesto(),             // Puesto
            puesto.getGrupo(),              // Grupo
            puesto.getTallerIdTaller()      // ID del taller
        });
    }
  }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Puesto", "Puesto", "Grupo", "Taller ID"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jLabel9.setText("Puestos");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel3))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 858, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7))
                        .addComponent(jLabel6))
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 549, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
private void exportarPuestos() {
        JFileChooser fileChooser = new JFileChooser();
        int resultado = fileChooser.showSaveDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            String rutaArchivo = archivo.getAbsolutePath();

            if (!rutaArchivo.endsWith(".txt")) {
                rutaArchivo += ".txt";
            }

            boolean exito = puestoDAO.exportarDatosAArchivoTxt(rutaArchivo);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Datos exportados correctamente a " + rutaArchivo, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Error al exportar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void mostrarDialogoFiltroPuestos() {
    // Opciones de filtro basadas en las columnas de la tabla Puesto
    String[] opcionesFiltro = {"ID Puesto", "Nombre del Puesto", "Puesto", "Grupo", "ID Taller"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    // Opciones de ordenación
    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    // Crear el panel de entrada
    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());

    // Crear panel para los checkboxes de filtro
    JPanel filtroPanel = new JPanel();
    filtroPanel.setLayout(new BoxLayout(filtroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    filtroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        filtroPanel.add(checkBox);
    }

    // Crear panel para la ordenación
    JPanel ordenPanel = new JPanel();
    ordenPanel.add(new JLabel("Selecciona el orden:"));
    ordenPanel.add(comboBoxOrden);

    // Añadir los paneles al panel principal
    panel.add(filtroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    // Mostrar el diálogo
    int resultado = JOptionPane.showConfirmDialog(null, panel, "Filtrar y Ordenar", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    
    if (resultado == JOptionPane.OK_OPTION) {
        // Obtener las opciones seleccionadas
        boolean[] columnasSeleccionadas = new boolean[checkBoxes.length];
        for (int i = 0; i < checkBoxes.length; i++) {
            columnasSeleccionadas[i] = checkBoxes[i].isSelected();
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();

        // Aplicar el filtro y orden en la tabla
        aplicarFiltroYOrdenPuestos(columnasSeleccionadas, ordenSeleccionado);
    }
}

private void aplicarFiltroYOrdenPuestos(boolean[] columnasSeleccionadas, String orden) {
    // Aquí iría la lógica para aplicar el filtro y orden en la tabla jTable1
    // Puedes usar las opciones seleccionadas para ajustar la visibilidad de las columnas y el orden de los datos
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    for (int i = 0; i < columnasSeleccionadas.length; i++) {
        jTable1.getColumnModel().getColumn(i).setMinWidth(columnasSeleccionadas[i] ? 15 : 0);
        jTable1.getColumnModel().getColumn(i).setMaxWidth(columnasSeleccionadas[i] ? Integer.MAX_VALUE : 0);
        jTable1.getColumnModel().getColumn(i).setPreferredWidth(columnasSeleccionadas[i] ? 100 : 0);
    }
    
    // Implementar la lógica para ordenar los datos de acuerdo al criterio seleccionado
    // Por ejemplo:
    if ("Ascendente".equals(orden)) {
        // Ordenar en orden ascendente
    } else if ("Descendente".equals(orden)) {
        // Ordenar en orden descendente
    }

    // Actualizar la tabla después de aplicar el filtro y orden
    // Dependiendo de cómo quieras implementar esto, podrías necesitar recargar los datos de la tabla
}

private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}
 
 
  private void mostrarDialogoBusqueda() {
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Puestos", true);
    dialogoBusqueda.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;

    JTextField campoBusqueda = new JTextField();
    dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
    gbc.gridy++;
    dialogoBusqueda.add(campoBusqueda, gbc);

    String[] opcionesFiltro = {"ID Puesto", "Nombre Puesto", "Puesto", "Grupo", "Taller ID"};
    JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); 
        panelOpciones.add(checkBoxes[i]);
    }
    gbc.gridy++;
    gbc.gridwidth = 2;
    dialogoBusqueda.add(panelOpciones, gbc);

    JButton botonBuscar = new JButton("Buscar");
    gbc.gridwidth = 1;
    gbc.gridy++;
    gbc.gridx = 0;
    dialogoBusqueda.add(botonBuscar, gbc);

    botonBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String textoBusqueda = campoBusqueda.getText().trim();
            List<String> columnasSeleccionadas = new ArrayList<>();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    columnasSeleccionadas.add(checkBox.getText());
                }
            }
            List<Puesto> resultadosBusqueda = buscarPuestos(textoBusqueda, columnasSeleccionadas);
            actualizarTablaConResultados(resultadosBusqueda);
            dialogoBusqueda.dispose();
        }
    });

    dialogoBusqueda.pack();
    dialogoBusqueda.setLocationRelativeTo(this);
    dialogoBusqueda.setVisible(true);
}

private List<Puesto> buscarPuestos(String textoBusqueda, List<String> columnasSeleccionadas) {
    if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
        return puestoDAO.cargarDatos();
    }

    String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

    List<Puesto> puestosList = puestoDAO.cargarDatos();

    return puestosList.stream()
            .filter(puesto -> {
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Puesto")) {
                    texto = String.valueOf(puesto.getIdPuesto()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Nombre Puesto")) {
                    texto = puesto.getNombrePuesto().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Puesto")) {
                    texto = puesto.getPuesto().toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Grupo")) {
                    texto = String.valueOf(puesto.getGrupo()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Taller ID")) {
                    texto = String.valueOf(puesto.getTallerIdTaller()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }

                return match;
            })
            .collect(Collectors.toList());
}

private void actualizarTablaConResultados(List<Puesto> puestosFiltrados) {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    for (Puesto puesto : puestosFiltrados) {
        modeloTabla.addRow(new Object[]{
            puesto.getIdPuesto(),
            puesto.getNombrePuesto(),
            puesto.getPuesto(),
            puesto.getGrupo(),
            puesto.getTallerIdTaller()
        });
    }
}


 
    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltroPuestos(); // Llamar al método para agregar insumo
            }
        });
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        jLabel7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                actualizarJFrame();
            }
        });  // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
  jLabel3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
               exportarPuestos();
            }
        });

    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();    }
});           // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro_PuestoVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro_PuestoVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro_PuestoVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro_PuestoVER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro_PuestoVER().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
