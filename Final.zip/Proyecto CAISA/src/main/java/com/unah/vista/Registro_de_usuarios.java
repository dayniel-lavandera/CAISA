/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vista;

import com.unah.modelos.Role;
import com.unah.modelos.Usuario;
import configuracion.ConexionBD;
import dao.UsuarioDAO;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author JuanMi025
 */
public class Registro_de_usuarios extends javax.swing.JFrame {
    private UsuarioDAO usuarioDAO;


    public Registro_de_usuarios() {
        // Inicializar usuarioDAO aquí
        usuarioDAO = new UsuarioDAO();
        
        // Otros inicializadores
        initComponents();
        cargarDatosTabla();
    }

   private void cargarDatosTabla() {
    // Verifica que jTable1 no sea null
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

    // Obtén el modelo de la tabla
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Obtener los datos desde el DAO
    List<Usuario> listaUsuarios = usuarioDAO.cargarDatos();

    // Definir los nombres de las columnas
    String[] columnNames = {"ID Usuario", "Nombre", "Password", "Rol"};

    // Crear el modelo de la tabla con los nombres de las columnas
    DefaultTableModel modelo = new DefaultTableModel(columnNames, 0);
    jTable1.setModel(modelo);

    // Agregar los datos al modelo de la tabla
    for (Usuario usuario : listaUsuarios) {
        modelo.addRow(new Object[]{
            usuario.getId(),
            usuario.getNombre(),     // Cambiado a getNombre()
            usuario.getPassword(),
            usuario.getRolString()   // Cambiado a getRolString() para obtener el rol como String
        });
    }


}
private void agregarUsuario() {
    // Crear un panel para contener todos los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    // Crear los campos de entrada
    JTextField idUsuarioField = new JTextField();
    JTextField nombreField = new JTextField();
    JTextField passwordField = new JTextField();
    
    // Crear el JComboBox para el rol
    String[] roles = {"ADMIN", "INFORMATICO"};
    JComboBox<String> rolComboBox = new JComboBox<>(roles);

    // Añadir los campos al panel
    panel.add(new JLabel("ID del nuevo usuario:"));
    panel.add(idUsuarioField);
    panel.add(new JLabel("Nombre del nuevo usuario:"));
    panel.add(nombreField);
    panel.add(new JLabel("Contraseña:"));
    panel.add(passwordField);
    panel.add(new JLabel("Rol:"));
    panel.add(rolComboBox);

    // Mostrar el panel en un JOptionPane
    int result = JOptionPane.showConfirmDialog(null, panel, "Ingrese los datos del nuevo usuario", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        try {
            int idUsuario = Integer.parseInt(idUsuarioField.getText().trim());
            String nombre = nombreField.getText().trim();
            String password = passwordField.getText().trim();
            String rolString = (String) rolComboBox.getSelectedItem();

            // Validar entrada del usuario
            if (!nombre.isEmpty() && !password.isEmpty() && rolString != null) {
                // Verificar si el ID o el nombre de usuario ya existen
                if (usuarioDAO.existeUsuario(idUsuario)) {
                    JOptionPane.showMessageDialog(null, "El ID del usuario ya existe. Por favor, elija otro.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (usuarioDAO.existeNombreUsuario(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre del usuario ya existe. Por favor, elija otro nombre.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Convertir el rol de String a enum Role
                    Role rol = Role.valueOf(rolString);

                    // Crear el objeto Usuario
                    Usuario nuevoUsuario = new Usuario(idUsuario, nombre, password, rol);

                    // Agregar el nuevo usuario a la base de datos
                    boolean exito = usuarioDAO.agregarUsuario(nuevoUsuario);

                    if (exito) {
                        JOptionPane.showMessageDialog(null, "Usuario agregado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarDatosTabla(); // Recargar datos en la tabla
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al agregar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe completar todos los campos para agregar el usuario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID del usuario debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.getRootFrame().dispose(); // Cierra la ventana del JOptionPane
    }
}

private void eliminarUsuario() {
    // Solicitar al usuario el ID del usuario que desea eliminar
    String idStr = JOptionPane.showInputDialog("Ingrese el ID del usuario que desea eliminar:");
    
    if (idStr != null && !idStr.trim().isEmpty()) {
        try {
            int idUsuario = Integer.parseInt(idStr.trim());
            
            // Eliminar el usuario usando el ID proporcionado
            boolean exito = usuarioDAO.eliminarUsuario(idUsuario);
            
            if (exito) {
                JOptionPane.showMessageDialog(null, "Usuario eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe ingresar un ID válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

    
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        jLabel8.setFont(new java.awt.Font("Dubai Medium", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Control de usuarios");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cancelbutton_99626.png"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel9))
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Contraseña", "Rol"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 820, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 519, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        jLabel4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
agregarUsuario();
            }
        });// TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        jLabel2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
eliminarUsuario();
            }
        });    // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        System.exit(0);        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro_de_usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro_de_usuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
