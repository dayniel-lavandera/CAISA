/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.unah.vista;


import dao.PersonalDAO;
import dao.PiezaDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Pieza;



/**
 *
 * @author pango
 */
public class Control_piezas extends javax.swing.JFrame {
 private PiezaDAO piezaDAO;
    /**
     * Creates new form Control_piezas
     */
    public Control_piezas() {
        initComponents();
    piezaDAO = new PiezaDAO(); // Crea una instancia del DAO
        cargarDatosTabla();
    actualizarTabla();
    
    }
private void cargarDatosTabla() {
    // Verifica que jTable1 no sea null
    if (jTable1 == null) {
        System.out.println("jTable1 es null");
        return;
    }

    // Obtén el modelo de la tabla
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla

    // Obtener los datos desde el DAO
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Definir los nombres de las columnas
    String[] columnNames = {"ID", "Número", "Código", "Cantidad", "Diseño", "Control Físico", "Observaciones", "Sobrante", "Causa", "Puesto ID", "Operaciones ID", "Puesto ID 2"};

    // Crear el modelo de la tabla con los nombres de las columnas
    DefaultTableModel modelo = new DefaultTableModel(columnNames, 0);
    jTable1.setModel(modelo);

    // Agregar los datos al modelo de la tabla
    for (Pieza pieza : listaPiezas) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}

private void agregarPieza() {
    // Crear un panel para contener todos los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    // Crear los campos de entrada
    JTextField numeroField = new JTextField();
    JTextField codigoField = new JTextField();
    JTextField cantidadField = new JTextField();
    JTextField diseñoField = new JTextField();
    JTextField controlFisicoField = new JTextField();
    JTextField observacionesField = new JTextField();
    JTextField sobranteField = new JTextField();
    JTextField causaField = new JTextField();
    JTextField puestoidPuestoField = new JTextField();
    JTextField operacionesidOperacionesField = new JTextField();
    JTextField puestoidPuesto2Field = new JTextField();

    // Añadir los campos al panel
    panel.add(new JLabel("Número:"));
    panel.add(numeroField);
    panel.add(new JLabel("Código:"));
    panel.add(codigoField);
    panel.add(new JLabel("Cantidad:"));
    panel.add(cantidadField);
    panel.add(new JLabel("Diseño:"));
    panel.add(diseñoField);
    panel.add(new JLabel("Control Físico:"));
    panel.add(controlFisicoField);
    panel.add(new JLabel("Observaciones:"));
    panel.add(observacionesField);
    panel.add(new JLabel("Sobrante:"));
    panel.add(sobranteField);
    panel.add(new JLabel("Causa:"));
    panel.add(causaField);
    panel.add(new JLabel("ID del Puesto:"));
    panel.add(puestoidPuestoField);
    panel.add(new JLabel("ID de Operaciones:"));
    panel.add(operacionesidOperacionesField);
    panel.add(new JLabel("ID del Segundo Puesto:"));
    panel.add(puestoidPuesto2Field);

    // Mostrar el panel en un JOptionPane
    int option = JOptionPane.showConfirmDialog(null, panel, "Ingrese los datos de la pieza", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (option == JOptionPane.OK_OPTION) {
        try {
            // Validar campos numéricos y de texto
            String numeroStr = numeroField.getText().trim();
            if (numeroStr.isEmpty() || !numeroStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'Número' solo puede contener números y no puede estar vacío.");
            }
            int numero = Integer.parseInt(numeroStr);

            String codigoStr = codigoField.getText().trim();
            if (codigoStr.isEmpty() || !codigoStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'Código' solo puede contener números y no puede estar vacío.");
            }
            int codigo = Integer.parseInt(codigoStr);

            String cantidadStr = cantidadField.getText().trim();
            if (cantidadStr.isEmpty() || !cantidadStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'Cantidad' solo puede contener números y no puede estar vacío.");
            }
            int cantidad = Integer.parseInt(cantidadStr);

            String diseñoStr = diseñoField.getText().trim();
            if (diseñoStr.isEmpty() || !diseñoStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'Diseño' solo puede contener números y no puede estar vacío.");
            }
            int diseño = Integer.parseInt(diseñoStr);

            String controlFisico = controlFisicoField.getText().trim();
            if (controlFisico.isEmpty() || controlFisico.length() > 255) {
                throw new IllegalArgumentException("El campo 'Control Físico' no puede estar vacío y debe tener una longitud máxima de 255 caracteres.");
            }

            String observaciones = observacionesField.getText().trim();
            if (observaciones.length() > 255) {
                throw new IllegalArgumentException("El campo 'Observaciones' debe tener una longitud máxima de 255 caracteres.");
            }

            String causa = causaField.getText().trim();
            if (causa.length() > 255) {
                throw new IllegalArgumentException("El campo 'Causa' debe tener una longitud máxima de 255 caracteres.");
            }

            String sobranteStr = sobranteField.getText().trim();
            if (sobranteStr.isEmpty() || !sobranteStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'Sobrante' solo puede contener números y no puede estar vacío.");
            }
            int sobrante = Integer.parseInt(sobranteStr);

            String puestoidPuestoStr = puestoidPuestoField.getText().trim();
            if (puestoidPuestoStr.isEmpty() || !puestoidPuestoStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'ID del Puesto' solo puede contener números y no puede estar vacío.");
            }
            int puestoidPuesto = Integer.parseInt(puestoidPuestoStr);

            String operacionesidOperacionesStr = operacionesidOperacionesField.getText().trim();
            if (operacionesidOperacionesStr.isEmpty() || !operacionesidOperacionesStr.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'ID de Operaciones' solo puede contener números y no puede estar vacío.");
            }
            int operacionesidOperaciones = Integer.parseInt(operacionesidOperacionesStr);

            String puestoidPuesto2Str = puestoidPuesto2Field.getText().trim();
            if (puestoidPuesto2Str.isEmpty() || !puestoidPuesto2Str.matches("\\d+")) {
                throw new IllegalArgumentException("El campo 'ID del Segundo Puesto' solo puede contener números y no puede estar vacío.");
            }
            int puestoidPuesto2 = Integer.parseInt(puestoidPuesto2Str);

            // Crear el objeto Pieza
            Pieza nuevaPieza = new Pieza(0, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoidPuesto, operacionesidOperaciones, puestoidPuesto2);

            // Llamar al DAO para agregar la pieza
            boolean exito = piezaDAO.agregarPieza(nuevaPieza);

            // Informar al usuario del resultado
            if (exito) {
                JOptionPane.showMessageDialog(null, "Pieza agregada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarDatosTabla(); // Recargar datos en la tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar la pieza.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Algunos campos numéricos contienen valores no válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error de Validación", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe completar todos los campos para agregar la pieza.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void eliminarPieza() {
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID de la pieza que desea eliminar:", "Eliminar Pieza", JOptionPane.QUESTION_MESSAGE);

    if (input != null && !input.trim().isEmpty()) {
        try {
            int idPieza = Integer.parseInt(input.trim());

            int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar la pieza con ID " + idPieza + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                boolean exito = piezaDAO.eliminarPieza(idPieza);

                if (exito) {
                    JOptionPane.showMessageDialog(null, "Pieza eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                    // Actualizar la tabla después de eliminar la pieza
                    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                    for (int i = 0; i < model.getRowCount(); i++) {
                        if ((int) model.getValueAt(i, 0) == idPieza) {
                            model.removeRow(i);
                            break;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar la pieza. Verifique si el ID es correcto o si existen dependencias.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de eliminación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void modificarPieza() {
    String input = JOptionPane.showInputDialog(null, "Ingrese el ID de la pieza que desea modificar:", "Modificar Pieza", JOptionPane.QUESTION_MESSAGE);

    if (input != null && !input.trim().isEmpty()) {
        try {
            int idPieza = Integer.parseInt(input.trim());

            // Crear un panel para ingresar los nuevos datos de la pieza
            JPanel panel = new JPanel(new GridLayout(0, 2));

            // Crear los campos de entrada
            JTextField numeroField = new JTextField();
            JTextField codigoField = new JTextField();
            JTextField cantidadField = new JTextField();
            JTextField diseñoField = new JTextField();
            JTextField controlFisicoField = new JTextField();
            JTextField observacionesField = new JTextField();
            JTextField sobranteField = new JTextField();
            JTextField causaField = new JTextField();
            JTextField puestoidPuestoField = new JTextField();
            JTextField operacionesidOperacionesField = new JTextField();
            JTextField puestoidPuesto2Field = new JTextField();

            // Añadir los campos al panel
            panel.add(new JLabel("Número:"));
            panel.add(numeroField);
            panel.add(new JLabel("Código:"));
            panel.add(codigoField);
            panel.add(new JLabel("Cantidad:"));
            panel.add(cantidadField);
            panel.add(new JLabel("Diseño:"));
            panel.add(diseñoField);
            panel.add(new JLabel("Control Físico:"));
            panel.add(controlFisicoField);
            panel.add(new JLabel("Observaciones:"));
            panel.add(observacionesField);
            panel.add(new JLabel("Sobrante:"));
            panel.add(sobranteField);
            panel.add(new JLabel("Causa:"));
            panel.add(causaField);
            panel.add(new JLabel("ID del Puesto:"));
            panel.add(puestoidPuestoField);
            panel.add(new JLabel("ID de Operaciones:"));
            panel.add(operacionesidOperacionesField);
            panel.add(new JLabel("ID del Segundo Puesto:"));
            panel.add(puestoidPuesto2Field);

            // Mostrar el panel en un JOptionPane
            int option = JOptionPane.showConfirmDialog(null, panel, "Ingrese los nuevos datos de la pieza", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (option == JOptionPane.OK_OPTION) {
                try {
                    // Validar campos numéricos y de texto
                    String numeroStr = numeroField.getText().trim();
                    if (!numeroStr.isEmpty() && !numeroStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'Número' solo puede contener números.");
                    }
                    Integer numero = numeroStr.isEmpty() ? null : Integer.parseInt(numeroStr);

                    String codigoStr = codigoField.getText().trim();
                    if (!codigoStr.isEmpty() && !codigoStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'Código' solo puede contener números.");
                    }
                    Integer codigo = codigoStr.isEmpty() ? null : Integer.parseInt(codigoStr);

                    String cantidadStr = cantidadField.getText().trim();
                    if (!cantidadStr.isEmpty() && !cantidadStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'Cantidad' solo puede contener números.");
                    }
                    Integer cantidad = cantidadStr.isEmpty() ? null : Integer.parseInt(cantidadStr);

                    String diseñoStr = diseñoField.getText().trim();
                    if (!diseñoStr.isEmpty() && !diseñoStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'Diseño' solo puede contener números.");
                    }
                    Integer diseño = diseñoStr.isEmpty() ? null : Integer.parseInt(diseñoStr);

                    String controlFisico = controlFisicoField.getText().trim();
                    if (controlFisico.length() > 255) {
                        throw new IllegalArgumentException("El campo 'Control Físico' debe tener una longitud máxima de 255 caracteres.");
                    }

                    String observaciones = observacionesField.getText().trim();
                    if (observaciones.length() > 255) {
                        throw new IllegalArgumentException("El campo 'Observaciones' debe tener una longitud máxima de 255 caracteres.");
                    }

                    String causa = causaField.getText().trim();
                    if (causa.length() > 255) {
                        throw new IllegalArgumentException("El campo 'Causa' debe tener una longitud máxima de 255 caracteres.");
                    }

                    String sobranteStr = sobranteField.getText().trim();
                    if (!sobranteStr.isEmpty() && !sobranteStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'Sobrante' solo puede contener números.");
                    }
                    Integer sobrante = sobranteStr.isEmpty() ? null : Integer.parseInt(sobranteStr);

                    String puestoidPuestoStr = puestoidPuestoField.getText().trim();
                    if (!puestoidPuestoStr.isEmpty() && !puestoidPuestoStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'ID del Puesto' solo puede contener números.");
                    }
                    Integer puestoidPuesto = puestoidPuestoStr.isEmpty() ? null : Integer.parseInt(puestoidPuestoStr);

                    String operacionesidOperacionesStr = operacionesidOperacionesField.getText().trim();
                    if (!operacionesidOperacionesStr.isEmpty() && !operacionesidOperacionesStr.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'ID de Operaciones' solo puede contener números.");
                    }
                    Integer operacionesidOperaciones = Integer.parseInt(operacionesidOperacionesStr);

                    String puestoidPuesto2Str = puestoidPuesto2Field.getText().trim();
                    if (!puestoidPuesto2Str.isEmpty() && !puestoidPuesto2Str.matches("\\d+")) {
                        throw new IllegalArgumentException("El campo 'ID del Segundo Puesto' solo puede contener números.");
                    }
                    Integer puestoidPuesto2 = Integer.parseInt(puestoidPuesto2Str);

                    // Crear el objeto Pieza con los datos validados
                    Pieza piezaModificada = new Pieza(idPieza, numero, codigo, cantidad, diseño, controlFisico, observaciones, sobrante, causa, puestoidPuesto, operacionesidOperaciones, puestoidPuesto2);

                    // Llamar al DAO para actualizar la pieza
                    boolean exito = piezaDAO.actualizarPieza(piezaModificada);

                    // Informar al usuario del resultado
                    if (exito) {
                        JOptionPane.showMessageDialog(null, "Pieza modificada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        cargarDatosTabla(); // Recargar datos en la tabla
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al modificar la pieza. Verifique el ID y los datos.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Algunos campos numéricos contienen valores no válidos.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IllegalArgumentException e) {
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Error de Validación", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No se ingresaron los datos necesarios para modificar la pieza.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID ingresado no es válido. Debe ingresar un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se ingresó un ID. La operación de modificación ha sido cancelada.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

private void exportarDatosATxt() {
    // Solicitar el nombre del archivo al usuario
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar como");
    int userSelection = fileChooser.showSaveDialog(null);

    if (userSelection != JFileChooser.APPROVE_OPTION) {
        return; // Usuario canceló la operación
    }

    File fileToSave = fileChooser.getSelectedFile();
    
    // Verificar si el archivo ya tiene una extensión
    String filePath = fileToSave.getPath();
    if (!filePath.endsWith(".txt")) {
        filePath += ".txt";
    }

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
        // Obtener el modelo de la tabla
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();

        // Escribir los nombres de las columnas
        for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
            writer.write(modeloTabla.getColumnName(i));
            if (i < modeloTabla.getColumnCount() - 1) {
                writer.write("\t"); // Separar columnas por tabulador
            }
        }
        writer.newLine();

        // Escribir los datos de las filas
        for (int row = 0; row < modeloTabla.getRowCount(); row++) {
            for (int col = 0; col < modeloTabla.getColumnCount(); col++) {
                writer.write(modeloTabla.getValueAt(row, col).toString());
                if (col < modeloTabla.getColumnCount() - 1) {
                    writer.write("\t"); // Separar columnas por tabulador
                }
            }
            writer.newLine();
        }

        JOptionPane.showMessageDialog(null, "Datos exportados exitosamente a " + filePath, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(null, "Error al exportar los datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void mostrarDialogoFiltro() {
    String[] opcionesFiltro = {"ID", "Número", "Código", "Cantidad", "Diseño"};
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); // Selecciona todas las columnas por defecto
    }

    String[] opcionesOrden = {"Ascendente", "Descendente"};
    JComboBox<String> comboBoxOrden = new JComboBox<>(opcionesOrden);

    JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    JPanel centroPanel = new JPanel();
    centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
    JLabel etiquetaFiltro = new JLabel("Selecciona las columnas a mostrar:");
    etiquetaFiltro.setFont(new Font("Arial", Font.BOLD, 12));
    centroPanel.add(etiquetaFiltro);
    for (JCheckBox checkBox : checkBoxes) {
        centroPanel.add(checkBox);
    }
    JPanel ordenPanel = new JPanel();
    ordenPanel.setLayout(new FlowLayout());
    JLabel etiquetaOrden = new JLabel("Ordenar:");
    etiquetaOrden.setFont(new Font("Arial", Font.BOLD, 12));
    ordenPanel.add(etiquetaOrden);
    ordenPanel.add(comboBoxOrden);

    panel.add(centroPanel, BorderLayout.CENTER);
    panel.add(ordenPanel, BorderLayout.SOUTH);

    int resultado = JOptionPane.showConfirmDialog(null, panel, "Opciones de Filtro y Ordenación", JOptionPane.OK_CANCEL_OPTION);
    if (resultado == JOptionPane.OK_OPTION) {
        List<String> columnasSeleccionadas = new ArrayList<>();
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                columnasSeleccionadas.add(checkBox.getText());
            }
        }
        String ordenSeleccionado = (String) comboBoxOrden.getSelectedItem();
        aplicarFiltroYOrden(columnasSeleccionadas, ordenSeleccionado);
    }
}

private void aplicarFiltroYOrden(List<String> columnasSeleccionadas, String orden) {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Ordenar la lista
    listaPiezas.sort((p1, p2) -> {
        int comparacion = 0;
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    comparacion = Integer.compare(p1.getIdPieza(), p2.getIdPieza());
                    break;
                case "Número":
                    comparacion = Integer.compare(p1.getNumero(), p2.getNumero());
                    break;
                case "Código":
                    comparacion = Integer.compare(p1.getCodigo(), p2.getCodigo());
                    break;
                case "Cantidad":
                    comparacion = Integer.compare(p1.getCantidad(), p2.getCantidad());
                    break;
                case "Diseño":
                    comparacion = Integer.compare(p1.getDiseño(), p2.getDiseño());
                    break;
            }
            if (comparacion != 0) break; // Si ya hay una diferencia, no seguir comparando
        }
        return "Ascendente".equals(orden) ? comparacion : -comparacion;
    });

    // Crear el modelo de la tabla con las columnas seleccionadas
    DefaultTableModel modelo = new DefaultTableModel(columnasSeleccionadas.toArray(), 0);
    jTable1.setModel(modelo);

    // Agregar los datos filtrados y ordenados al modelo de la tabla
    for (Pieza pieza : listaPiezas) {
        List<Object> fila = new ArrayList<>();
        for (String columna : columnasSeleccionadas) {
            switch (columna) {
                case "ID":
                    fila.add(pieza.getIdPieza());
                    break;
                case "Número":
                    fila.add(pieza.getNumero());
                    break;
                case "Código":
                    fila.add(pieza.getCodigo());
                    break;
                case "Cantidad":
                    fila.add(pieza.getCantidad());
                    break;
                case "Diseño":
                    fila.add(pieza.getDiseño());
                    break;
            }
        }
        modelo.addRow(fila.toArray());
    }
}

private void actualizarTabla() {
    List<Pieza> listaPiezas = piezaDAO.cargarDatos();

    // Obtener el modelo de la tabla actual
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();

    // Crear un mapa para buscar piezas por ID
    Map<Integer, Pieza> mapaPiezas = new HashMap<>();
    for (Pieza pieza : listaPiezas) {
        mapaPiezas.put(pieza.getIdPieza(), pieza);
    }

    // Actualizar las filas existentes
    for (int i = 0; i < modelo.getRowCount(); i++) {
        int idPieza = (int) modelo.getValueAt(i, 0);
        Pieza pieza = mapaPiezas.get(idPieza);
        if (pieza != null) {
            modelo.setValueAt(pieza.getNumero(), i, 1);
            modelo.setValueAt(pieza.getCodigo(), i, 2);
            modelo.setValueAt(pieza.getCantidad(), i, 3);
            modelo.setValueAt(pieza.getDiseño(), i, 4);
            modelo.setValueAt(pieza.getControlFisico(), i, 5);
            modelo.setValueAt(pieza.getObservaciones(), i, 6);
            modelo.setValueAt(pieza.getSobrante(), i, 7);
            modelo.setValueAt(pieza.getCausa(), i, 8);
            modelo.setValueAt(pieza.getPuestoIdPuesto(), i, 9);
            modelo.setValueAt(pieza.getOperacionesIdOperaciones(), i, 10);
            modelo.setValueAt(pieza.getPuestoIdPuesto2(), i, 11);
            mapaPiezas.remove(idPieza); // Eliminar la pieza del mapa
        }
    }

    // Agregar nuevas filas para las piezas restantes en el mapa
    for (Pieza pieza : mapaPiezas.values()) {
        modelo.addRow(new Object[]{
            pieza.getIdPieza(),
            pieza.getNumero(),
            pieza.getCodigo(),
            pieza.getCantidad(),
            pieza.getDiseño(),
            pieza.getControlFisico(),
            pieza.getObservaciones(),
            pieza.getSobrante(),
            pieza.getCausa(),
            pieza.getPuestoIdPuesto(),
            pieza.getOperacionesIdOperaciones(),
            pieza.getPuestoIdPuesto2()
        });
    }
}

private void actualizarJFrame() {
    // Ejemplo de cómo podrías actualizar el contenido del JFrame.
    // Aquí simplemente refrescamos el panel principal.
    this.getContentPane().removeAll(); // Eliminar todos los componentes actuales
    initComponents(); // Volver a inicializar los componentes (cargar de nuevo el contenido)

    // Si tienes métodos específicos para actualizar datos, llámalos aquí
    cargarDatosTabla(); // Por ejemplo, recargar los datos en una tabla

    this.revalidate(); // Revalidar el JFrame para aplicar cambios
    this.repaint(); // Volver a pintar el JFrame
}

private void mostrarDialogoBusqueda() {
    JDialog dialogoBusqueda = new JDialog(this, "Buscar Piezas", true);
    dialogoBusqueda.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;

    
    JTextField campoBusqueda = new JTextField();
    dialogoBusqueda.add(new JLabel("Texto de búsqueda:"), gbc);
    gbc.gridy++;
    dialogoBusqueda.add(campoBusqueda, gbc);

    
    String[] opcionesFiltro = {"ID Pieza", "Número", "Código", "Cantidad", "Diseño"};
    JPanel panelOpciones = new JPanel(new GridLayout(opcionesFiltro.length, 1));
    JCheckBox[] checkBoxes = new JCheckBox[opcionesFiltro.length];
    for (int i = 0; i < opcionesFiltro.length; i++) {
        checkBoxes[i] = new JCheckBox(opcionesFiltro[i]);
        checkBoxes[i].setSelected(true); 
        panelOpciones.add(checkBoxes[i]);
    }
    gbc.gridy++;
    gbc.gridwidth = 2;
    dialogoBusqueda.add(panelOpciones, gbc);

    JButton botonBuscar = new JButton("Buscar");
    gbc.gridwidth = 1;
    gbc.gridy++;
    gbc.gridx = 0;
    dialogoBusqueda.add(botonBuscar, gbc);


    botonBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String textoBusqueda = campoBusqueda.getText().trim();
            List<String> columnasSeleccionadas = new ArrayList<>();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    columnasSeleccionadas.add(checkBox.getText());
                }
            }
            List<Pieza> resultadosBusqueda = buscarPiezas(textoBusqueda, columnasSeleccionadas);
            actualizarTablaConResultados(resultadosBusqueda);
            dialogoBusqueda.dispose();
        }
    });

    dialogoBusqueda.pack();
    dialogoBusqueda.setLocationRelativeTo(this);
    dialogoBusqueda.setVisible(true);
}

private List<Pieza> buscarPiezas(String textoBusqueda, List<String> columnasSeleccionadas) {
    if (textoBusqueda == null || textoBusqueda.trim().isEmpty()) {
        return piezaDAO.cargarDatos();
    }

    String textoBusquedaLowerCase = textoBusqueda.toLowerCase();

    List<Pieza> piezasList = piezaDAO.cargarDatos();

    return piezasList.stream()
            .filter(pieza -> {
              
                boolean match = false;
                String texto = "";

                if (columnasSeleccionadas.contains("ID Pieza")) {
                    texto = String.valueOf(pieza.getIdPieza()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Número")) {
                    texto = String.valueOf(pieza.getNumero()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Código")) {
                    texto = String.valueOf(pieza.getCodigo()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Cantidad Adicional")) {
                    texto = String.valueOf(pieza.getCantidad()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                if (columnasSeleccionadas.contains("Diseño")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                    if (columnasSeleccionadas.contains("Cantidad")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                }
                
                     if (columnasSeleccionadas.contains("Control Fisico")) {
                    texto = String.valueOf(pieza.getDiseño()).toLowerCase();
                    match |= texto.contains(textoBusquedaLowerCase);
                } 
                    
                    return match;
            })
            .collect(Collectors.toList());
}

private void actualizarTablaConResultados(List<Pieza> piezasFiltrado) {
    DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0); // Limpiar la tabla


    for (Pieza pieza : piezasFiltrado) {
        modeloTabla.addRow(new Object[]{
                pieza.getIdPieza(),
                pieza.getNumero(),
                pieza.getCodigo(),
                pieza.getCantidad(),
                pieza.getDiseño()
        });
    }
}




@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Pieza", "Número", "Código", "Cantidad Adicional", "Diseño", "Cantidad", "Control FÍsico", "Observaciones", "Sobrante", "Causas", "Operaciones ID ", "Puesto ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/4213417-explore-find-glass-magnifier-search-view-zoom_115406.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1486485588-add-create-new-math-sign-cross-plus_81186.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504830-delete-dustbin-empty-recycle-recycling-remove-trash_81361 (1).png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486505366-exit-export-out-send-sending-archive-outside_81436.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1486504369-change-edit-options-pencil-settings-tools-write_81307.png"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fillingfilter_filter_4512 (1).png"))); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/database_refresh_icon_137697.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jLabel8.setText("Piezas ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1066, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)))
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        jLabel4.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        agregarPieza(); // Llamar al método para agregar insumo
    }
});// TODO add your handling code here:
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
    jLabel2.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        eliminarPieza(); // Llamar al método para agregar insumo
    }
});    // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
     jLabel3.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        exportarDatosATxt(); // Llamar al método para agregar insumo
    }
});   // TODO add your handling code here:
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
         jLabel1.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        modificarPieza(); // Llamar al método para agregar insumo
    }
});   // TODO// TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
jLabel5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                mostrarDialogoFiltro();
            }
        });
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
 jLabel7.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
 actualizarJFrame();
    }
});           // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
    jLabel6.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
mostrarDialogoBusqueda();    }
});          // TODO add your handling code here:
    }//GEN-LAST:event_jLabel6MouseClicked

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Control_piezas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Control_piezas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
