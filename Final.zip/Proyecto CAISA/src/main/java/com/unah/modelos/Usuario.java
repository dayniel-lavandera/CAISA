package com.unah.modelos;

public class Usuario {
    private int id;
    private String nombre;
    private String password;
    private Role rol;

    // Constructor con Role
    public Usuario(int id, String nombre, String password, Role rol) {
        this.id = id;
        this.nombre = nombre;
        this.password = password;
        this.rol = rol;
    }

    // Constructor con String para el rol (para compatibilidad con la base de datos)
    public Usuario(int id, String nombre, String password, String rol) {
        this.id = id;
        this.nombre = nombre;
        this.password = password;
        try {
            this.rol = Role.valueOf(rol.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Rol inválido: " + rol, e);
        }
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRol() {
        return rol;
    }

    public void setRol(Role rol) {
        this.rol = rol;
    }

    // Para representar el rol como String, si es necesario
    public String getRolString() {
        return rol != null ? rol.name() : null;
    }

    @Override
    public String toString() {
        return "Usuario{id=" + id + ", nombre='" + nombre + "', rol=" + rol + '}';
    }
}
