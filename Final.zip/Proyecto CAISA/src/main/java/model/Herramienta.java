package model;

public class Herramienta {
    private int idHerramienta;
    private String nombre;
    private String cantidad;
    private String proveedor;
    private int puesto;
    private int puestoidPuesto;

    public Herramienta(int idHerramienta, String nombre, String cantidad, String proveedor, int puesto, int puestoidPuesto) {
        this.idHerramienta = idHerramienta;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.proveedor = proveedor;
        this.puesto = puesto;
        this.puestoidPuesto = puestoidPuesto;
    }

    public Herramienta() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters
    public int getIdHerramienta() {
        return idHerramienta;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCantidad() {
        return cantidad;
    }

    public String getProveedor() {
        return proveedor;
    }

    public int getPuesto() {
        return puesto;
    }

    public int getPuestoidPuesto() {
        return puestoidPuesto;
    }

    // Setters
    public void setIdHerramienta(int idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public void setPuesto(int puesto) {
        this.puesto = puesto;
    }

    public void setPuestoidPuesto(int puestoidPuesto) {
        this.puestoidPuesto = puestoidPuesto;
    }
}
