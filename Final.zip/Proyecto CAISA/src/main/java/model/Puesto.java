package model;

public class Puesto {
    private int idPuesto;
    private String nombrePuesto;
    private String puesto;
    private String grupo; // El tipo de 'grupo' es int
    private int tallerIdTaller;

    // Constructor principal con todos los parámetros
    public Puesto(int idPuesto, String nombrePuesto, String puesto, String grupo, int tallerIdTaller) {
        this.idPuesto = idPuesto;
        this.nombrePuesto = nombrePuesto;
        this.puesto = puesto;
        this.grupo = grupo;
        this.tallerIdTaller = tallerIdTaller;
    }

    // Getters y Setters
    public int getIdPuesto() {
        return idPuesto;
    }

    public void setIdPuesto(int idPuesto) {
        this.idPuesto = idPuesto;
    }

    public String getNombrePuesto() {
        return nombrePuesto;
    }

    public void setNombrePuesto(String nombrePuesto) {
        this.nombrePuesto = nombrePuesto;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public int getTallerIdTaller() {
        return tallerIdTaller;
    }

    public void setTallerIdTaller(int tallerIdTaller) {
        this.tallerIdTaller = tallerIdTaller;
    }

    @Override
    public String toString() {
        return "Puesto{" +
                "idPuesto=" + idPuesto +
                ", nombrePuesto='" + nombrePuesto + '\'' +
                ", puesto='" + puesto + '\'' +
                ", grupo=" + grupo +
                ", tallerIdTaller=" + tallerIdTaller +
                '}';
    }
}
